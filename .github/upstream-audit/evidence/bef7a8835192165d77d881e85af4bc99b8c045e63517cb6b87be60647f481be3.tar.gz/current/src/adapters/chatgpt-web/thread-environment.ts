import { existsSync, readFileSync, renameSync } from "node:fs";
import { isAbsolute, relative, resolve } from "node:path";
import { isCurrentOrParentThreadVisualizationRoot, pathIdentity as environmentPathIdentity } from "./environment-paths";
import { atomicWriteFile, stripUtf8Bom } from "../../config";
import { getCodexHome, getTrustedCodexHomes } from "../../codex-integration-shared";
import { isReadableCompactionSummaryText } from "../../responses/compaction";
import type { CodexParsedRequest } from "../../types";
import {
  extractChatGptTurnEnvironmentClaim,
  extractChatGptCompactionSourceRevision,
  extractChatGptContinuationEnvironmentClaims,
  extractChatGptSteeringEnvironmentClaim,
  extractChatGptTurnIdentity,
  extractChatGptThreadSpawnLineage,
  extractChatGptRootThreadMetadata,
  hasCurrentChatGptEnvironmentContext,
  extractChatGptCalendarEnvironmentDelta,
  hasRawChatGptEnvironmentContext,
  isChatGptCompactionContinuation,
  MissingTrustedCodexEnvironmentError,
  type ChatGptEnvironmentClaim,
  type ChatGptSandboxPolicy,
  type ChatGptTurnEnvironment,
} from "./environment";
import { effectiveChatGptToolPolicy } from "./tool-policy";
import { resolveCurrentCodexRolloutEnvironment } from "./codex-rollout-environment";
import { unattributedChatGptEnvironmentMessages } from "./environment-history";
import { isAcceptedCompactionContinuation } from "./compaction-continuation";
import { hasEnvironmentContextFragment, isPureContextualCodexUserText } from "./contextual-user-message";
import { codexTurnMetadataFromBody } from "./environment-identity";
import {
  isCurrentTurnInstruction,
  isCurrentTurnInstructionCandidate,
  isNativeInstruction,
  itemTurnId,
  priorAbortedTurnIds,
  turnUserRevisionHistory,
} from "./turn-user-revision";
import { ChatGptWebAdapterError } from "./adapter-error";

interface StoredThreadEnvironment {
  cwd: string;
  roots: string[];
  writableRoots: string[];
  sandboxPolicy: ChatGptSandboxPolicy;
  updatedAt: number;
}

type CurrentTurnAnchor = {
  id: string;
  type: string;
  role: unknown;
  content: unknown;
  author: unknown;
  recipient: unknown;
  name?: unknown;
  namespace?: unknown;
  output?: unknown;
  call_id?: unknown;
};

interface StoredThreadEnvironmentFile {
  version: 1;
  threads: Record<string, StoredThreadEnvironment>;
}

const MAX_THREAD_ENVIRONMENTS = 256;
const THREAD_ENVIRONMENT_TTL_MS = 30 * 24 * 60 * 60_000;

function record(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined;
}

function isSingleEnvelope(text: string, whole: RegExp, tags: RegExp): boolean {
  return whole.test(text) && (text.match(tags)?.length ?? 0) === 2;
}

function environmentContextPart(value: unknown): boolean {
  const part = record(value);
  return (part?.type === "input_text" || part?.type === "text") && typeof part.text === "string"
    && isSingleEnvelope(
      part.text.trim(),
      /^<environment_context>[\s\S]*<\/environment_context>$/i,
      /<\/?environment_context>/gi,
    );
}

function singleContextualPart(value: unknown): boolean {
  const part = record(value);
  return (part?.type === "input_text" || part?.type === "text") && typeof part.text === "string"
    && isPureContextualCodexUserText(part.text);
}

function pureContextualUserMessage(item: Record<string, unknown>): boolean {
  return item.type === "message" && item.role === "user"
    && Array.isArray(item.content) && item.content.length > 0
    && item.content.every(singleContextualPart);
}

function isPassiveCurrentContextualContinuation(item: Record<string, unknown> | undefined, turnId: string): boolean {
  const owner = itemTurnId(item);
  return !!item && typeof item.id === "string" && !!item.id && (owner === undefined || owner === turnId)
    && pureContextualUserMessage(item)
    && !(item.content as unknown[]).some(part => environmentContextPart(part) || goalContextPart(part));
}

function rolloutAnchor(item: Record<string, unknown> | undefined): CurrentTurnAnchor | undefined {
  if (!item || typeof item.id !== "string" || !item.id || typeof item.type !== "string") return undefined;
  // Cross-task instructions use output rather than content. Keep the native shape guard;
  // the rollout must still authenticate every field in this exact current-turn message.
  const delegated = item.type === "function_call_output" && isNativeInstruction(item);
  if (!("content" in item) && !delegated) return undefined;
  return {
    id: item.id,
    type: item.type,
    role: item.role,
    content: item.content,
    author: item.author,
    recipient: item.recipient,
    ...(delegated ? { name: item.name, namespace: item.namespace, output: item.output, call_id: item.call_id } : {}),
  };
}

function modelSwitchMessage(item: Record<string, unknown> | undefined, turnId: string): boolean {
  if (!item || item.type !== "message" || item.role !== "developer" || itemTurnId(item) !== turnId) return false;
  const parts = typeof item.content === "string" ? [item.content] : Array.isArray(item.content) && item.content.length === 1
    ? item.content.flatMap(value => {
      const part = record(value);
      return (part?.type === "input_text" || part?.type === "text") && typeof part.text === "string" ? [part.text] : [];
    }) : [];
  return parts.length === 1
    && /^<model_switch>[\s\S]*<\/model_switch>$/.test(parts[0]!.trim())
    && (parts[0]!.match(/<\/?model_switch>/g)?.length ?? 0) === 2;
}

function currentTurnRolloutAnchor(
  input: unknown[],
  checkpointIndex: number,
  metadata: Record<string, unknown> | undefined,
  turnId: string,
  allowGoalAnchor: boolean,
): CurrentTurnAnchor | undefined {
  const suffix = input.slice(checkpointIndex + 1).map(record);
  const invalidTrailingUserAfter = (index: number): boolean => suffix.slice(index + 1).some(item => {
    if (item?.type !== "message" || item.role !== "user") return false;
    const owner = itemTurnId(item);
    return (owner !== undefined && owner !== turnId)
      || !pureContextualUserMessage(item)
      || (Array.isArray(item.content) && item.content.some(goalContextPart));
  });
  const invalidPassiveTrailingUserAfter = (index: number): boolean => suffix.slice(index + 1).some(item => (
    item?.type === "message" && item.role === "user" && !isPassiveCurrentContextualContinuation(item, turnId)
  ));
  const ordinaryIndex = suffix.findLastIndex(item => (
    isCurrentTurnInstructionCandidate(item, metadata, turnId) && !hasGoalContextAttempt(item)
  ));
  if (ordinaryIndex >= 0) {
    if (invalidTrailingUserAfter(ordinaryIndex)) return undefined;
    const ordinaryAnchor = rolloutAnchor(suffix[ordinaryIndex]);
    if (ordinaryAnchor) return ordinaryAnchor;
  }

  const modelSwitchIndex = suffix.findLastIndex(item => modelSwitchMessage(item, turnId));
  if (modelSwitchIndex >= 0 && !invalidPassiveTrailingUserAfter(modelSwitchIndex)) {
    const modelSwitchAnchor = rolloutAnchor(suffix[modelSwitchIndex]);
    if (modelSwitchAnchor) return modelSwitchAnchor;
  }

  const goal = allowGoalAnchor ? goalContinuationBoundary(suffix, metadata, turnId) : undefined;
  if (goal) {
    const goalAnchor = rolloutAnchor(suffix[goal.index]);
    if (goalAnchor) return goalAnchor;
  }

  const currentUserMessages = suffix.filter(item => {
    if (item?.type !== "message" || item.role !== "user" || typeof item.id !== "string" || !item.id) return false;
    const owner = itemTurnId(item);
    return owner === undefined || owner === turnId;
  });
  if (currentUserMessages.length === 0
    || !currentUserMessages.every(item => isPassiveCurrentContextualContinuation(item, turnId))) return undefined;
  return rolloutAnchor(currentUserMessages.at(-1));
}

function goalContextPart(value: unknown): boolean {
  const part = record(value);
  if ((part?.type !== "input_text" && part?.type !== "text") || typeof part.text !== "string") return false;
  const text = part.text.trim();
  return isSingleEnvelope(
    text,
    /^<codex_internal_context source="goal">[\s\S]*<\/codex_internal_context>$/,
    /<\/?codex_internal_context(?:\s+source="[a-z][a-z0-9_]*")?>/g,
  ) || isSingleEnvelope(text, /^<goal_context>[\s\S]*<\/goal_context>$/i, /<\/?goal_context>/gi);
}

function goalContextAttemptPart(value: unknown): boolean {
  const part = record(value);
  if ((part?.type !== "input_text" && part?.type !== "text") || typeof part.text !== "string") return false;
  const text = part.text.trim();
  return /^<\/?goal_context\b/i.test(text)
    || /^<codex_internal_context\b(?=[^>]*\bsource\s*=\s*(?:"goal"|'goal'|goal\b))/i.test(text)
    || /^<\/codex_internal_context\b/i.test(text);
}

function hasGoalContextAttempt(item: Record<string, unknown> | undefined): boolean {
  return item?.type === "message" && item.role === "user" && Array.isArray(item.content)
    && item.content.some(goalContextAttemptPart);
}

function goalContinuationBoundary(
  suffix: unknown[],
  metadata: Record<string, unknown> | undefined,
  turnId: string,
): { index: number } | undefined {
  const items = suffix.map(record);
  const goalIndexes = items.flatMap((item, index) => (
    itemTurnId(item) === turnId
      && item?.type === "message" && item.role === "user" && Array.isArray(item.content)
      && item.content.some(goalContextPart) ? [index] : []
  ));
  if (goalIndexes.length !== 1) return undefined;
  const goalIndex = goalIndexes[0]!;
  const goalContextCount = items.reduce((count, item) => count + (
    itemTurnId(item) === turnId
      && item?.type === "message" && item.role === "user" && Array.isArray(item.content)
      ? item.content.filter(goalContextPart).length : 0
  ), 0);
  if (goalContextCount !== 1) return undefined;
  let currentPrefixStarted = false;
  const validPrefix = items.slice(0, goalIndex + 1).every(item => {
    if (!item) return false;
    const owner = itemTurnId(item);
    if (owner !== turnId) {
      if (currentPrefixStarted) return false;
      if (owner !== undefined) return true;
      return item.type !== "message" && item.type !== "agent_message";
    }
    currentPrefixStarted = true;
    if (typeof item.id !== "string" || !item.id
      || item.type !== "message" || !Array.isArray(item.content) || item.content.length === 0) return false;
    if (item.role === "user") return item.content.every(singleContextualPart);
    return item.role === "developer" && item.content.every(part => {
      const content = record(part);
      return (content?.type === "input_text" || content?.type === "text") && typeof content.text === "string"
        && !/<\/?(?:environment_context|codex_internal_context)\b/i.test(content.text);
    });
  });
  const validTrailingHistory = items.slice(goalIndex + 1).every(item => {
    return !!item && typeof item.id === "string" && !!item.id
      && itemTurnId(item) === turnId
      && !isCurrentTurnInstruction(item, metadata, turnId)
      && (item.type !== "message" || item.role !== "user" || pureContextualUserMessage(item));
  });
  return validPrefix && validTrailingHistory ? { index: goalIndex } : undefined;
}

function latestCompactionIndex(input: unknown[]): number {
  let checkpointIndex = -1;
  for (let index = 0; index < input.length; index += 1) {
    const item = record(input[index]);
    const text = typeof item?.content === "string" ? item.content : Array.isArray(item?.content)
      ? item.content.map(part => record(part)?.text ?? "").join("\n") : "";
    if (item?.type === "compaction" || item?.type === "compaction_summary" || item?.type === "context_compaction"
      || (item?.role === "user" && isReadableCompactionSummaryText(text))) {
      checkpointIndex = index;
    }
  }
  return checkpointIndex;
}

function isAcceptedPostCompactionContext(parsed: CodexParsedRequest): boolean {
  const identity = extractChatGptTurnIdentity(parsed);
  if (!identity.turnId) return false;
  const body = record(parsed._rawBody);
  const input = Array.isArray(body?.input) ? body.input : [];
  const checkpointIndex = latestCompactionIndex(input);
  if (checkpointIndex < 0) return false;

  const metadata = codexTurnMetadataFromBody(parsed._rawBody);
  const suffix = input.slice(checkpointIndex + 1);
  const hasCurrentSteering = suffix.some(value => isCurrentTurnInstruction(record(value), metadata, identity.turnId!));
  const suffixUserMessages = suffix.flatMap(value => {
    const item = record(value);
    return item?.type === "message" && item.role === "user" ? [item] : [];
  });
  const currentEnvironmentClaimCount = suffixUserMessages.reduce((count, item) => count + (
    Array.isArray(item.content) ? item.content.filter(environmentContextPart).length : 0
  ), 0);
  const goalBoundary = goalContinuationBoundary(suffix, metadata, identity.turnId);
  // Goal-driven continuation has no ordinary user revision. Its current, server-owned environment
  // still proceeds only through the canonical rollout comparison in resolve().
  if (!hasCurrentSteering && currentEnvironmentClaimCount >= 1 && goalBoundary
    && !extractChatGptThreadSpawnLineage(parsed) && extractChatGptRootThreadMetadata(parsed)) return true;
  if (!hasCurrentSteering) return false;

  const aborted = new Set(priorAbortedTurnIds(parsed._rawBody, identity.turnId));
  const sourceBody = { ...body, input: input.slice(0, checkpointIndex) };
  return turnUserRevisionHistory(sourceBody).some(source => (
    source.turnId !== identity.turnId
    && (source.turnId === undefined || !aborted.has(source.turnId))
    && isAcceptedCompactionContinuation(parsed, identity, source)
  ));
}

function pathIdentity(value: string): string {
  const normalized = resolve(value);
  return process.platform === "win32" ? normalized.toLowerCase() : normalized;
}

function contains(root: string, path: string): boolean {
  const rel = relative(pathIdentity(root), pathIdentity(path));
  return rel === "" || (!rel.startsWith("..") && !isAbsolute(rel));
}

function absolutePaths(value: unknown, field: string): string[] {
  if (!Array.isArray(value) || value.length === 0 || value.some(path => typeof path !== "string" || !isAbsolute(path))) {
    throw new Error(`Invalid persisted ChatGPT thread ${field}`);
  }
  const unique = new Map<string, string>();
  for (const path of value.map(path => resolve(path as string))) {
    if (!unique.has(pathIdentity(path))) unique.set(pathIdentity(path), path);
  }
  return [...unique.values()];
}

function sandboxPolicy(value: unknown, roots: string[], writableRoots: string[]): ChatGptSandboxPolicy {
  const parsed = record(value);
  if (parsed?.type === "dangerFullAccess") {
    const rootIdentities = new Set(roots.map(pathIdentity));
    if (writableRoots.length !== roots.length || writableRoots.some(path => !rootIdentities.has(pathIdentity(path)))) {
      throw new Error("Invalid persisted ChatGPT danger-full-access roots");
    }
    return { type: "dangerFullAccess" };
  }
  if (parsed?.type === "workspaceWrite") {
    const policyRoots = absolutePaths(parsed.writableRoots, "workspace-write policy writable roots");
    const declared = new Set(policyRoots.map(pathIdentity));
    // Project membership is not the grant boundary: native Codex also authorizes
    // external output directories. Both persisted grant sets must agree exactly.
    if (typeof parsed.networkAccess !== "boolean" || policyRoots.length !== writableRoots.length
      || writableRoots.some(path => !declared.has(pathIdentity(path)))) {
      throw new Error("Invalid persisted ChatGPT workspace-write policy");
    }
    return { type: "workspaceWrite", writableRoots, networkAccess: parsed.networkAccess };
  }
  if (parsed?.type === "readOnly") {
    if (typeof parsed.networkAccess !== "boolean" || writableRoots.length !== 0) {
      throw new Error("Invalid persisted ChatGPT read-only policy");
    }
    return { type: "readOnly", networkAccess: parsed.networkAccess };
  }
  throw new Error("Invalid persisted ChatGPT sandbox policy");
}

function validateStoredEnvironment(value: unknown): StoredThreadEnvironment {
  const parsed = record(value);
  if (!parsed || typeof parsed.cwd !== "string" || !isAbsolute(parsed.cwd) || typeof parsed.updatedAt !== "number") {
    throw new Error("Invalid persisted ChatGPT thread environment");
  }
  const cwd = resolve(parsed.cwd);
  const roots = absolutePaths(parsed.roots, "roots");
  const writableRoots = Array.isArray(parsed.writableRoots) && parsed.writableRoots.length === 0
    ? []
    : absolutePaths(parsed.writableRoots, "writable roots");
  if (!roots.some(root => contains(root, cwd))) throw new Error("Persisted ChatGPT cwd is outside its roots");
  return {
    cwd,
    roots,
    writableRoots,
    sandboxPolicy: sandboxPolicy(parsed.sandboxPolicy, roots, writableRoots),
    updatedAt: parsed.updatedAt,
  };
}

function authority(environment: ChatGptTurnEnvironment, updatedAt: number): StoredThreadEnvironment {
  return {
    cwd: environment.cwd,
    roots: environment.roots,
    writableRoots: environment.writableRoots,
    sandboxPolicy: environment.sandboxPolicy,
    updatedAt,
  };
}

function sameAuthority(
  claim: ChatGptEnvironmentClaim, right: ChatGptTurnEnvironment, allowAdditionalWritableRoots: boolean,
  isVisualizationRoot: (path: string) => boolean,
): boolean {
  const left = claim.environment;
  const samePaths = (a: string[], b: string[]): boolean => {
    const expected = new Set(b.filter(path => !isVisualizationRoot(path)).map(pathIdentity));
    const actual = a.filter(path => !isVisualizationRoot(path));
    return actual.length === expected.size && actual.every(path => expected.has(pathIdentity(path)));
  };
  return pathIdentity(left.cwd) === pathIdentity(right.cwd)
    && right.roots.filter(path => !isVisualizationRoot(path)).every(path => left.roots.some(root => pathIdentity(root) === pathIdentity(path)))
    && left.roots.filter(path => !isVisualizationRoot(path)).every(path =>
      [...right.roots, ...right.writableRoots].some(root => pathIdentity(root) === pathIdentity(path)))
    // Filesystem envelopes can omit Codex's extra output directories. The current
    // native rollout remains the authority returned to the caller, never the claim.
    && (allowAdditionalWritableRoots || right.writableRoots.some(root => !right.roots.some(path => pathIdentity(path) === pathIdentity(root)))
      ? left.writableRoots.filter(path => !isVisualizationRoot(path))
        .every(path => right.writableRoots.some(root => pathIdentity(root) === pathIdentity(path)))
      : samePaths(left.writableRoots, right.writableRoots))
    && left.sandboxPolicy.type === right.sandboxPolicy.type
    // An envelope that does not state its network policy cannot contradict the rollout on it.
    && (left.sandboxPolicy.type === "dangerFullAccess" || !claim.statesNetworkAccess
      || (right.sandboxPolicy.type !== "dangerFullAccess"
        && left.sandboxPolicy.networkAccess === right.sandboxPolicy.networkAccess));
}

/**
 * Codex emits its trusted environment envelope when a task starts or its environment changes,
 * not on every follow-up. This store carries only that trusted authority across turns. Tool
 * declarations are always taken from the current request and are never persisted.
 */
export class ChatGptThreadEnvironmentStore {
  private loaded = false;
  private readonly threads = new Map<string, StoredThreadEnvironment>();
  private readonly codexHomes: readonly string[];

  constructor(
    private readonly path?: string,
    private readonly now: () => number = Date.now,
    private readonly codexHome: string = getCodexHome(),
    private readonly sqliteHome?: string,
    additionalCodexHomes?: readonly string[],
  ) {
    this.codexHomes = getTrustedCodexHomes(codexHome, additionalCodexHomes);
  }

  resolve(parsed: CodexParsedRequest): ChatGptTurnEnvironment {
    const identity = extractChatGptTurnIdentity(parsed);
    let initialClaim: ChatGptEnvironmentClaim | undefined;
    let directEnvironment: ChatGptTurnEnvironment | undefined;
    let directError: unknown;
    try {
      initialClaim = extractChatGptTurnEnvironmentClaim(parsed);
      directEnvironment = initialClaim.environment;
      if (this.codexHomes.length > 1
        || (directEnvironment.sandboxPolicy.type !== "dangerFullAccess" && !initialClaim.statesNetworkAccess)) {
        // With multiple registered Codex homes no envelope can establish its own
        // owner. An exact current native rollout must authenticate the request.
        directEnvironment = undefined;
        throw new MissingTrustedCodexEnvironmentError(
          this.codexHomes.length > 1 ? "current native task ownership" : "network access",
        );
      }
    } catch (error) {
      directError = error;
    }

    if (directError && !(directError instanceof MissingTrustedCodexEnvironmentError)) throw directError;
    if (!identity.threadId) {
      if (directEnvironment) return directEnvironment;
      throw directError;
    }

    const hasCurrentContext = hasCurrentChatGptEnvironmentContext(parsed);
    const lineage = extractChatGptThreadSpawnLineage(parsed);
    const currentCompaction = isChatGptCompactionContinuation(parsed);
    const postCompactionContext = !currentCompaction && isAcceptedPostCompactionContext(parsed);
    const body = record(parsed._rawBody);
    const input = Array.isArray(body?.input) ? body.input : [];
    const checkpointIndex = latestCompactionIndex(input);
    const metadata = codexTurnMetadataFromBody(body);
    const sourceBeforeCheckpoint = checkpointIndex >= 0
      ? [...input.slice(0, checkpointIndex)].reverse().find(value => isNativeInstruction(record(value), metadata))
      : undefined;
    const crossesForeignCompaction = checkpointIndex >= 0
      && itemTurnId(sourceBeforeCheckpoint) !== identity.turnId;
    const hasCurrentInstruction = !!identity.turnId
      && input.some(value => isCurrentTurnInstruction(record(value), metadata, identity.turnId!));
    const ordinaryContinuation = hasCurrentInstruction && !crossesForeignCompaction;
    const rootMetadata = extractChatGptRootThreadMetadata(parsed);
    const currentTurnAnchor = crossesForeignCompaction && !!identity.turnId && !currentCompaction && !postCompactionContext
      ? currentTurnRolloutAnchor(input, checkpointIndex, metadata, identity.turnId, !lineage && !!rootMetadata)
      : undefined;
    const historicalMessages = !hasCurrentContext && (lineage || rootMetadata)
      ? unattributedChatGptEnvironmentMessages(parsed) : undefined;
    const rolloutIdentity = lineage ?? rootMetadata;
    // Automatic compaction has a current turn_context; standalone compaction has only its
    // source turn_context. Either must be the latest native record, never an arbitrary ancestor.
    const compactionSourceTurnId = parsed._compactionRequest || parsed._localCompactionRequest
      ? extractChatGptCompactionSourceRevision(parsed).turnId : undefined;
    if (parsed._rawBody !== undefined && rolloutIdentity && identity.turnId) {
      const rollout = resolveCurrentCodexRolloutEnvironment({
        codexHome: this.codexHomes[0]!,
        additionalCodexHomes: this.codexHomes.slice(1),
        ...(this.sqliteHome ? { sqliteHome: this.sqliteHome } : {}),
        lineage: rolloutIdentity,
        turnId: identity.turnId,
        ...(compactionSourceTurnId ? { compactionSourceTurnId } : {}),
        ...(historicalMessages ? { historicalEnvironmentMessages: historicalMessages } : {}),
        ...(currentTurnAnchor ? { currentTurnAnchor } : {}),
        tools: effectiveChatGptToolPolicy(parsed).tools,
      });
      if (rollout) {
        let rolloutEnvironment = rollout.environment;
        const calendarDelta = hasCurrentContext && !currentCompaction
          ? extractChatGptCalendarEnvironmentDelta(parsed) : undefined;
        const currentClaims = hasCurrentContext ? extractChatGptContinuationEnvironmentClaims(parsed, !!calendarDelta) : [];
        const workspaceClaim = initialClaim ?? currentClaims.at(-1);
        // A full-access rollout without workspace_roots has no native restriction
        // on roots. The current same-cwd request may supply workspace context,
        // but the exact native owner and permission profile remain authoritative.
        if ((currentCompaction || postCompactionContext) && !rollout.workspaceRootsDeclared
          && rolloutEnvironment.sandboxPolicy.type === "dangerFullAccess"
          && workspaceClaim?.environment.sandboxPolicy.type === "dangerFullAccess"
          && environmentPathIdentity(workspaceClaim.environment.cwd) === environmentPathIdentity(rolloutEnvironment.cwd)) {
          rolloutEnvironment = {
            ...rolloutEnvironment,
            roots: [...workspaceClaim.environment.roots],
            writableRoots: [...workspaceClaim.environment.roots],
          };
        }
        const visualizationOwner = { thread_id: rolloutIdentity.threadId,
          ...("parentThreadId" in rolloutIdentity ? { parent_thread_id: rolloutIdentity.parentThreadId } : {}),
        };
        // Full-access context may list Codex's auxiliary visualization root absent from turn_context.
        const isVisualizationRoot = (path: string): boolean => rolloutEnvironment.sandboxPolicy.type === "dangerFullAccess"
          && isCurrentOrParentThreadVisualizationRoot(path, visualizationOwner, rollout.codexHome);
        if (calendarDelta && (rolloutEnvironment.sandboxPolicy.type !== "dangerFullAccess"
          || calendarDelta.workspaceRoots.some(roots => {
            const authoritative = new Set(rolloutEnvironment.roots.filter(path => !isVisualizationRoot(path)).map(environmentPathIdentity));
            const actual = roots.filter(path => !isVisualizationRoot(path));
            return actual.length !== authoritative.size || actual.some(root => !authoritative.has(root));
          }))) {
          throw new Error("Calendar environment delta conflicts with its current Codex rollout");
        }
        if (hasCurrentContext && !directEnvironment && !initialClaim && !currentCompaction && !postCompactionContext
          && ordinaryContinuation && !calendarDelta) {
          const firstInstruction = input.findIndex(value => isCurrentTurnInstruction(record(value), metadata, identity.turnId!));
          const hasLaterRefresh = input.slice(firstInstruction + 1).some(value => hasEnvironmentContextFragment(record(value)));
          // An earlier preamble separated by steering needs two attributed current instructions.
          // A later refresh uses the existing per-claim/current-rollout comparison instead.
          if (!hasLaterRefresh && !extractChatGptSteeringEnvironmentClaim(parsed)) {
            throw new MissingTrustedCodexEnvironmentError("cwd");
          }
        }
        const steering = !currentCompaction && !postCompactionContext && ordinaryContinuation
          && !!extractChatGptSteeringEnvironmentClaim(parsed);
        if (currentClaims.some(claim => !sameAuthority(claim, rolloutEnvironment,
          steering || (initialClaim !== undefined && !initialClaim.statesNetworkAccess), isVisualizationRoot))) {
          throw new Error(`${steering ? "Steering" : "Compaction continuation"} environment conflicts with its current Codex rollout`);
        }
        if ((hasCurrentContext || crossesForeignCompaction)
          && !currentCompaction && !postCompactionContext && !ordinaryContinuation
          && !currentTurnAnchor) throw new MissingTrustedCodexEnvironmentError("cwd");
        this.set(rolloutIdentity.threadId, rolloutEnvironment);
        return rolloutEnvironment;
      }
    }

    if (this.codexHomes.length > 1) {
      // Multiple registered owners must always have an exact current native
      // rollout. Historical envelopes, inherited permissions and cache entries
      // can never authorize a shared-home request.
      throw new Error("No current native Codex task proof in the trusted homes", { cause: directError });
    }
    if (directEnvironment) {
      this.set(identity.threadId, directEnvironment);
      return directEnvironment;
    }
    const missingEnvironment = directError as MissingTrustedCodexEnvironmentError;
    // Only a current native rollout can supersede an unrecognized historical envelope. Without
    // that proof, do not turn arbitrary history or an invalid update into cached authority.
    if (hasRawChatGptEnvironmentContext(parsed)) throw missingEnvironment;
    const sameThread = this.get(identity.threadId);
    if (sameThread) return {
      cwd: sameThread.cwd,
      roots: sameThread.roots,
      writableRoots: sameThread.writableRoots,
      sandboxPolicy: sameThread.sandboxPolicy,
      tools: effectiveChatGptToolPolicy(parsed).tools,
    };

    if (!lineage && identity.parentThreadId && identity.parentThreadId !== identity.threadId
      && !identity.agentName && !identity.subagentKind
      && this.inherit(identity.parentThreadId, identity.threadId)) {
      const inherited = this.get(identity.threadId);
      if (inherited) return {
        cwd: inherited.cwd,
        roots: inherited.roots,
        writableRoots: inherited.writableRoots,
        sandboxPolicy: inherited.sandboxPolicy,
        tools: effectiveChatGptToolPolicy(parsed).tools,
      };
    }
    if (!lineage) throw missingEnvironment;
    const parent = this.get(lineage.parentThreadId);
    if (!parent) throw missingEnvironment;
    if (lineage.sandboxType !== parent.sandboxPolicy.type) {
      throw new Error("ChatGPT Web subagent sandbox metadata conflicts with its trusted parent thread");
    }
    if (lineage.workspaceRoots.length > 0 && !lineage.workspaceRoots.some(root => contains(root, parent.cwd))) {
      throw new Error("ChatGPT Web subagent workspace metadata does not contain its trusted parent cwd");
    }
    if (lineage.workspaceRoots.some(root => !parent.roots.some(parentRoot => (
      contains(parentRoot, root) || contains(root, parentRoot)
    )))) {
      throw new Error("ChatGPT Web subagent workspace metadata conflicts with its trusted parent roots");
    }
    const inherited: ChatGptTurnEnvironment = {
      cwd: parent.cwd,
      roots: parent.roots,
      writableRoots: parent.writableRoots,
      sandboxPolicy: parent.sandboxPolicy,
      tools: effectiveChatGptToolPolicy(parsed).tools,
    };
    this.set(lineage.threadId, inherited);
    return inherited;
  }

  inherit(parentThreadId: string, childThreadId: string): boolean {
    const parent = this.get(parentThreadId);
    if (!parent) return false;
    this.setStored(childThreadId, { ...parent, updatedAt: this.now() });
    return true;
  }

  private get(threadId: string): StoredThreadEnvironment | undefined {
    if (this.codexHomes.length > 1) return undefined;
    this.load();
    let stored = this.threads.get(threadId);
    if (!stored) {
      this.load(true);
      stored = this.threads.get(threadId);
    }
    if (!stored) return undefined;
    if (this.now() - stored.updatedAt > THREAD_ENVIRONMENT_TTL_MS) {
      this.threads.delete(threadId);
      this.persist();
      return undefined;
    }
    return stored;
  }

  private set(threadId: string, environment: ChatGptTurnEnvironment): void {
    // A shared bridge must not persist authority that could be replayed by
    // another registered native home. Resolve the current rollout on each turn.
    if (this.codexHomes.length > 1) return;
    this.setStored(threadId, authority(environment, this.now()));
  }

  private setStored(threadId: string, environment: StoredThreadEnvironment): void {
    if (this.codexHomes.length > 1) return;
    this.load(true, true);
    this.threads.delete(threadId);
    this.threads.set(threadId, environment);
    while (this.threads.size > MAX_THREAD_ENVIRONMENTS) {
      const oldest = this.threads.keys().next().value as string | undefined;
      if (!oldest) break;
      this.threads.delete(oldest);
    }
    this.persist();
  }

  private load(refresh = false, verifiedEnvironment = false): void {
    if (this.loaded && !refresh) return;
    if (!this.path || !existsSync(this.path)) {
      this.loaded = true;
      return;
    }
    const invalidState = (reason: string) => new ChatGptWebAdapterError(
      `The saved Codex task environment file (thread-environments.json) ${reason}. `
      + "Its contents have not been overwritten. Start a fresh Codex task to supply its current workspace and permissions. "
      + "If that also fails, export Activity > Export safe log; do not delete your launcher settings.",
      { status: 409, errorType: "invalid_request_error", code: "thread_environment_state_invalid", retryable: false },
    );
    const source = readFileSync(this.path, "utf8");
    let decoded: unknown;
    try {
      decoded = JSON.parse(stripUtf8Bom(source));
    } catch {
      if (!verifiedEnvironment) throw invalidState("contains invalid JSON");
      // Preserve the original for diagnosis. Never infer permissions from a damaged cache,
      // discard an unfamiliar schema, or turn a read/rename permission error into recovery.
      if (readFileSync(this.path, "utf8") !== source) throw invalidState("changed during recovery");
      const backup = `${this.path}.corrupt-${crypto.randomUUID()}`;
      renameSync(this.path, backup);
      console.warn("[chatgpt-web] preserved corrupt thread-environments.json beside the original; rebuilding from a verified current Codex environment");
      this.loaded = true;
      return;
    }
    const parsed = record(decoded);
    const rawThreads = record(parsed?.threads);
    if (parsed?.version !== 1 || !rawThreads) throw invalidState("has an unsupported or invalid format");
    let entries: Array<readonly [string, StoredThreadEnvironment]>;
    try {
      const cutoff = this.now() - THREAD_ENVIRONMENT_TTL_MS;
      entries = Object.entries(rawThreads)
        .map(([threadId, value]) => [threadId, validateStoredEnvironment(value)] as const)
        .filter(([, environment]) => environment.updatedAt >= cutoff)
        .sort((left, right) => left[1].updatedAt - right[1].updatedAt)
        .slice(-MAX_THREAD_ENVIRONMENTS);
    } catch {
      throw invalidState("contains invalid workspace or permission records");
    }
    for (const [threadId, environment] of entries) {
      const current = this.threads.get(threadId);
      if (!current || current.updatedAt < environment.updatedAt) this.threads.set(threadId, environment);
    }
    this.loaded = true;
  }

  private persist(): void {
    if (!this.path) return;
    const payload: StoredThreadEnvironmentFile = {
      version: 1,
      threads: Object.fromEntries(this.threads),
    };
    atomicWriteFile(this.path, `${JSON.stringify(payload, null, 2)}\n`, { durable: true });
  }
}
