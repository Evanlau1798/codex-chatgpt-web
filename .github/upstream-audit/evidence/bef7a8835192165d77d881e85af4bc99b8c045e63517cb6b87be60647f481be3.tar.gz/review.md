# v6.1.11 Upstream Integration Checkpoint Review

## 範圍與結論

- 候選：`G:\\codex-chatgpt-web\\tmp\\upstream-6.1.11\\candidate`
- 分支：`codex/upstream-6.1.11`
- B/HEAD：`7016a0cf8bf421ab4944f782ebf140ff93d1657f`
- U/MERGE_HEAD：`9fe005eefb93913c138368b0972b8a0c476fcf54`
- P：`8645a89e6a5fbe011e1bfbb0821a386ca7477ad5`
- 凍結 staged tree（依本 checkpoint 提供）：`7cb567083fb11e243e3512b6bcae9a39bfe462c8`
- 候選為 46 個 staged 檔案；相對 index 沒有 working-tree 差異。原始 capture 未修改。
- Upstream ledger 記錄 42 paths、117 hunks、39 test-case deltas，pending/missing 皆為 0；follow-up ledger 為空。v6.1.12 不在本次範圍。

**Finding：0 P0、0 P1、2 個 confirmed P2。** 這是唯讀 checkpoint 審查，不是 release 批准。以下為程式碼路徑確認；依要求沒有操作 runtime、發出 Web/live 請求或重跑測試，未做真實 launcher/Web 邊界重現。

## Findings

### P2 — Saved Chats 下 Enhanced output tunnel 仍被 Temporary Chat 專屬檢查拒絕

- **位置：** `src/adapters/chatgpt-web/browser-worker.ts:5405`
- **觸發：** `useSavedChats=true)，且 Enhanced Native2 turn 選用 tunneled output；啟動流程會用 saved-chat URL 準備頁面，但 tunnel 的 `observe` 仍呼叫 `isTemporaryChatGptTurnUrl(page.url())`。
- **證據：** Saved Chat 首頁 `https://chatgpt.com/` 和一般對話 `/c/<id>` 都不符合 Temporary Chat URL 判定；同一 turn 因而進入 `chatgptWebSurfaceError`。本輪在一般 response 路徑加入了 selected-surface 判定，但 tunnel observer 沒有同步。現有 Saved Chat 測試覆蓋 helper verification 和一般模式，未覆蓋 tunneled turn。
- **影響：** opt-in Saved Chats 的 tunneled Enhanced/Native2 turn 會在觀察階段失敗。
- **修正方向：** 讓 tunnel observer 與一般 response 路徑共用 selected-mode URL 驗證，保留 Temporary Chat 判定與 Saved Chat 的 origin/path 限制，補 Saved/Temporary tunnel 測試。
- **範圍註記：** 這個 Temporary-only guard 已存在於 B；本 finding 是候選仍保留的基線 caller 漏接，並非聲稱由 v6.1.11 hunk 新引入。

### P2 — 次要 trusted home 的合法 visualization root 以 primary home 驗證

- **位置：** `src/adapters/chatgpt-web/thread-environment.ts:523-524`
- **觸發：** 操作者註冊次要 Codex home；該 home 的 current native full-access turn 在請求環境列出其標準 `visualizations/YYYY/MM/DD/<threadId>` root，而最新 rollout 的 `workspace_roots` 未宣告它。
- **證據：** rollout resolver 在多個 trusted homes 中選出唯一 owner，但回傳的 `CodexRolloutEnvironment` 未保留 owner home；visualization predicate 因此固定使用 `this.codexHome`（primary）。次要 home 的精確 thread/date 路徑無法通過 `isCurrentOrParentThreadVisualizationRoot`，之後被 `sameAuthority` 當成未授權額外 root 拒絕。既有 visualization 測試驗證 primary-home 精確路徑及 foreign/descendant 路徑，但沒有 secondary-home 對應案例。
- **影響：** 有合法 visualization context 的次要 home turn 會在環境驗證失敗。
- **修正方向：** 保留 resolver 選出的 owner home，並以該 home 驗證精確 thread/date 格式；增加 secondary-home 精確路徑通過、foreign/descendant/outside-home 路徑仍拒絕的測試。不要放寬成一般額外 root。

## 其他已核對項目

- Trusted-home 設定是 operator 環境輸入；檢查 absolute/local/existing/non-symlink、canonical alias 去重、重複 thread ownership、每 home 的 SQLite 設定、shared mode 不讀寫單一 home cache，以及 DEV 移除 production registration。
- #847 compaction 適配要求 full access、同 cwd、當前 native proof 且 native roots 缺席；明確 roots、cwd、permissions、stale turn 均仍拒絕。v1/v2、shared/single 與負向案例都有映射；primary-home ordinary visualization bounds 保留。
- Saved Chats 的新/缺失設定維持 false、true 僅明確 opt-in；launcher refresh/helper IPC 傳遞所選模式，API Access 與 account inspection 仍走 Temporary Chat。匹配目標時不重複導航。
- Native2 public tool schema/description/revision/ABI hash 保持不變；token 使用 exact capability lookup，未知或截短 token 不借用唯一 active turn，錯誤提供 copy guidance 且不回顯 token。B 中 observer lease、steering、cancellation 的測試映射保留；沒有把 checkpoint 規則加入 public Native2 ABI。
- External WebContents cleanup 以精確 tab owner 收尾；multipart terminal error 在 MCP activity acknowledgement 前檢查；新增的 pending-group 路徑保留既有 acknowledgement/content/duplicate checks。無 runtime 證據證明真實 Electron Page.close 邊界。
- API diagnostics 新增欄位只記錄 bounded DOM 結構、actionability、座標/狀態與 frame count；不讀取文字、labels 或 identifiers，content-free verification 不啟用 interaction probe。
- 版本、README 變體、穩定 latest-release 連結與 installer 仍指向最後已發布的 Enhanced 版本一致。

## 證據與限制

已重用 checkpoint 證據，沒有重跑測試：upstream audit reconstruction 測試 PASS（838 assertions）；affected tests 225/0、environment tests 136/0、launcher tests 156/0；composition final 的剩餘案例 PASS；root/launcher typecheck 與隔離 runtime build 依 checkpoint 紀錄 PASS。RED/GREEN 失敗紀錄保留，未將早期失敗改寫成通過。

Lifecycle 證據尚不能視為 release gate 全綠：保留的早期紀錄有 Node 22.17.0 未達 Pi 要求 22.19.0；另有 shared test harness 替身造成的失敗，後續 composition 修補驗證不等於完整 release candidate gate。build smoke 仍由主代理處理中。release candidate 仍須依專案規則重新跑適用完整 gate；本報告不代替該 gate。
