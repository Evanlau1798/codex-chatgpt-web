# v6.1.11 Targeted Fix Review

## Verdict

Candidate `G:\codex-chatgpt-web\tmp\upstream-6.1.11\candidate` was reviewed read-only at `HEAD` `7016a0cf8bf421ab4944f782ebf140ff93d1657f`, with `MERGE_HEAD` `9fe005eefb93913c138368b0972b8a0c476fcf54`. The index cache-tree records `bfaeff19e6c222fb908dfbaf871e8f9695035027`; the working-tree diff is empty and all 49 changes remain staged.

The two P2 findings in `tmp/REVIEW-v6111.md` are fixed in the current staged candidate. No P0/P1 was found in these fixes or their trust boundaries. One adjacent, confirmed P2 remains in Saved Chat retry handling (below), so this checkpoint does not have zero remaining findings. This is a targeted review, not release approval.

## Confirmed findings

### P2 — Saved Chat route transition is rejected before a response retry

- **Location:** `src/adapters/chatgpt-web/browser-worker.ts:4898` (guard at 4895–4900).
- **Trigger:** Saved Chats is enabled, model/effort selection produces `mode.selection`, the turn starts at `https://chatgpt.com/`, the first submitted message changes the page to `/c/<id>`, and the first response enters the retry loop.
- **Evidence:** `selectModelAndEffort` records the current page URL in `mode.selection` (`browser-worker.ts:1687` or `1834`). The code itself documents the first Saved Chat message changing `/` to `/c/<id>` at 4854–4856. On retry, the guard accepts a changed route only when the old URL is a Temporary Chat URL and the new URL is a Temporary Chat turn URL (4895–4899); a normal Saved Chat root fails that condition. The newly added Saved Chat tunnel cases at `tests/browser-tunneled-fallback.test.ts:838–845` keep `initialRoute` and `conversationRoute` identical and do not exercise a retry. Existing retry coverage at 928–937 covers Temporary Chat only.
- **Impact:** An incomplete/empty first answer that would otherwise be retried can fail with `ChatGPT changed the selected model's browser surface before retry`, despite remaining in the same newly created Saved Chat. The failure is limited to this Saved Chat route-transition/retry combination.
- **Fix direction:** Extend the retry proof to recognize the selected Saved Chat root-to-new-conversation transition and re-prove the effort selection, while continuing to reject a change between already selected `/c/<id>` conversations. The mode-only URL predicate by itself does not prove conversation identity.
- **Evidence limit:** Confirmed by source control flow and the documented route transition; no live Web turn or test was run in this review.

## Prior findings confirmed fixed

### Saved Chat tunneled observation

`src/chatgpt-session.ts:153–161` adds a selected-mode URL predicate. Temporary mode delegates to the existing Temporary Chat turn validator; Saved mode requires the exact `https://chatgpt.com` origin, `/` or one `/c/<id>` segment, and excludes `temporary-chat=true`. Invalid URL parsing returns false. `browser-worker.ts:5403–5407` and `5572–5576` use this shared predicate in the tunneled and normal response observers. The error text includes only the selected mode and does not include the URL. The matrix covers valid Saved/Temporary pages, cross-mode flags, unrelated paths, deceptive origins, HTTP, and malformed input. The runBrowserTurn tests cover Saved home and conversation paths with one send and atomic final output.

### Visualization root from a secondary trusted Codex home

`codex-rollout-environment.ts:434–445` selects exactly one owner among configured homes and rejects duplicate ownership; at 474 it returns that verified `owner.home`. `thread-environment.ts:488–500, 519–547` uses the resolver result, then accepts a visualization path only for full-access rollout authority and only under that owner’s exact current/parent-thread `visualizations/YYYY/MM/DD/<threadId>` layout. Trusted homes are operator-registered and canonicalized in `src/codex-integration-shared.ts:269–293`; request paths do not register owners. The added tests accept legal secondary-home roots for root and child threads and reject foreign IDs, descendants, a primary-home substitute, and extra workspace roots. I found no authority widening in this change.

## Verification and limits

No source, index, commit, runtime, browser/Web session, or external service was changed or operated. No tests were run. I reused the supplied RED/GREEN/affected/typecheck evidence and read the current `codex-review-audit.log`, which reports the audit reconstruction test passing (1 test, 877 assertions). These results are not a substitute for a live browser check. The full final release gate remains pending after the 6.1.12 integration, as stated in the task; this review does not mark it green.
