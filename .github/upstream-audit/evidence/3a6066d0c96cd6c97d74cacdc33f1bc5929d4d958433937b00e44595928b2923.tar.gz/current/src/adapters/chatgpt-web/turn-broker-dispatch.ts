import type { CompactionTransactionStore } from "./compaction-transaction";
import type { TurnContextStore } from "./turn-context-store";
import {
  assertTurnActivityId,
  claimTurnActivity,
  completeTurnActivity,
} from "./turn-broker-completion";
import { dispatchExternalOwnerRequest, type TurnBrokerOwner } from "./turn-broker-owner";
import { scheduleToolWaiters } from "./turn-broker-queue";
import { subagentModelObservation } from "./mcp-observation";
import { scopeHash } from "./mcp-request-diagnostics";
import {
  assertSafeHarnessRunning,
  waitForSafeSent,
} from "./turn-broker-safe";
import {
  notifyCompactionDelivery,
  retiredTurnLabel,
  steeringResult,
  type TurnChannel,
} from "./turn-broker-state";
import {
  opaqueId,
  type BrokerRequest,
  type BrokerToolRequest,
  type BrokerToolResult,
} from "./turn-broker-protocol";
import { submitTurnOutput } from "./turn-broker-output";
import { readAgentWait, startAgentWait } from "./turn-broker-agent-wait";
import { assertRetirementFailure } from "./turn-broker-protocol";
import { chatGptToolTimeoutError } from "./adapter-error";
import { waitForTurnObserver } from "./turn-broker-observer";

interface DispatchState {
  acceptingExternalOwners(): boolean;
  bindings: Map<string, { token: string; channel: TurnChannel }>;
  channels: Map<string, TurnChannel>;
  compactionTransactions: CompactionTransactionStore;
  contexts: TurnContextStore;
  owner: TurnBrokerOwner;
  pending: Map<string, TurnChannel>;
  registerExternal: TurnBrokerOwner["register"];
  registerExternalSafe: TurnBrokerOwner["registerSafe"];
  retiredBindings: Map<string, import("./turn-broker-protocol").BrokerRetirementDiagnostics>;
  retiredTokens: Map<string, string>;
  startSafeTurn(requestId: string): { started: true; duplicate: boolean };
  completeSafeTurn(requestId: string, finalAnswer: string): { completed: true; duplicate: boolean };
}

export async function dispatchTurnBrokerRequest(
  request: BrokerRequest,
  signal: AbortSignal,
  state: DispatchState,
): Promise<unknown> {
  const { owner } = state;
  if (request.method === "safe_start") {
    if (!request.token) throw new Error("Zero Risk request_id is required");
    await waitForSafeSent(state.channels.get(request.token), signal);
    return state.startSafeTurn(request.token);
  }
  if (request.method === "safe_complete") {
    if (!request.token) throw new Error("Zero Risk request_id is required");
    if (typeof request.finalAnswer !== "string") throw new Error("Zero Risk turn final_answer is required");
    return state.completeSafeTurn(request.token, request.finalAnswer);
  }
  if (request.method.startsWith("owner_")) return dispatchExternalOwnerRequest(request, {
    accepting: state.acceptingExternalOwners,
    registerExternal: state.registerExternal,
    registerExternalSafe: state.registerExternalSafe,
    register: owner.register.bind(owner),
    registerSafe: owner.registerSafe.bind(owner),
    setObserverConnected: owner.setObserverConnected?.bind(owner),
    updateEnvironment: owner.updateEnvironment.bind(owner),
    confirmSafeTurnSent: owner.confirmSafeTurnSent.bind(owner),
    nextToolBatch: owner.nextToolBatch.bind(owner),
    completeTool: owner.completeTool.bind(owner),
    waitForSafeStart: owner.waitForSafeStart.bind(owner),
    waitForSafeCompletion: owner.waitForSafeCompletion.bind(owner),
    requestCompaction: owner.requestCompaction.bind(owner),
    compactionDeliveryCount: owner.compactionDeliveryCount.bind(owner),
    beginCompletionFence: owner.beginCompletionFence.bind(owner),
    commitCompletionFence: owner.commitCompletionFence.bind(owner),
    beginFinalizationOnly: owner.beginFinalizationOnly.bind(owner),
    cancelFinalizationOnly: owner.cancelFinalizationOnly.bind(owner),
    armFinalizationOutput: owner.armFinalizationOutput.bind(owner),
    nextOutput: owner.nextOutput.bind(owner),
    resetOutput: owner.resetOutput.bind(owner),
    sealOutput: owner.sealOutput.bind(owner),
    waitForRetirement: owner.waitForRetirement.bind(owner),
    revoke: owner.revoke.bind(owner),
  }, signal);
  if (request.method === "submit_compaction_handoff" || request.method === "submit_recovery_checkpoint") {
    if (typeof request.token !== "string" || request.token.length === 0) throw new Error("compaction control token is required");
    if (typeof request.handoffId !== "string" || request.handoffId.length === 0) throw new Error("compaction handoff id is required");
    if (typeof request.summary !== "string") throw new Error("compaction handoff summary is required");
    state.compactionTransactions.submit(request.token, request.handoffId, request.summary,
      request.method === "submit_recovery_checkpoint" ? "recovery" : "compaction");
    return { submitted: true };
  }
  if (request.method === "submit_output") {
    if (!request.token) throw new Error("Codex Native output turn token is required");
    if (typeof request.outputText !== "string") throw new Error("Codex Native output text is required");
    const channel = state.channels.get(request.token);
    if (!channel) throw new Error("turn token is invalid, expired, or revoked");
    const activityRevision = channel.activityRevision;
    await waitForTurnObserver(channel, signal);
    if (state.channels.get(request.token) !== channel) throw new Error("turn token is invalid, expired, or revoked");
    let submitted: ReturnType<typeof submitTurnOutput>;
    try {
      if (request.outputKind === "final" && state.contexts.hasIncomplete(request.token)) {
        throw new Error("Read and verify the complete Codex context archive before submitting final output");
      }
      if (request.outputKind === "final" && activityRevision !== channel.activityRevision
        && !channel.steeringInstruction && channel.outputFinalSequence === undefined) {
        return { accepted: false, reason: "steering", instruction:
          "This final attempt was overtaken by Native turn activity or reconnection and was not accepted. Apply the latest instruction already delivered to this turn, then submit the updated complete answer." };
      }
      submitted = submitTurnOutput(channel, request.outputKind!, request.outputText, request.nextMessagePrediction);
      if ("steering" in submitted) {
        console.info(`[chatgpt-web] broker trace=${channel.traceId} delivered queued native steering through output control`);
        return { accepted: false, reason: "steering", instruction:
          `A new user instruction arrived. Continue any unfinished work with this update, then submit the complete final answer:\n\n${submitted.steering}` };
      }
    } catch (error) {
      const kind = ["commentary", "reasoning", "final"].includes(request.outputKind!) ? request.outputKind : "invalid";
      try {
        console.warn(`[chatgpt-web] broker trace=${channel.traceId} output rejected kind=${kind} chars=${request.outputText.length}`
        + ` activeActivities=${channel.activities.size} pendingTools=${channel.invocations.size} finalizationOnly=${channel.finalizationOnly}`
        + ` outputSealed=${channel.outputSealed} finalAccepted=${channel.outputFinalSequence !== undefined}`
        + ` contextIncomplete=${state.contexts.hasIncomplete(request.token)} referenceHash=${scopeHash(request.token)}`);
      } catch { /* Preserve the original validation failure. */ }
      throw error;
    }
    try {
      console.info(`[chatgpt-web] broker trace=${channel.traceId} output accepted kind=${submitted.event.kind}`
      + ` sequence=${submitted.event.sequence} chars=${submitted.event.text.length} duplicate=${submitted.duplicate}`
      + ` referenceHash=${scopeHash(request.token)}`);
    } catch { /* An accepted output must keep its acknowledgement. */ }
    return { accepted: true, sequence: submitted.event.sequence, duplicate: submitted.duplicate };
  }
  if (request.method === "read_context") {
    if (typeof request.token !== "string" || request.token.length === 0) throw new Error("context token is required");
    return state.contexts.read(request.token, request.index, request.chunkChars, state.channels);
  }
  if (request.method === "read_output_control") {
    const channel = request.token ? state.channels.get(request.token) : undefined;
    if (!channel || (channel.environment.expiresAt !== undefined && channel.environment.expiresAt <= Date.now())
      || channel.completionCommitted || channel.outputSealed
      || channel.safe || !channel.outputEnabled) {
      throw new Error("output control is unavailable for this turn");
    }
    // Schema discovery is not work: no activity, task data, work reopening,
    // or mutation of the finalization/completion revision.
    return { outputEnabled: true, finalizationOnly: channel.finalizationOnly,
      ...(channel.predictionEnabled ? { predictionEnabled: true } : {}) };
  }
  if (request.method === "read_agent_wait") {
    const channel = request.token ? state.channels.get(request.token) : undefined;
    if (!channel || channel.completionCommitted) throw new Error("turn token is invalid, expired, or revoked");
    return readAgentWait(channel, request.waitId);
  }
  if (request.method === "claim") return claim(request, signal, state);
  if (request.method === "activity_complete") {
    if (typeof request.token !== "string" || request.token.length === 0) throw new Error("turn token is required");
    assertTurnActivityId(request.activityId);
    const channel = state.channels.get(request.token);
    if (!channel) return { completed: false, retired: state.retiredTokens.has(request.token) };
    if (channel.completedActivities.has(request.activityId)) return { completed: false, duplicate: true };
    return { completed: completeTurnActivity(channel, request.activityId) };
  }
  return invoke(request, state, signal);
}

async function claim(request: BrokerRequest, signal: AbortSignal, state: DispatchState): Promise<unknown> {
  const contract = request.contract ?? "native";
  const token = request.token;
  if (typeof token !== "string" || token.length === 0) {
    throw new Error(contract === "safe" ? "request id is required" : "turn token is required");
  }
  const channel = state.channels.get(token);
  let activeChannel = channel && !channel.completionCommitted ? channel : undefined;
  const retiredTurn = channel?.completionCommitted ? channel.traceId : state.retiredTokens.get(token);
  try {
    console.error(
    `[chatgpt-web] broker claim received (tokenChars=${token.length}, valid=${Boolean(activeChannel)}`
    + `${activeChannel ? "" : `, retiredTurn=${retiredTurn ?? "unknown"}`})`
    + ` referenceHash=${token.length <= 256 ? scopeHash(token) : "oversized"}${activeChannel ? ` trace=${activeChannel.traceId}` : ""}`,
  );
  } catch { /* Diagnostics cannot reject a valid claim. */ }
  if (!activeChannel) {
    throw new Error(retiredTurn !== undefined
      ? `This turn_token was issued for ${retiredTurnLabel(retiredTurn)}, which has already finished.`
      + " This Codex Native action can no longer run."
      : "turn token is invalid, expired, or revoked");
  }
  await waitForTurnObserver(activeChannel, signal);
  if (state.channels.get(token) !== activeChannel) throw new Error("turn token is invalid, expired, or revoked");
  if (activeChannel.finalizationOnly) {
    throw new Error("Codex Native work tools are closed during final-answer recovery; call codex.control.output with kind=final");
  }
  if (activeChannel.safe) {
    if (contract !== "safe") throw new Error("Zero Risk request id requires the Zero Risk MCP contract");
    if (activeChannel.safe.state === "awaiting_start" && !activeChannel.safe.launcherSent) {
      await waitForSafeSent(activeChannel, signal);
      activeChannel = state.channels.get(token);
      if (!activeChannel || activeChannel.completionCommitted) throw new Error("turn token is invalid, expired, or revoked");
    }
    assertSafeHarnessRunning(activeChannel);
  } else if (contract === "safe") {
    throw new Error("Zero Risk MCP contract requires a Zero Risk request id");
  }
  assertTurnActivityId(request.activityId);
  if (activeChannel.outputSealed) {
    throw new Error("Codex Native work cannot start after DOM fallback was sealed");
  }
  if (activeChannel.outputFinalSequence !== undefined) {
    throw new Error("Codex Native work cannot start while the final answer is pending");
  }
  claimTurnActivity(activeChannel, request.activityId);
  if (state.contexts.hasIncomplete(token)) {
    throw new Error("Read and verify the complete Codex context archive before calling work tools");
  }
  if (activeChannel.bindingId) {
    const existing = state.bindings.get(activeChannel.bindingId);
    if (!existing || existing.token !== token || existing.channel !== activeChannel) {
      throw new Error("turn token binding state is inconsistent");
    }
    return { bindingId: activeChannel.bindingId, activityId: request.activityId, environment: activeChannel.environment };
  }
  state.pending.delete(token);
  const bindingId = opaqueId("binding");
  activeChannel.bindingId = bindingId;
  state.bindings.set(bindingId, { token, channel: activeChannel });
  return { bindingId, activityId: request.activityId, environment: activeChannel.environment };
}

function invoke(request: BrokerRequest, state: DispatchState, signal?: AbortSignal): unknown {
  signal?.throwIfAborted();
  const bindingId = request.bindingId;
  if (typeof bindingId !== "string" || bindingId.length === 0) throw new Error("binding id is required");
  const binding = state.bindings.get(bindingId);
  if (!binding) {
    const retiredTurn = state.retiredBindings.get(bindingId);
    if (request.method === "release" && retiredTurn !== undefined) {
      if (request.failure !== undefined) assertRetirementFailure(request.failure);
      return { released: true, duplicate: true, ...(request.failure === undefined ? {} : { diagnostics: retiredTurn }) };
    }
    console.error(`[chatgpt-web] broker rejected ${request.method} (binding=${bindingId.slice(0, 17)}, retiredTurn=${retiredTurn ?? "unknown"})`);
    throw new Error(retiredTurn !== undefined
      ? `${retiredTurnLabel(retiredTurn.traceId)} has already finished; this Codex Native action can no longer run.`
      : "internal Codex turn binding is invalid or expired");
  }
  if (request.method === "release") {
    if (request.failure !== undefined) {
      assertRetirementFailure(request.failure);
      state.owner.revoke(binding.token, chatGptToolTimeoutError(request.failure.tool, request.failure.timeoutMs), request.failure);
    } else {
      state.owner.revoke(binding.token);
    }
    return { released: true, ...(request.failure === undefined ? {} : { diagnostics: state.retiredBindings.get(bindingId)! }) };
  }
  if (request.method === "resolve") return { environment: binding.channel.environment };
  if (binding.channel.observerPause) {
    return waitForTurnObserver(binding.channel, signal).then(() => invoke(request, state, signal));
  }
  assertSafeHarnessRunning(binding.channel);
  if (binding.channel.outputSealed) {
    throw new Error("Codex Native work cannot start after DOM fallback was sealed");
  }
  if (binding.channel.finalizationOnly) {
    throw new Error("Codex Native work tools are closed during final-answer recovery; call codex.control.output with kind=final");
  }
  if (binding.channel.outputFinalSequence !== undefined) {
    throw new Error("Codex Native work cannot start while the final answer is pending");
  }
  if (request.method === "start_agent_wait") {
    return startAgentWait(binding.channel, request.wireName, request.arguments,
      tool => invoke({ id: request.id, method: "invoke", bindingId, ...tool }, state) as Promise<BrokerToolResult> | BrokerToolResult,
      error => state.owner.revoke(binding.token, error));
  }
  if (binding.channel.compactionRequested) {
    const result = binding.channel.compactionResult;
    if (!result) throw new Error("Codex context compaction control result is unavailable");
    binding.channel.compactionDeliveryCount += 1;
    notifyCompactionDelivery(binding.channel);
    return structuredClone(result);
  }
  if (binding.channel.steeringInstruction) {
    const instruction = binding.channel.steeringInstruction;
    binding.channel.steeringInstruction = undefined;
    console.info(`[chatgpt-web] broker trace=${binding.channel.traceId} delivered queued native steering through the tool loop`);
    return steeringResult(instruction);
  }
  const wireName = request.wireName?.trim();
  if (!wireName) throw new Error("wire tool name is required");
  const callId = opaqueId("call");
  const toolRequest: BrokerToolRequest = {
    callId,
    wireName,
    freeform: request.freeform === true,
    ...(Number.isFinite(request.invokeDeadlineAt) ? { invokeDeadlineAt: request.invokeDeadlineAt } : {}),
    ...(request.freeform === true ? { input: request.input ?? "" } : { arguments: request.arguments ?? {} }),
  };
  return new Promise<BrokerToolResult>((resolve, reject) => {
    binding.channel.invocations.set(callId, { request: toolRequest, queuedAt: performance.now(), resolve, reject });
    binding.channel.queuedCallIds.push(callId);
    console.info(`[chatgpt-web] broker trace=${binding.channel.traceId} queued call=${callId.slice(0, 17)} tool=${wireName} waiters=${binding.channel.waiters.size}`);
    const modelObservation = !toolRequest.freeform && subagentModelObservation(wireName, toolRequest.arguments);
    if (modelObservation) console.info(`[chatgpt-web] subagent_model_requested ${JSON.stringify({
      traceId: binding.channel.traceId, callId: callId.slice(0, 17), tool: wireName, ...modelObservation,
    })}`);
    scheduleToolWaiters(binding.channel);
  });
}
