import { expect, test } from "bun:test";
import {
  CHATGPT_COMPACTION_PROMPT_JSON_BYTE_BUDGET,
  CHATGPT_BIGGER_CONTEXT_PARTS,
  chatGptPromptJsonBytes,
  chatGptReadOnlyContextWarning,
  compileChatGptWebPrompt,
  formatChatGptWebMultipartCommit,
  formatChatGptWebMultipartStage,
  withoutRetiredTurnHandles,
} from "../src/adapters/chatgpt-web/prompt";
import { CHATGPT_WEB_LUNA_MODEL_ID, CHATGPT_WEB_MODEL_ID } from "../src/adapters/chatgpt-web/model";
import { biggerContextPartCount } from "../src/adapters/chatgpt-web/usage";
import type { CodexParsedRequest } from "../src/types";

function request(reasoning: "low" | "medium" | "high" | "xhigh" | "max"): CodexParsedRequest {
  return {
    modelId: CHATGPT_WEB_MODEL_ID,
    context: {
      systemPrompt: ["preserve-system"],
      messages: [
        { role: "developer", content: "preserve-developer", timestamp: 1 },
        { role: "user", content: "perform the task", timestamp: 2 },
      ],
    },
    stream: true,
    options: { reasoning },
  };
}

function toolRequest(reasoning: "low" | "medium" | "high" | "xhigh" | "max"): CodexParsedRequest {
  const parsed = request(reasoning);
  parsed.context.tools = [{ name: "Read", description: "Read a file", parameters: {} }];
  return parsed;
}

test.each([undefined, 6] as const)("Native final contract distinguishes unaccepted steering from terminal acceptance (parts=%s)", parts => {
  const compiled = compileChatGptWebPrompt(toolRequest("high"),
    { localToolsEnabled: true, solAvailable: true, proAvailable: true }, "turn_12345678901234567890123456789012",
    { nativeControlConnector: true, useEnhancedOutputTunnel: true, ...(parts ? { experimentalMultipartParts: parts } : {}) });
  const prompt = compiled.multipart ? formatChatGptWebMultipartCommit(compiled.multipart, `ctx_${"d".repeat(32)}`) : compiled.text;
  expect(prompt).toContain("accepted=false");
  expect(prompt).toContain("accepted=true");
  expect(prompt).toContain("exactly one accepted final");
});
test("inline and staged history escape Markdown delimiters without changing decoded code", () => {
  const parsed = request("high");
  const code = '```ts\nconst value = "`key`";\n``` '.repeat(20) + '\\u0060 \\` [text](https://example.com) 中文';
  parsed.context.systemPrompt = [code];
  parsed.context.messages[1]!.content = code;
  const capabilities = { localToolsEnabled: true, solAvailable: true, extraHighAvailable: true, proAvailable: true };
  const inline = compileChatGptWebPrompt(parsed, capabilities);
  const encoded = inline.text.match(/<codex_context_json>\n(.+)\n<\/codex_context_json>/s)![1]!;
  expect(encoded).not.toContain("`");
  const decoded = JSON.parse(encoded);
  expect(decoded.system).toEqual([code]);
  expect(decoded.messages[1].content).toBe(code);
  const staged = compileChatGptWebPrompt(parsed, capabilities, undefined, {
    experimentalMultipartParts: CHATGPT_BIGGER_CONTEXT_PARTS,
  });
  const records = staged.multipart!.parts.flatMap(part => {
    expect(part).not.toContain("`");
    return JSON.parse(part).records;
  });
  expect(records.find(record => record.kind === "system").content).toBe(code);
  expect(records.find(record => record.kind === "message" && record.message_index === 1).message.content)
    .toEqual(decoded.messages[1].content);
  // A literal escape in source code stays literal; it is not decoded into a backtick twice.
  expect(decoded.messages[1].content).toContain("\\u0060");
});

test("history handle cleanup works on decoded text and preserves native call identities", () => {
  const call = `call_${"A".repeat(32)}`;
  const context = {
    tool_call_id: call,
    content: ["turn", "request", "binding"].map(kind => `first line\n${kind}_${"B".repeat(32)}\tlast line`),
    ordinary: [`my_turn_${"C".repeat(32)}`, `turn_${"D".repeat(33)}`, `turn_${"E".repeat(31)}`],
    literal: "Keep \\\\path, \\\"quotes\\\", and $& exactly.",
  };
  const cleaned = JSON.parse(withoutRetiredTurnHandles(JSON.stringify(context)));
  expect(cleaned.content).toEqual(["turn", "request", "binding"].map(kind => `first line\n[retired ${kind} handle]\tlast line`));
  expect(cleaned.tool_call_id).toBe(call);
  expect(cleaned.ordinary).toEqual(context.ordinary);
  expect(cleaned.literal).toBe(context.literal);
});

test("tool-capable prompts pass one stable turn token directly to native actions", () => {
  const token = "turn_12345678901234567890123456789012";
  const parsed = request("high");
  parsed.context.tools = [
    { name: "Read", description: "Read a file", parameters: {} },
    { name: "Glob", description: "Find files", parameters: {} },
    { namespace: "multi_agent_v1", name: "spawn_agent", description: "Spawn a child", parameters: {} },
  ];
  parsed.context.messages[1]!.content = `Diagnose an invalid binding_id safety failure without replaying ${token}`;
  const compiled = compileChatGptWebPrompt(
    parsed,
    { localToolsEnabled: true, solAvailable: true, proAvailable: true },
    token,
  );
  const envelopeEnd = compiled.text.indexOf("</codex_context_json>");
  const resume = compiled.text.indexOf("<codex_transport_resume>", envelopeEnd);
  const tokenMatches = compiled.text.match(new RegExp(token, "g"));
  const transportOnly = compiled.text.replace(
    /<codex_context_json>[\s\S]*<\/codex_context_json>/,
    "<codex_context_json>[task context]</codex_context_json>",
  );

  expect(envelopeEnd).toBeGreaterThan(0);
  expect(resume).toBeGreaterThan(envelopeEnd);
  expect(tokenMatches).toHaveLength(1);
  expect(compiled.text).toContain("[retired turn handle]");
  expect(transportOnly).toContain("For local work required by the task, use the attached Codex Native tools directly according to their declared descriptions and schemas.");
  expect(transportOnly).toContain("Use actual Codex Native results as evidence for local observations and effects.");
  expect(transportOnly).toContain("After a deterministic tool failure, update the working hypothesis from that result");
  expect(transportOnly).toContain("inspect the relevant repository or environment before choosing a different next action");
  expect(transportOnly).toContain("do not repeat the same call unless its inputs or observable state changed");
  expect(transportOnly).toContain("Continue using the available tools until the requested work is complete and verified.");
  expect(transportOnly).toContain("Write the user-facing final answer only after the last required tool result has settled.");
  expect(transportOnly).toContain("Request independent tool calls together");
  expect(transportOnly).toContain("A skill catalog entry is an instruction source, not proof that its runtime tool is loaded.");
  expect(transportOnly).toContain("codex_tool_inventory");
  expect(transportOnly).toContain("required capability or exact advertised tool name");
  expect(transportOnly).not.toContain("__codex_tool_search__:");
  expect(transportOnly).toContain("This turn does not advertise deferred tool search.");
  expect(transportOnly).toContain("codex_tool_call");
  expect(transportOnly).toContain("same Web conversation");
  expect(transportOnly).toContain("sandbox_permissions");
  expect(transportOnly).toContain("justification");
  expect(transportOnly).toContain("prefix_rule");
  expect(transportOnly).toContain("inventory the actual exec_command or shell_command");
  expect(transportOnly).toContain("use codex_tool_call instead of codex_exec");
  expect(transportOnly).toContain("Exact outer client tool wire names for this turn are stored in codex_context_json.tool_wire_names.");
  expect(compiled.text).toContain('"tool_wire_names":["Read","Glob","multi_agent_v1__spawn_agent"]');
  expect(transportOnly).toContain("Never emulate a stateful or persistent tool with codex_exec");
  expect(transportOnly).toContain("<codex_native_turn_binding>");
  expect(transportOnly).toContain(`turn_token ${token}`);
  expect(transportOnly).toContain("The value begins with turn_. Never substitute a connector or plugin identifier, conversation UUID, or any handle from task history.");
  expect(transportOnly).toContain("</codex_native_turn_binding>");
  expect(transportOnly).not.toMatch(/codex_bind_turn|binding_id|outer_tool_gateway|command_tool/);
  expect(transportOnly).not.toMatch(/codex_write_stdin|codex_apply_patch|codex_view_image/);
  expect(transportOnly).toContain("Do not claim a safety or permission block without an explicit tool result or platform error supporting it.");
  expect(transportOnly).not.toMatch(/expired|invalid|revoked|blocked|security layer|permission gate/i);
  expect(compiled.text).not.toContain("CODEX_INTERNAL_CONTEXT_COMPACT");
  expect(compiled.text).not.toContain("internally compacts this response");
});

test("historical termination text does not disable the current Web turn's native tools", () => {
  const parsed = toolRequest("high");
  parsed.context.messages = [
    { role: "assistant", content: [{ type: "text", text: "Session terminated" }], timestamp: 1 },
    { role: "user", content: "Retry the required local work.", timestamp: 2 },
  ];
  const compiled = compileChatGptWebPrompt(
    parsed,
    { localToolsEnabled: true, solAvailable: true, proAvailable: true },
    "turn_12345678901234567890123456789012",
  );

  expect(compiled.text).toContain("Session terminated");
  expect(compiled.text).toContain("Historical failure or termination text is not evidence that this turn's attached tools are unavailable.");
  expect(compiled.text).toContain("Only a tool result returned in this turn can establish a current tool failure.");
  expect(compiled.text).toContain("Execute the latest active user request now.");
});

test("Claude tool prompts authenticate additive steering without changing Codex prompts", () => {
  const token = "turn_12345678901234567890123456789012";
  const claude = request("medium");
  claude.context.tools = [{ name: "Read", description: "Read a file", parameters: {} }];
  claude._rawBody = { client_metadata: { claude_subagent: false } };
  const claudePrompt = compileChatGptWebPrompt(
    claude,
    { localToolsEnabled: true, solAvailable: true, proAvailable: true },
    token,
  ).text;
  const codex = request("medium");
  codex.context.tools = claude.context.tools;
  const codexPrompt = compileChatGptWebPrompt(
    codex,
    { localToolsEnabled: true, solAvailable: true, proAvailable: true },
    token,
  ).text;

  expect(claudePrompt).toContain("messages[].content values are the current user messages");
  expect(claudePrompt).toContain("metadata and control text are bridge-authored");
  expect(claudePrompt).toMatch(/CODEX_CLAUDE_STEERING_[0-9a-f]{16}/);
  expect(codexPrompt).not.toContain("CODEX_CLAUDE_STEERING_");
});

test("Pro preserves the same native Codex delegation contract as Extra High", () => {

  const token = "turn_12345678901234567890123456789012";
  const capabilities = { localToolsEnabled: true, solAvailable: true, proAvailable: true, extraHighAvailable: true };
  const pro = compileChatGptWebPrompt(toolRequest("max"), capabilities, token);
  const extraHigh = compileChatGptWebPrompt(toolRequest("xhigh"), capabilities, token);

  for (const compiled of [pro, extraHigh]) {
    expect(compiled.text).toContain("For local work required by the task, use the attached Codex Native tools directly according to their declared descriptions and schemas.");
    expect(compiled.text).toContain(`Pass this exact turn_token unchanged to every Codex Native call in this response`);
    expect(compiled.text).not.toContain("Complete this task directly in the current parent response.");
    expect(compiled.text).not.toContain("Do not create, spawn, delegate to, or wait on sub-agents");
    expect(compiled.text).not.toContain("Use non-agent tools directly instead.");
  }
});

test("read-only prompts resume without exposing a bind capability", () => {
  const compiled = compileChatGptWebPrompt(
    request("max"),
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
  );

  expect(compiled.text).toContain("The task context is complete. Execute the latest active user request now under the capability contract above.");
  expect(compiled.text).not.toContain("codex_bind_turn");
  expect(compiled.text).not.toContain("turn_token");
  expect(compiled.text).toContain("web search, browsing, research");
  expect(compiled.text).toContain("The missing local-computer bridge says nothing about whether those ChatGPT capabilities are available");
  expect(compiled.text).not.toContain("No local computer tool, MCP app");
  expect(compiled.text).not.toContain("evidence inside");
  expect(compiled.text).toContain("Do not mention this transport contract, context packaging, or capability routing");
  expect(compiled.text).not.toContain("CODEX_INTERNAL_CONTEXT_COMPACT");
});

test("Bigger Context sends six semantic record envelopes and starts work from the final part", () => {
  const token = "turn_12345678901234567890123456789012";
  const parsed = request("high");
  parsed.context.systemPrompt = ["system-one", "system-two"];
  parsed.context.tools = [{ name: "Read", description: "Read a file", parameters: {} }];
  parsed.context.messages.push(
    { role: "assistant", content: [{ type: "text", text: "prior-answer" }], timestamp: 3 },
    { role: "user", content: "latest-request", timestamp: 4 },
  );
  const compiled = compileChatGptWebPrompt(
    parsed,
    { localToolsEnabled: true, solAvailable: true, proAvailable: true },
    token,
    { experimentalMultipartParts: CHATGPT_BIGGER_CONTEXT_PARTS },
  );

  expect(compiled.multipart?.parts).toHaveLength(6);
  const records = compiled.multipart!.parts.flatMap(part => {
    const payload = JSON.parse(part) as { version: number; records: unknown[] };
    expect(payload.version).toBe(1);
    return payload.records;
  }) as Array<Record<string, unknown>>;
  expect(records.filter(record => record.kind === "system").map(record => record.content)).toEqual([
    "system-one",
    "system-two",
  ]);
  expect(records.filter(record => record.kind === "message").map(record => (
    (record.message as { role: string }).role
  ))).toEqual(["developer", "user", "assistant", "user"]);
  expect(compiled.multipart!.parts.join("\n")).not.toContain(token);
  expect(compiled.multipart!.commit.match(new RegExp(token, "g"))).toHaveLength(1);
  expect(compiled.text).toBe(compiled.multipart!.commit);
  expect(compiled.text).not.toContain("<codex_context_json>");

  const transactionId = `ctx_${"a".repeat(32)}`;
  const stages = compiled.multipart!.parts.slice(0, -1).map((part, index) => (
    formatChatGptWebMultipartStage(part, transactionId, index + 1)
  ));
  expect(stages).toHaveLength(5);
  for (const [index, stage] of stages.entries()) {
    expect(stage.text).toContain(`part: ${index + 1}/6`);
    expect(stage.text).toContain(stage.sha256);
    expect(stage.acknowledgement).toBe(
      `CODEX_MULTIPART_ACK ${transactionId} ${index + 1}/6 ${stage.sha256}`,
    );
    expect(stage.text).toContain("```json\n");
    expect(stage.text).toContain("<codex_multipart_stage_end>");
    expect(stage.text).toEndWith("</codex_multipart_stage_end>");
    expect(stage.text.lastIndexOf(stage.acknowledgement)).toBeGreaterThan(
      stage.text.indexOf("</codex_context_part_json>"),
    );
  }
  const commit = formatChatGptWebMultipartCommit(compiled.multipart!, transactionId);
  expect(commit).toContain(`transaction_id: ${transactionId}`);
  expect(commit).toContain("acknowledged_parts: 5/6");
  expect(commit).toContain("The final part is included in this same message and starts the task");
  expect(commit).toContain(compiled.multipart!.parts.at(-1)!);
  expect(commit).toContain("latest-request");
  expect(commit.match(new RegExp(token, "g"))).toHaveLength(1);
});

test("Bigger Context uses the minimum transport and reserves six parts for compaction", () => {
  expect(biggerContextPartCount(94_999, 95_000, false)).toBeUndefined();
  expect(biggerContextPartCount(95_000, 95_000, false)).toBe(2);
  expect(biggerContextPartCount(189_999, 95_000, false)).toBe(2);
  expect(biggerContextPartCount(190_000, 95_000, false)).toBe(6);
  expect(biggerContextPartCount(1, 95_000, true)).toBe(6);

  const compiled = compileChatGptWebPrompt(
    request("high"),
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
    undefined,
    { experimentalMultipartParts: 2 },
  );
  expect(compiled.multipart?.parts).toHaveLength(2);
  const transactionId = `ctx_${"b".repeat(32)}`;
  const stages = compiled.multipart!.parts.slice(0, -1).map((part, index) => (
    formatChatGptWebMultipartStage(part, transactionId, index + 1, 2)
  ));
  expect(stages).toHaveLength(1);
  expect(stages.map(stage => stage.acknowledgement)).toEqual([
    `CODEX_MULTIPART_ACK ${transactionId} 1/2 ${stages[0]!.sha256}`,
  ]);
  expect(formatChatGptWebMultipartCommit(compiled.multipart!, transactionId))
    .toContain("acknowledged_parts: 1/2");
});

test("browser-only Medium directs users to the full harness", () => {
  const capabilities = { localToolsEnabled: false, solAvailable: true, proAvailable: true };
  const warning = chatGptReadOnlyContextWarning(request("medium"), capabilities);
  expect(warning).toStartWith("> **Local tools unavailable**");
  expect(warning).toContain("`MCP`");
  expect(warning).toContain("`Codex Web GPT`");
  expect(warning).toContain("`Full`");
  expect(warning).toContain("selected ChatGPT Web model");
  expect(warning).not.toContain("tool-capable ChatGPT Web model first");
  expect(chatGptReadOnlyContextWarning(toolRequest("medium"), {
    ...capabilities,
    localToolsEnabled: true,
  })).toBeUndefined();
});

test("compaction prompts are isolated summarization turns without local or native tool instructions", () => {
  const compact = request("high");
  compact._compactionRequest = true;
  const compiled = compileChatGptWebPrompt(
    compact,
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
  );

  expect(compiled.text).toContain("This is a Codex history-compaction checkpoint, not a normal task turn.");
  expect(compiled.text).toContain("Produce the requested checkpoint summary now without calling tools.");
  expect(compiled.text).not.toContain("codex_bind_turn");
  expect(compiled.text).not.toContain("web search, browsing, research");
  expect(compiled.text).not.toContain("missing local-computer bridge");
});

test.each([undefined, 6] as const)("connector-backed compaction has one control-only completion contract (parts=%s)", parts => {
  const compact = request("high");
  compact._compactionRequest = true;
  const control = "Submit the summary through codex.control.compaction_handoff exactly once.";
  const compiled = compileChatGptWebPrompt(
    compact,
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
    undefined,
    {
      nativeControlConnector: true,
      compactionControlInstruction: control,
      ...(parts ? { experimentalMultipartParts: parts } : {}),
    },
  );

  expect(compiled.text).toContain(control);
  expect(compiled.text).not.toContain("Produce the requested checkpoint summary now without calling tools.");
  expect(compiled.text).not.toContain("Return only the answer that the outer Codex task should receive.");
  expect(compiled.text).toContain("Submit the checkpoint through the one-shot control operation now.");
});

test("Web compaction trims only the oldest history until the browser request fits", () => {
  const compact = request("high");
  compact._compactionRequest = true;
  compact.context.systemPrompt = [];
  compact.context.messages = [
    { role: "developer", content: `oldest-static-${"a".repeat(10_000)}`, timestamp: 1 },
    { role: "developer", content: `newer-static-${"b".repeat(10_000)}`, timestamp: 2 },
    { role: "user", content: `real-task-${"c".repeat(100_000)}`, timestamp: 3 },
    {
      role: "assistant",
      content: [{ type: "text", text: "verified-progress" }],
      timestamp: 4,
    },
    { role: "user", content: "checkpoint-now", timestamp: 5 },
  ];

  const compiled = compileChatGptWebPrompt(
    compact,
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
  );
  const encoded = compiled.text.match(/<codex_context_json>\n(.+)\n<\/codex_context_json>/s)?.[1];
  const envelope = JSON.parse(encoded!) as { messages: Array<{ role: string; content: unknown }> };

  expect(chatGptPromptJsonBytes(compiled.text)).toBeLessThanOrEqual(CHATGPT_COMPACTION_PROMPT_JSON_BYTE_BUDGET);
  expect(compiled.trimmedCompactionMessages).toBe(2);
  expect(compiled.text).not.toContain("oldest-static");
  expect(compiled.text).not.toContain("newer-static");
  expect(compiled.text).toContain("real-task-");
  expect(compiled.text).toContain("verified-progress");
  expect(envelope.messages.at(-1)).toEqual({ role: "user", content: "checkpoint-now" });

  const normal = structuredClone(compact);
  delete normal._compactionRequest;
  const untrimmed = compileChatGptWebPrompt(
    normal,
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
  );
  expect(untrimmed.text).toContain("oldest-static");
  expect(untrimmed.text).toContain("newer-static");
  expect(untrimmed.trimmedCompactionMessages).toBeUndefined();
});

test("Bigger Context compaction preserves history above the retired inline byte budget", () => {
  const compact = request("high");
  compact._compactionRequest = true;
  compact.context.systemPrompt = [];
  compact.context.messages = Array.from({ length: 6 }, (_unused, index) => ({
    role: "user" as const,
    // Two records per stage still exceed the retired cap without a near-megabyte fixture.
    content: `multipart-history-${index + 1}-${String.fromCharCode(97 + index).repeat(CHATGPT_COMPACTION_PROMPT_JSON_BYTE_BUDGET / 2 + 1)}`,
    timestamp: index + 1,
  }));

  const multipart = compileChatGptWebPrompt(
    compact,
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
    undefined,
    { experimentalMultipartParts: CHATGPT_BIGGER_CONTEXT_PARTS },
  );

  expect(multipart.trimmedCompactionMessages).toBeUndefined();
  expect(multipart.multipart?.parts).toHaveLength(6);
  const transactionId = `ctx_${"0".repeat(32)}`;
  const stageBytes = multipart.multipart!.parts.map((payload, index) => chatGptPromptJsonBytes(
    formatChatGptWebMultipartStage(payload, transactionId, index + 1).text,
  ));
  expect(stageBytes.reduce((sum, bytes) => sum + bytes, 0)).toBeGreaterThan(CHATGPT_COMPACTION_PROMPT_JSON_BYTE_BUDGET);
  const staged = multipart.multipart!.parts.join("\n");
  for (let index = 1; index <= 6; index += 1) {
    expect(staged).toContain(`multipart-history-${index}-`);
  }
}, 30_000);

test("Bigger Context keeps preliminary parts small and preserves all records in order", () => {
  const compact = request("high");
  compact._compactionRequest = true;
  compact.context.systemPrompt = ["system".repeat(1_000)];
  compact.context.messages = [
    ...Array.from({ length: 6 }, (_unused, index) => ({
      role: "user" as const,
      content: `history-${index}-${"x".repeat(100_000)}`,
      timestamp: index + 1,
    })),
    { role: "user", content: "compact now", timestamp: 7 },
  ];

  const multipart = compileChatGptWebPrompt(
    compact,
    { localToolsEnabled: false, solAvailable: true, proAvailable: false },
    undefined,
    { experimentalMultipartParts: CHATGPT_BIGGER_CONTEXT_PARTS },
  );
  const parts = multipart.multipart!.parts.map(part => JSON.parse(part) as { records: unknown[] });

  expect(parts).toHaveLength(6);
  expect(parts.flatMap(part => part.records)).toHaveLength(8);
  expect(Math.max(...multipart.multipart!.parts.slice(0, -1).map(part => part.length))).toBeLessThan(120_000);
  // The selected High mode can carry a larger final part than an Instant upload.
  expect(multipart.multipart!.parts.at(-1)!.length).toBeLessThan(1_048_572);
}, 30_000);

test("Web compaction rebuilds attachments after trimming an oversized oldest image message", () => {
  const compact = request("high");
  compact._compactionRequest = true;
  compact.context.systemPrompt = [];
  compact.context.messages = [
    {
      role: "user",
      content: [
        { type: "text", text: `discard-${"x".repeat(120_000)}` },
        { type: "image", imageUrl: "data:image/png;base64,discarded-image" },
      ],
      timestamp: 1,
    },
    { role: "user", content: "preserve-latest-checkpoint", timestamp: 2 },
  ];

  const compiled = compileChatGptWebPrompt(
    compact,
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
  );

  const envelope = compiled.text.split("<codex_context_json>")[1]!.split("</codex_context_json>")[0]!;
  expect(compiled.images).toEqual([]);
  expect(compiled.trimmedCompactionMessages).toBe(1);
  expect(compiled.text).not.toContain("discard-");
  expect(envelope).not.toContain("image_attachment");
  expect(compiled.text).toContain("preserve-latest-checkpoint");
});

test("Luna rejects a separate compaction prompt because continuity is already rolling", () => {
  const compact = request("low");
  compact.modelId = CHATGPT_WEB_LUNA_MODEL_ID;
  compact._compactionRequest = true;
  expect(() => compileChatGptWebPrompt(
    compact,
    { localToolsEnabled: false, solAvailable: false, proAvailable: false },
  )).toThrow("does not accept a separate compaction turn");
});

test("Web compaction fails closed when its final instruction alone exceeds the transport budget", () => {
  const compact = request("high");
  compact._compactionRequest = true;
  compact.context.systemPrompt = [];
  compact.context.messages = [{ role: "user", content: "z".repeat(120_000), timestamp: 1 }];

  expect(() => compileChatGptWebPrompt(
    compact,
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
  )).toThrow("final compaction instruction alone exceeds");
});

test("assigns prior assistant output to the model and never attributes Codex context to the human", () => {
  const attributed = request("max");
  attributed.context.messages = [
    { role: "user", content: "hi", timestamp: 1 },
    {
      role: "assistant",
      content: [{ type: "text", text: "Hi! How can I help?" }],
      timestamp: 2,
    },
    {
      role: "user",
      content: "what did I write before?\n<environment_context><cwd>/private/project</cwd></environment_context>",
      timestamp: 3,
    },
  ];
  const compiled = compileChatGptWebPrompt(
    attributed,
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
  );
  const encoded = compiled.text.match(/<codex_context_json>\n(.+)\n<\/codex_context_json>/s)?.[1];
  const envelope = JSON.parse(encoded!) as { messages: Array<Record<string, unknown>> };

  expect(envelope.messages[1]).toEqual({
    role: "assistant",
    content: [{ type: "text", text: "Hi! How can I help?" }],
  });
  expect(compiled.text).toContain("assistant messages are your own earlier replies");
  expect(compiled.text).toContain("environment_context, are operational context rather than human-authored text");
  expect(compiled.text).toContain("answer only from the human-authored text in user messages");
  expect(compiled.text).toContain("do not attribute, quote, summarize, or otherwise mention them");
});

test("a long task keeps the newest images and drops the overflow instead of failing", () => {
  const image = (marker: string) => ({
    type: "image" as const,
    imageUrl: `data:image/png;base64,${marker}`,
  });
  const markers = Array.from({ length: 13 }, (_unused, index) => `IMG${index + 1}`);
  const replayed: CodexParsedRequest = {
    modelId: CHATGPT_WEB_MODEL_ID,
    context: {
      systemPrompt: ["preserve-system"],
      tools: [{ name: "Read", description: "Read a file", parameters: {} }],
      messages: markers.map((marker, index) => ({
        role: "user" as const,
        content: [{ type: "text" as const, text: `step ${index + 1}` }, image(marker)],
        timestamp: index + 1,
      })),
    },
    stream: true,
    options: { reasoning: "high" },
  };

  const compiled = compileChatGptWebPrompt(
    replayed,
    { localToolsEnabled: true, solAvailable: true, proAvailable: true },
    "turn_12345678901234567890123456789012",
  );

  expect(compiled.images.map(entry => entry.imageUrl)).toEqual(
    markers.slice(-10).map(marker => `data:image/png;base64,${marker}`),
  );
  expect(compiled.text).toContain("older image not attached");
  expect(compiled.text).toContain("step 1");
  expect(compiled.text).toContain("step 13");
});

test("Web compaction attaches the newest ten images as files and never embeds their base64 in prompt text", () => {
  const imagePayloads = Array.from({ length: 13 }, (_unused, index) =>
    Buffer.from(`compaction-image-${index + 1}`).toString("base64"));
  const parsed: CodexParsedRequest = {
    modelId: CHATGPT_WEB_MODEL_ID,
    context: {
      systemPrompt: ["preserve-system"],
      messages: imagePayloads.map((payload, index) => ({
        role: "user" as const,
        content: [
          { type: "text" as const, text: `checkpoint ${index + 1}` },
          { type: "image" as const, imageUrl: `data:image/png;base64,${payload}` },
        ],
        timestamp: index + 1,
      })),
    },
    stream: true,
    options: { reasoning: "high" },
    _compactionRequest: true,
  };

  const compiled = compileChatGptWebPrompt(
    parsed,
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
  );

  expect(compiled.images.map(image => image.imageUrl)).toEqual(
    imagePayloads.slice(-10).map(payload => `data:image/png;base64,${payload}`),
  );
  expect(compiled.text).not.toContain("data:image");
  for (const payload of imagePayloads) expect(compiled.text).not.toContain(payload);
  expect(compiled.text.match(/"type":"image_attachment"/g)).toHaveLength(10);
  expect(compiled.text.match(/older image not attached/g)).toHaveLength(3);
});

test("persisted one-pixel image sentinels are not attached to ChatGPT", () => {
  const placeholder = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=";
  const parsed: CodexParsedRequest = {
    modelId: CHATGPT_WEB_MODEL_ID,
    context: {
      messages: [{
        role: "user",
        content: [
          { type: "text", text: "inspect the real image" },
          ...Array.from({ length: 30 }, () => ({ type: "image" as const, imageUrl: placeholder })),
          { type: "image", imageUrl: "data:image/png;base64,real-image" },
        ],
        timestamp: 1,
      }],
    },
    stream: true,
    options: { reasoning: "high" },
  };

  const compiled = compileChatGptWebPrompt(parsed, { localToolsEnabled: false, solAvailable: true, proAvailable: true });

  expect(compiled.images.map(image => image.imageUrl)).toEqual(["data:image/png;base64,real-image"]);
  expect(compiled.text.match(/"type":"image_attachment"/g)).toHaveLength(1);
  expect(compiled.text).not.toContain("older image not attached");
});

test("the replayed context never carries a finished turn's broker handles", () => {
  const staleToken = "turn_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
  const staleBinding = "binding_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB";
  const token = "turn_12345678901234567890123456789012";
  const replayed: CodexParsedRequest = {
    modelId: CHATGPT_WEB_MODEL_ID,
    context: {
      systemPrompt: ["preserve-system"],
      tools: [{ name: "Read", description: "Read a file", parameters: {} }],
      messages: [
        { role: "user", content: "keep working", timestamp: 1 },
        {
          role: "assistant",
          content: [{ type: "toolCall", id: "call_1", name: "codex_bind_turn", arguments: { turn_token: staleToken } }],
          timestamp: 2,
        },
        {
          role: "toolResult",
          toolCallId: "call_1",
          toolName: "codex_bind_turn",
          isError: false,
          content: `{"binding_id":"${staleBinding}"}`,
          timestamp: 3,
        },
      ],
    },
    stream: true,
    options: { reasoning: "high" },
  };

  const compiled = compileChatGptWebPrompt(replayed, { localToolsEnabled: true, solAvailable: true, proAvailable: true }, token);

  expect(compiled.text).not.toContain(staleToken);
  expect(compiled.text).not.toContain(staleBinding);
  expect(compiled.text).toContain("[retired turn handle]");
  expect(compiled.text).toContain("[retired binding handle]");
  expect(compiled.text).toContain(token);
  expect(compiled.text).toContain("keep working");
  const envelope = compiled.text.split("<codex_context_json>")[1]!.split("</codex_context_json>")[0]!.trim();
  expect(() => JSON.parse(envelope) as unknown).not.toThrow();
});

test("requires ChatGPT-native rich results to include a safe Markdown answer for Codex", () => {
  const compiled = compileChatGptWebPrompt(
    request("max"),
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
  );

  expect(compiled.text).toContain("also provide the relevant result as ordinary Markdown in the final answer");
  expect(compiled.text).toContain("A private ChatGPT UI widget never replaces the Markdown answer returned to Codex");
  expect(compiled.text).toContain("Never copy a ChatGPT widget's HTML, CSS, class names, or DOM markup");
});

test("describes one-shot cross-platform shell limits without exposing secret values", () => {
  const compiled = compileChatGptWebPrompt(
    toolRequest("xhigh"),
    { localToolsEnabled: true, solAvailable: true, proAvailable: true, extraHighAvailable: true },
    "turn_12345678901234567890123456789012",
  );

  expect(compiled.text).toContain("shell_command is one-shot");
  expect(compiled.text).toContain("active platform shell");
  expect(compiled.text).not.toContain("PowerShell 5.1");
  expect(compiled.text).toContain("never print secret values");
});

test("uses the public Instant name without leaking the browser menu alias into the prompt", () => {
  const compiled = compileChatGptWebPrompt(
    request("low"),
    { localToolsEnabled: false, solAvailable: true, proAvailable: true },
  );

  expect(compiled.text).toContain("This is ChatGPT Web Instant with no Codex Native bridge to the user's local computer");
  expect(compiled.text).not.toContain("Instant 5.5");
});

test("keeps large contexts intact in the inline text envelope", () => {
  const token = "turn_12345678901234567890123456789012";
  const largeContent = "x".repeat(600_000);
  const large = request("high");
  large.context.tools = [{ name: "Read", description: "Read a file", parameters: {} }];
  large.context.messages.push({
    role: "toolResult",
    toolCallId: "call_large",
    toolName: "exec_command",
    content: largeContent,
    isError: false,
    timestamp: 3,
  });
  const compiled = compileChatGptWebPrompt(
    large,
    { localToolsEnabled: true, solAvailable: true, proAvailable: true },
    token,
  );

  expect(compiled.text.length).toBeGreaterThan(600_000);
  expect(compiled.text).toContain(largeContent);
  expect(compiled.text).toContain(token);
  expect(compiled.text).toContain(`<codex_context_json>`);
  expect(compiled.text).not.toContain(`<codex_context_attachment>`);
  expect(compiled.text).not.toContain("sha256");
  expect(compiled.text).not.toContain("SHA-256");
});

test("serialized history cannot feed code-fence backtracking into ChatGPT's link lexer", () => {
  const original = {
    content: '```python\nprint("hello")\n``` '.repeat(20),
    nested: { '`key`': ["`inline`", "\\u0060", "\\`", "中文", "[link](url)"] },
  };
  const encoded = withoutRetiredTurnHandles(JSON.stringify(original));
  expect(encoded).not.toContain("`");
  expect(JSON.parse(encoded)).toEqual(original);
});

test("inline and multipart transports preserve code while escaping its Markdown delimiters", () => {
  const parsed = request("high");
  parsed.context.messages[1]!.content = '```python\nprint("hello")\n``` '.repeat(20);
  const capabilities = { localToolsEnabled: true, solAvailable: true, extraHighAvailable: true, proAvailable: true };
  const inline = compileChatGptWebPrompt(parsed, capabilities);
  const envelope = inline.text.split("<codex_context_json>\n")[1]!.split("\n</codex_context_json>")[0]!;
  expect(envelope).not.toContain("`");
  expect(JSON.stringify(JSON.parse(envelope))).toContain("```python");
  const multipart = compileChatGptWebPrompt(parsed, capabilities, undefined, { experimentalMultipartParts: CHATGPT_BIGGER_CONTEXT_PARTS });
  expect(multipart.multipart).toBeDefined();
  for (const part of multipart.multipart!.parts) {
    expect(part).not.toContain("`");
    expect(() => JSON.parse(part)).not.toThrow();
  }
  expect(JSON.stringify(multipart.multipart!.parts.map(part => JSON.parse(part)))).toContain("```python");
});
