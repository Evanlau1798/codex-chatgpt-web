import { randomBytes } from "node:crypto";
import type { ChatGptTurnEnvironment } from "./environment";

export interface BrokerRetirementFailure {
  code: "codex_tool_timeout";
  tool: string;
  timeoutMs: number;
}

export function assertRetirementFailure(value: unknown): asserts value is BrokerRetirementFailure {
  const failure = value as Partial<BrokerRetirementFailure> | null;
  if (!failure || failure.code !== "codex_tool_timeout"
    || typeof failure.tool !== "string" || !/^[A-Za-z0-9_.-]{1,256}$/.test(failure.tool)
    || !Number.isSafeInteger(failure.timeoutMs) || failure.timeoutMs! <= 0) {
    throw new Error("Invalid Codex tool retirement failure");
  }
}

export interface BrokerToolRequest {
  callId: string;
  wireName: string;
  freeform: boolean;
  invokeDeadlineAt?: number;
  arguments?: Record<string, unknown>;
  input?: string;
}

export interface BrokerToolResult {
  content: unknown[];
  structuredContent?: unknown;
  isError?: boolean;
  _meta?: unknown;
}

export type BrokerTurnOutputKind = "commentary" | "reasoning" | "final";
export type BrokerOutputCapability = boolean | { predictions: true };

export interface BrokerTurnOutputEvent {
  sequence: number;
  kind: BrokerTurnOutputKind;
  text: string;
  nextMessagePrediction?: string | null;
}

export interface BrokerRequest {
  failure?: BrokerRetirementFailure;
  id: string;
  method: "claim" | "resolve" | "release" | "invoke" | "read_context" | "submit_compaction_handoff" | "submit_recovery_checkpoint" | "submit_output"
    | "owner_status" | "owner_register" | "owner_register_safe" | "owner_update" | "owner_safe_sent"
    | "owner_next" | "owner_complete" | "owner_safe_wait_start" | "owner_safe_wait_completion"
    | "owner_request_compaction" | "owner_compaction_delivery_count" | "safe_start" | "safe_complete"
    | "owner_completion_fence_begin" | "owner_completion_fence_commit" | "owner_next_output"
    | "owner_begin_finalization"
    | "owner_cancel_finalization"
    | "owner_arm_finalization_output"
    | "owner_reset_output" | "owner_seal_output" | "owner_wait_retirement" | "owner_revoke" | "activity_complete"
    | "start_agent_wait" | "read_agent_wait" | "read_output_control";
  waitId?: string;
  token?: string;
  bindingId?: string;
  wireName?: string;
  freeform?: boolean;
  arguments?: Record<string, unknown>;
  input?: string;
  invokeDeadlineAt?: number;
  handoffId?: string;
  summary?: string;
  index?: number;
  chunkChars?: number;
  environment?: ChatGptTurnEnvironment;
  ttlMs?: number;
  traceId?: string;
  callId?: string;
  activityId?: string;
  revision?: number;
  toolResult?: BrokerToolResult;
  surfaceNonce?: string;
  finalAnswer?: string;
  outputKind?: BrokerTurnOutputKind;
  outputText?: string;
  outputEnabled?: boolean;
  predictionEnabled?: boolean;
  nextMessagePrediction?: string | null;
  afterSequence?: number;
  expectedRevision?: number;
  outputSequence?: number;
  contract?: "native" | "safe";
}

export interface BrokerResponse {
  id: string;
  result?: unknown;
  error?: string;
}

export const MAX_BROKER_LINE_CHARS = 67_108_864;

export function opaqueId(prefix: string): string {
  return `${prefix}_${randomBytes(16).toString("hex")}`;
}

export function errorOf(value: unknown): Error {
  return value instanceof Error ? value : new Error(String(value));
}

export interface BrokerRetirementDiagnostics {
  traceId: string;
  pendingTools: number;
  queuedTools: number;
  deliveredTools: number;
  activeMcpRequests: number;
  completionCommitted: boolean;
  pendingCalls: Array<{
    callRef: string;
    tool: string;
    state: "queued" | "delivered";
    queuedMs: number;
    awaitingResultMs?: number;
  }>;
  omittedPendingCalls: number;
}
