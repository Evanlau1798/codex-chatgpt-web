const test = require("node:test");
const assert = require("node:assert/strict");
const { EventEmitter } = require("node:events");
const fs = require("node:fs");
const { resolve } = require("node:path");
const { createLogger } = require("../electron/logging.cjs");
const {
  browserViewVisible,
  constrainBrowserBounds,
  navigateBrowser,
  readBrowserNavigationState,
  scaleBrowserBounds,
  shellZoomActionForInput,
} = require("../electron/browser-state.cjs");
const {
  allowedAuthUrl,
  BrowserHost,
  IDLE_BROWSER_URL,
  isChatGptCloudflareChallengeResponse,
  isTemporaryChatUrl,
  loadCommittedBrowserSurface,
  navigationErrorForLog,
  navigationOriginForLog,
} = require("../electron/browser-host.cjs");

test("Electron and Bun agree on the exact launcher idle surface", () => {
  const clientSource = fs.readFileSync(
    resolve(__dirname, "../../src/launcher-browser-host.ts"),
    "utf8",
  );
  assert.ok(clientSource.includes(
    `export const LAUNCHER_BROWSER_IDLE_URL = ${JSON.stringify(IDLE_BROWSER_URL)};`,
  ));
});

test("descriptor publishes native surface identities without inspecting renderers or Zero Risk tabs", () => {
  const dir = fs.mkdtempSync(require("node:path").join(require("node:os").tmpdir(), "browser-targets-"));
  const queried = [];
  const contents = id => ({
    isDestroyed: () => false,
    getOrCreateDevToolsTargetId: () => { queried.push(id); return id; },
    executeJavaScript: () => { throw new Error("Descriptor must not inspect renderer content"); },
  });
  const automatic = { surfaceId: "a".repeat(32), interactionMode: "automatic", view: { webContents: contents("auto-target") } };
  const manual = { surfaceId: null, interactionMode: "manual", view: { webContents: contents("manual-target") } };
  const fixture = {
    surfaceId: "h".repeat(32), view: { webContents: contents("home-target") },
    turnTabs: new Map([["automatic", automatic], ["manual", manual]]),
    getBrowserInteractionMode: () => "automatic", profile: "production", cdpPort: 40000,
    partition: "persist:codex-web-gpt-chatgpt", control: {}, helper: {},
    descriptorPath: require("node:path").join(dir, "descriptor.json"),
  };
  try {
    BrowserHost.prototype.writeDescriptor.call(fixture);
    const descriptor = JSON.parse(fs.readFileSync(fixture.descriptorPath, "utf8"));
    assert.equal(descriptor.version, 3);
    assert.deepEqual(descriptor.surfaceTargets, {
      [fixture.surfaceId]: "home-target", [automatic.surfaceId]: "auto-target",
    });
    assert.deepEqual(queried, ["home-target", "auto-target"]);
    fixture.getBrowserInteractionMode = () => "manual";
    BrowserHost.prototype.writeDescriptor.call(fixture);
    assert.deepEqual(JSON.parse(fs.readFileSync(fixture.descriptorPath, "utf8")).surfaceTargets, {});
    assert.deepEqual(queried, ["home-target", "auto-target"]);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
test("mode transitions publish targets before setup inspection and restore them on rollback", async () => {
  const dir = fs.mkdtempSync(require("node:path").join(require("node:os").tmpdir(), "browser-mode-targets-"));
  let savedMode = "manual";
  const announcementModes = [];
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    surfaceId: "h".repeat(32),
    view: { webContents: { isDestroyed: () => false, getOrCreateDevToolsTargetId: () => "home-target" } },
    turnTabs: new Map(), getBrowserInteractionMode: () => savedMode,
    interactionModeOverride: null, manualOperation: null,
    profile: "production", cdpPort: 40000, partition: "persist:codex-web-gpt-chatgpt",
    control: {}, helper: {}, descriptorPath: require("node:path").join(dir, "descriptor.json"),
    markOwnedSurface: async () => {},
    configureAnnouncementDismissal: async enabled => announcementModes.push(enabled),
  });
  const targets = () => JSON.parse(fs.readFileSync(fixture.descriptorPath, "utf8")).surfaceTargets;
  const automaticTargets = { [fixture.surfaceId]: "home-target" };
  try {
    fixture.writeDescriptor();
    assert.deepEqual(targets(), {});
    await assert.rejects(fixture.withInteractionModeChange("automatic", async () => {
      assert.deepEqual(targets(), automaticTargets);
      throw new Error("setup failed");
    }), /setup failed/);
    assert.deepEqual(targets(), {});
    await fixture.withInteractionModeChange("automatic", async commit => {
      assert.deepEqual(targets(), automaticTargets);
      await commit();
    });
    // main.cjs persists the new mode only after the transaction returns.
    assert.deepEqual(targets(), automaticTargets);
    savedMode = "automatic";
    await assert.rejects(fixture.withInteractionModeChange("manual", async () => {
      assert.deepEqual(targets(), {});
      throw new Error("manual setup failed");
    }), /manual setup failed/);
    assert.deepEqual(targets(), automaticTargets);
    await fixture.withInteractionModeChange("manual", async commit => {
      assert.deepEqual(targets(), {});
      await commit();
    });
    savedMode = "manual";
    assert.deepEqual(targets(), {});
    assert.equal(fixture.currentOperation(), null);
    await assert.rejects(fixture.withInteractionModeChange("automatic", async commit => {
      await commit();
      throw new Error("runtime failed after browser commit");
    }), /runtime failed after browser commit/);
    assert.deepEqual(targets(), {});
    assert.deepEqual(announcementModes, [false, true, false, true, false, true, false]);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test("primary browser bootstrap accepts only the exact committed idle document", async () => {
  const calls = [];
  const contents = new EventEmitter();
  let currentUrl = "about:blank";
  contents.isDestroyed = () => false;
  contents.getURL = () => currentUrl;
  contents.stop = () => calls.push("stop");
  contents.loadURL = async (url) => {
    calls.push(["load", url]);
    currentUrl = url;
  };

  await loadCommittedBrowserSurface(contents, IDLE_BROWSER_URL, 50);

  assert.deepEqual(calls, [["load", IDLE_BROWSER_URL]]);
  assert.equal(contents.listenerCount("did-stop-loading"), 0);
  assert.equal(contents.listenerCount("did-finish-load"), 0);
  assert.equal(contents.listenerCount("did-fail-load"), 0);
  assert.equal(contents.listenerCount("render-process-gone"), 0);
  assert.equal(contents.listenerCount("destroyed"), 0);
});

test("primary browser bootstrap fails closed on navigation, renderer, and timeout boundaries", async () => {
  const keepTestAlive = setTimeout(() => {}, 100);
  try {
    const failureCases = [
      {
        event: ["did-fail-load", {}, -2, "ERR_FAILED", IDLE_BROWSER_URL, true],
        expected: /idle document failed: ERR_FAILED \(-2\)/,
      },
      {
        event: ["render-process-gone", {}, { reason: "crashed", exitCode: -2147483645 }],
        expected: /renderer stopped during idle document bootstrap: crashed/,
      },
    ];
    for (const failure of failureCases) {
      const contents = new EventEmitter();
      contents.isDestroyed = () => false;
      contents.getURL = () => "about:blank";
      contents.stop = () => {};
      contents.loadURL = () => {
        queueMicrotask(() => contents.emit(...failure.event));
        return new Promise(() => {});
      };
      await assert.rejects(
        loadCommittedBrowserSurface(contents, IDLE_BROWSER_URL, 50),
        failure.expected,
      );
    }

    const stalled = new EventEmitter();
    const calls = [];
    stalled.isDestroyed = () => false;
    stalled.getURL = () => "about:blank";
    stalled.stop = () => calls.push("stop");
    stalled.loadURL = () => new Promise(() => {});
    await assert.rejects(
      loadCommittedBrowserSurface(stalled, IDLE_BROWSER_URL, 5),
      /idle document did not commit within 5ms/,
    );
    assert.deepEqual(calls, ["stop"]);
  } finally {
    clearTimeout(keepTestAlive);
  }
});

test("primary browser initialization keeps its view offscreen but visible until ownership is committed", async () => {
  const calls = [];
  let currentUrl = "about:blank";
  const contents = new EventEmitter();
  contents.isDestroyed = () => false;
  contents.getURL = () => currentUrl;
  contents.stop = () => calls.push("stop");
  contents.loadURL = async (url) => {
    calls.push(["load", url]);
    currentUrl = url;
  };
  const hiddenBounds = { x: 1121, y: 721, width: 1120, height: 720 };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    view: {
      setBounds: bounds => calls.push(["bounds", bounds]),
      setVisible: visible => calls.push(["visible", visible]),
      webContents: contents,
    },
    hiddenTurnBounds: () => hiddenBounds,
    markOwnedSurface: async () => calls.push("owned"),
    syncViewVisibility: () => calls.push("sync"),
    writeDescriptor: () => calls.push("descriptor"),
    logger: { info: (event, detail) => calls.push([event, detail]) },
  });

  await BrowserHost.prototype.initializePrimaryView.call(fixture);

  assert.deepEqual(calls, [
    ["bounds", hiddenBounds],
    ["visible", true],
    ["load", IDLE_BROWSER_URL],
    "owned",
    "sync",
    "descriptor",
    ["browser.initialized", { url: IDLE_BROWSER_URL }],
  ]);
});

test("authentication diagnostics retain only origin and non-sensitive error metadata", () => {
  assert.equal(
    navigationOriginForLog("https://accounts.google.com/o/oauth2/v2/auth?state=secret&login_hint=user@example.com"),
    "https://accounts.google.com",
  );
  assert.equal(navigationOriginForLog("not a URL with user@example.com"), "invalid-url");
  assert.deepEqual(
    navigationErrorForLog(Object.assign(new Error("loading https://chatgpt.com/c/private"), { code: "ERR_ABORTED" })),
    { errorType: "Error", errorCode: "ERR_ABORTED" },
  );
});

test("only an explicit Cloudflare challenge on a ChatGPT backend response triggers recovery", () => {
  assert.equal(isChatGptCloudflareChallengeResponse({
    statusCode: 403,
    url: "https://chatgpt.com/backend-api/subscriptions",
    responseHeaders: {
      "Cf-Mitigated": ["challenge"],
      "Content-Type": ["text/html; charset=UTF-8"],
    },
  }), true);
  assert.equal(isChatGptCloudflareChallengeResponse({
    statusCode: 403,
    url: "https://chatgpt.com/backend-api/subscriptions",
    responseHeaders: { "Content-Type": ["application/json"] },
  }), false);
  assert.equal(isChatGptCloudflareChallengeResponse({
    statusCode: 403,
    url: "https://example.com/backend-api/subscriptions",
    responseHeaders: { "cf-mitigated": ["challenge"] },
  }), false);
});

test("the idle home browser performs one bounded reload for a Cloudflare challenge burst", async () => {
  const calls = [];
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map(),
    manualOperation: null,
    cloudflareChallengeRecovery: null,
    cloudflareChallengeRecoveryArmed: true,
    cloudflareChallengeRecoveryDelayMs: 0,
    cloudflareChallengeRecoverySettleMs: 0,
    view: {
      webContents: {
        id: 42,
        getURL: () => "https://chatgpt.com/?temporary-chat=true",
        isDestroyed: () => false,
        loadURL: async (url) => calls.push(["loadURL", url]),
        executeJavaScript: async () => ({ draft: false, running: false }),
      },
    },
    logger: {
      info: (event, detail) => calls.push(["info", event, detail]),
      warn: (event, detail) => calls.push(["warn", event, detail]),
      error: (event, detail) => calls.push(["error", event, detail]),
    },
    setState: (patch) => calls.push(["setState", patch]),
    probeAuthentication: async () => calls.push(["probeAuthentication"]),
  });
  const challenge = {
    statusCode: 403,
    url: "https://chatgpt.com/backend-api/subscriptions?private=PRIVATE_QUERY",
    webContentsId: 42,
    responseHeaders: { "cf-mitigated": ["challenge"] },
  };

  assert.equal(BrowserHost.prototype.handleChatGptBackendResponse.call(fixture, challenge), true);
  assert.equal(BrowserHost.prototype.handleChatGptBackendResponse.call(fixture, challenge), true);
  await fixture.cloudflareChallengeRecovery;

  assert.deepEqual(calls.filter(([name]) => name === "loadURL"), [
    ["loadURL", "https://chatgpt.com/?temporary-chat=true"],
  ]);
  assert.equal(fixture.cloudflareChallengeRecoveryArmed, false);
  assert.doesNotMatch(JSON.stringify(calls.filter(([name]) => name === "warn")), /PRIVATE_QUERY|https:\/\//);

  BrowserHost.prototype.handleChatGptBackendResponse.call(fixture, {
    statusCode: 200,
    url: "https://chatgpt.com/backend-api/subscriptions",
    webContentsId: 42,
    responseHeaders: { "content-type": ["application/json"] },
  });
  assert.equal(fixture.cloudflareChallengeRecoveryArmed, true);
});

test("managed challenge is reported without reloading, cancelling or trusting a foreign view", () => {
  const messages = [];
  const tab = { traceId: "owned", status: "running", view: { webContents: { id: 43, isDestroyed: () => false } } };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map([["owned", tab]]),
    view: { webContents: { id: 42, isDestroyed: () => false } },
    logger: { warn: (...args) => messages.push(args) },
    setState: patch => messages.push(patch),
    reloadHomeAfterCloudflareChallenge: () => { throw new Error("must not reload"); },
  });
  const details = { statusCode: 403, webContentsId: 43, url: "https://chatgpt.com/backend-api/f/conversation?private=PRIVATE_QUERY", responseHeaders: { "cf-mitigated": ["challenge"] } };
  assert.equal(fixture.handleChatGptBackendResponse({ ...details, webContentsId: 999 }), false);
  assert.equal(fixture.handleChatGptBackendResponse(details), true);
  assert.equal(tab.status, "running");
  assert.match(tab.message, /manually/);
  assert.equal(messages[0][1].traceId, "owned");
  assert.doesNotMatch(JSON.stringify(messages), /PRIVATE_QUERY|https:\/\//);
});

for (const scenario of ["active-turn", "manual-operation", "persisted", "recovered", "recovery-failed"]) {
  test(`challenge ${scenario} diagnostics exclude private URLs from disk, Activity and published records`, async () => {
    const dir = fs.mkdtempSync(resolve(require("node:os").tmpdir(), "challenge-privacy-"));
    const filePath = resolve(dir, "launcher.log");
    const published = [];
    const loads = [];
    const states = [];
    const logger = createLogger({ filePath, publish: record => published.push(record) });
    const fixture = Object.assign(Object.create(BrowserHost.prototype), {
      turnTabs: new Map(scenario === "active-turn" ? [["owned", { status: "running", traceId: "owned" }]] : []),
      manualOperation: scenario === "manual-operation" ? {} : null,
      cloudflareChallengeRecovery: null,
      cloudflareChallengeRecoveryArmed: scenario !== "persisted",
      cloudflareChallengeRecoveryDelayMs: 0,
      cloudflareChallengeRecoverySettleMs: 0,
      logger,
      view: { webContents: {
        id: 42, isDestroyed: () => false,
        getURL: () => "https://chatgpt.com/c/PRIVATE_PATH?private=PRIVATE_QUERY",
        executeJavaScript: async () => ({ draft: false, running: false }),
        loadURL: async url => {
          loads.push(url);
          if (scenario === "recovery-failed") throw Object.assign(new Error(`ERR_FAILED loading '${url}'`), { code: "ERR_FAILED" });
          fixture.cloudflareChallengeRecoveryArmed = true;
        },
      } },
      setState: patch => states.push(patch), probeAuthentication: async () => {},
    });
    try {
      assert.equal(fixture.handleChatGptBackendResponse({
        statusCode: 403, webContentsId: 42,
        url: "https://chatgpt.com/backend-api/subscriptions?private=PRIVATE_QUERY",
        responseHeaders: { "cf-mitigated": ["challenge"] },
      }), true);
      await fixture.cloudflareChallengeRecovery;
      const expected = scenario === "recovered" ? "browser.cloudflare_challenge_recovered"
        : scenario === "recovery-failed" ? "browser.cloudflare_challenge_recovery_failed"
        : scenario === "persisted" ? "browser.cloudflare_challenge_persisted" : "browser.cloudflare_challenge_not_reloaded";
      assert.equal(published.at(-1).event, expected);
      assert.equal(loads.length, scenario === "recovered" || scenario === "recovery-failed" ? 1 : 0);
      if (scenario === "recovery-failed") {
        assert.match(states.at(-1).message, /ERR_FAILED.*PRIVATE_QUERY/);
      }
      for (const records of [fs.readFileSync(filePath, "utf8"), JSON.stringify(logger.recent()), JSON.stringify(published)]) {
        assert.doesNotMatch(records, /PRIVATE_QUERY|PRIVATE_PATH|https:\/\//);
      }
      const expectedDetail = scenario === "recovered" ? {}
        : scenario === "recovery-failed" ? { errorType: "Error", errorCode: "ERR_FAILED" }
        : scenario === "persisted" ? { statusCode: 403 }
        : { reason: scenario === "active-turn" ? "turn-active" : "manual-operation-active", statusCode: 403 };
      assert.deepEqual(published.at(-1).detail, expectedDetail);
    } finally {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  });
}

test("security refresh preserves manually running generation, draft and unverifiable renderer", async () => {
  for (const observed of [{ draft: true, running: false }, { draft: false, running: true }, null]) {
    const calls = [];
    const fixture = {
      cloudflareChallengeRecoveryDelayMs: 0,
      view: { webContents: { isDestroyed: () => false, getURL: () => "https://chatgpt.com/?temporary-chat=true",
        executeJavaScript: async () => observed, loadURL: async () => calls.push("reload") } },
      setState() {},
    };
    await assert.rejects(BrowserHost.prototype.reloadHomeAfterCloudflareChallenge.call(fixture), /refresh refused/);
    assert.deepEqual(calls, []);
  }
});

test("security refresh rejects lookalike, foreign and malformed origins without inspection or navigation", async () => {
  for (const url of ["https://chatgpt.com.attacker.test/", "https://chatgpt.com@attacker.test/", "http://chatgpt.com/", "not a URL"]) {
    const calls = [];
    const fixture = {
      cloudflareChallengeRecoveryDelayMs: 0,
      view: { webContents: { isDestroyed: () => false, getURL: () => url,
        executeJavaScript: async () => { calls.push("inspect"); return { draft: false, running: false }; },
        loadURL: async () => calls.push("reload") } },
      setState() {},
    };
    await assert.rejects(BrowserHost.prototype.reloadHomeAfterCloudflareChallenge.call(fixture), /lost its owned browser page/);
    assert.deepEqual(calls, []);
  }
});

function createContents() {
  const calls = [];
  let zoomFactor = 1;
  const history = {
    canGoBack: () => true,
    canGoForward: () => false,
    goBack: () => calls.push("back"),
    goForward: () => calls.push("forward"),
  };
  const webContents = {
    navigationHistory: history,
    getURL: () => "https://chatgpt.com/?temporary-chat=true",
    getTitle: () => "ChatGPT",
    isDestroyed: () => false,
    isLoading: () => false,
    focus: () => calls.push("focus"),
    getZoomFactor: () => zoomFactor,
    reload: () => calls.push("reload"),
    setZoomFactor: (next) => {
      zoomFactor = next;
      calls.push(["zoom", next]);
    },
  };
  return { calls, webContents };
}

test("browser surface visibility requires both requested and active state", () => {
  assert.equal(browserViewVisible(false, false, false), false);
  assert.equal(browserViewVisible(true, false, true), false);
  assert.equal(browserViewVisible(false, true, true), false);
  assert.equal(browserViewVisible(true, true, false), false);
  assert.equal(browserViewVisible(true, true, true), true);
});

test("showing the browser restores its minimized parent window", () => {
  const calls = [];
  const fixture = {
    visible: false,
    surfaceActive: true,
    boundsReady: false,
    window: {
      isMinimized: () => true,
      isVisible: () => false,
      restore: () => calls.push("restore"),
      show: () => calls.push("show-window"),
    },
    syncViewVisibility: () => calls.push("sync"),
    setState: patch => calls.push(["state", patch]),
  };

  BrowserHost.prototype.show.call(fixture);

  assert.deepEqual(calls, ["restore", "show-window", "sync", ["state", { visible: true }]]);
});

test("smoke preserves an already-hydrated Temporary Chat page", () => {
  assert.equal(isTemporaryChatUrl("https://chatgpt.com/?temporary-chat=true"), true);
  assert.equal(isTemporaryChatUrl("https://chatgpt.com/?temporary-chat=false"), false);
  assert.equal(isTemporaryChatUrl("https://chatgpt.com/c/abc?temporary-chat=true"), false);
  assert.equal(isTemporaryChatUrl("not a url"), false);
});

test("session inspection delegates navigation and capability detection to the shared browser helper", async () => {
  const calls = [];
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    helper: { executable: "/runtime/electron", script: "/runtime/browser-helper.cjs" },
    descriptorPath: "/runtime/launcher-browser.json",
    getConnectorName: () => "Codex Native2",
    logger: { info() {} },
    view: { webContents: { getURL: () => "https://chatgpt.com/" } },
    refreshChatGptHomeDocument: async () => calls.push({ operation: "refresh" }),
    runBrowserHelperOperation: async options => {
      calls.push(options);
      return {
        type: "result",
        value: {
          authenticated: true,
          temporary: true,
           url: "https://chatgpt.com/?temporary-chat=true",
           solAvailable: true,
           extraHighAvailable: true,
           proAvailable: true,
        },
      };
    },
  });

  const inspected = await BrowserHost.prototype.runSessionInspection.call(fixture, true);

  assert.deepEqual(inspected, {
    authenticated: true,
    temporary: true,
     url: "https://chatgpt.com/?temporary-chat=true",
     solAvailable: true,
     extraHighAvailable: true,
     proAvailable: true,
  });
  assert.equal(calls.length, 2);
  assert.equal(calls[0].operation, "refresh");
  assert.equal(calls[1].operation, "inspect");
  assert.equal(calls[1].appName, "Codex Native2");
  assert.deepEqual(calls[1].payload, { detectCapabilities: true });
});

test("session inspection fails closed on incomplete shared-helper capability evidence", async () => {
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    helper: {},
    descriptorPath: "/runtime/launcher-browser.json",
    getConnectorName: () => "Codex Native",
    logger: { info() {} },
    view: { webContents: { getURL: () => "https://chatgpt.com/?temporary-chat=true" } },
    refreshChatGptHomeDocument: async () => {},
    runBrowserHelperOperation: async () => ({
      type: "result",
      value: { authenticated: true, temporary: true, url: "https://chatgpt.com/?temporary-chat=true" },
    }),
  });
  await assert.rejects(
    BrowserHost.prototype.runSessionInspection.call(fixture, true),
    /incomplete ChatGPT capability evidence/,
  );
});

test("browser surface reactivation preserves its last measured bounds", () => {
  const visibility = [];
  const fixture = {
    surfaceActive: true,
    boundsReady: true,
    syncViewVisibility() {
      visibility.push({ active: this.surfaceActive, boundsReady: this.boundsReady });
    },
    setState() {},
    snapshot() {
      return { surfaceActive: this.surfaceActive, boundsReady: this.boundsReady };
    },
  };

  BrowserHost.prototype.setSurfaceActive.call(fixture, false);
  BrowserHost.prototype.setSurfaceActive.call(fixture, true);

  assert.deepEqual(visibility, [
    { active: false, boundsReady: true },
    { active: true, boundsReady: true },
  ]);
  assert.equal(fixture.boundsReady, true);
});

test("hidden turn tabs receive an explicit renderer viewport before moving offscreen", () => {
  const events = [];
  const tab = {
    id: "tab-hidden-viewport",
    status: "running",
    rendererReady: true,
    deviceEmulationViewport: null,
    deviceEmulationDirty: true,
    view: {
      setBounds: bounds => events.push(["bounds", bounds]),
      setVisible: visible => events.push(["visible", visible]),
      webContents: {
        enableDeviceEmulation: options => events.push(["emulate", options]),
        disableDeviceEmulation: () => events.push(["disable-emulation"]),
      },
    },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    visible: false,
    surfaceActive: false,
    boundsReady: false,
    bounds: { x: 0, y: 0, width: 1, height: 1 },
    selectedTabId: tab.id,
    turnTabs: new Map([[tab.id, tab]]),
    authView: null,
    window: {
      getContentSize: () => [1120, 720],
      isMinimized: () => false,
      isVisible: () => true,
    },
    view: {
      setBounds: bounds => events.push(["home-bounds", bounds]),
      setVisible: visible => events.push(["home-visible", visible]),
    },
  });

  BrowserHost.prototype.syncViewVisibility.call(fixture);

  assert.deepEqual(events, [
    ["home-bounds", { x: 1121, y: 721, width: 1120, height: 720 }],
    ["home-visible", true],
    ["emulate", {
      screenPosition: "desktop",
      screenSize: { width: 1120, height: 720 },
      viewPosition: { x: 0, y: 0 },
      deviceScaleFactor: 0,
      viewSize: { width: 1120, height: 720 },
      scale: 1,
    }],
    ["bounds", { x: 1121, y: 721, width: 1120, height: 720 }],
    ["visible", true],
  ]);
  assert.deepEqual(tab.deviceEmulationViewport, { width: 1120, height: 720 });
  assert.equal(tab.deviceEmulationDirty, false);
});

test("background tabs retain the measured browser pane size across selection and window visibility", () => {
  const host = Object.assign(Object.create(BrowserHost.prototype), {
    boundsReady: true,
    bounds: { x: 280, y: 64, width: 710, height: 568 },
    window: { getContentSize: () => [1120, 720] },
  });
  const hidden = host.hiddenTurnBounds();
  assert.deepEqual(hidden, { x: 1121, y: 721, width: 710, height: 568 });
  assert.ok(hidden.x > 1120 && hidden.y > 720, "the pane remains entirely offscreen");
  const sizes = [];
  const tab = {
    status: "running", rendererReady: true, deviceEmulationDirty: true,
    view: {
      setBounds: ({ width, height }) => sizes.push([width, height]),
      setVisible() {},
      webContents: {
        enableDeviceEmulation: ({ viewSize }) => sizes.push([viewSize.width, viewSize.height]),
        disableDeviceEmulation() {},
      },
    },
  };
  host.presentTurnView(tab, false);
  host.presentTurnView(tab, true);
  host.presentTurnView(tab, false);
  assert.ok(sizes.every(([width, height]) => width === 710 && height === 568));
  // A real pane resize still updates every background renderer.
  host.bounds = { ...host.bounds, width: 900, height: 640 };
  host.presentTurnView(tab, false);
  assert.deepEqual(tab.deviceEmulationViewport, { width: 900, height: 640 });
});

test("hidden primary checks retain a renderer viewport across resize and navigation, then restore native bounds", () => {
  const calls = [];
  let size = [1120, 720];
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    primaryRendererReady: false, primaryDeviceEmulationDirty: true,
    primaryDeviceEmulationViewport: null,
    bounds: { x: 280, y: 64, width: 840, height: 656 },
    window: { getContentSize: () => size },
    view: {
      setBounds: value => calls.push(["bounds", value]), setVisible: value => calls.push(["visible", value]),
      webContents: {
        enableDeviceEmulation: value => calls.push(["emulate", value.viewSize]),
        disableDeviceEmulation: () => calls.push(["disable"]),
      },
    },
  });
  fixture.presentPrimaryView(false);
  assert.equal(calls.some(([event]) => event === "emulate"), false);
  fixture.primaryRendererReady = true;
  fixture.presentPrimaryView(false);
  assert.deepEqual(calls.slice(-3), [["emulate", { width: 1120, height: 720 }],
    ["bounds", { x: 1121, y: 721, width: 1120, height: 720 }], ["visible", true]]);
  fixture.presentPrimaryView(false);
  assert.equal(calls.filter(([event]) => event === "emulate").length, 1);
  fixture.primaryDeviceEmulationDirty = true;
  fixture.presentPrimaryView(false);
  size = [1280, 800];
  fixture.presentPrimaryView(false);
  assert.deepEqual(fixture.primaryDeviceEmulationViewport, { width: 1280, height: 800 });
  assert.equal(calls.filter(([event]) => event === "emulate").length, 3);
  fixture.presentPrimaryView(true);
  assert.deepEqual(calls.slice(-3), [["bounds", fixture.bounds], ["disable"], ["visible", true]]);
  assert.equal(fixture.primaryDeviceEmulationViewport, null);
  fixture.getBrowserInteractionMode = () => "manual";
  fixture.presentPrimaryView(false);
  assert.equal(calls.filter(([event]) => event === "emulate").length, 3);
});

test("turn tabs use the hidden viewport when the launcher window is hidden", () => {
  const events = [];
  const tab = {
    id: "tab-hidden-window",
    status: "running",
    rendererReady: true,
    deviceEmulationViewport: null,
    deviceEmulationDirty: true,
    view: {
      setBounds: bounds => events.push(["bounds", bounds]),
      setVisible: visible => events.push(["visible", visible]),
      webContents: {
        enableDeviceEmulation: options => events.push(["emulate", options]),
        disableDeviceEmulation: () => events.push(["disable-emulation"]),
      },
    },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    visible: true,
    surfaceActive: true,
    boundsReady: true,
    bounds: { x: 280, y: 64, width: 840, height: 656 },
    selectedTabId: tab.id,
    turnTabs: new Map([[tab.id, tab]]),
    authView: null,
    window: {
      getContentSize: () => [1120, 720],
      isMinimized: () => false,
      isVisible: () => false,
    },
    view: {
      setBounds: bounds => events.push(["home-bounds", bounds]),
      setVisible: visible => events.push(["home-visible", visible]),
    },
  });

  BrowserHost.prototype.syncViewVisibility.call(fixture);

  assert.deepEqual(events, [
    ["home-bounds", { x: 1121, y: 721, width: 840, height: 656 }],
    ["home-visible", true],
    ["emulate", {
      screenPosition: "desktop",
      screenSize: { width: 840, height: 656 },
      viewPosition: { x: 0, y: 0 },
      deviceScaleFactor: 0,
      viewSize: { width: 840, height: 656 },
      scale: 1,
    }],
    ["bounds", { x: 1121, y: 721, width: 840, height: 656 }],
    ["visible", true],
  ]);
  assert.deepEqual(tab.deviceEmulationViewport, { width: 840, height: 656 });
});

test("new turn tabs defer device emulation until their document is ready", () => {
  const events = [];
  const tab = {
    id: "tab-loading-viewport",
    status: "running",
    rendererReady: false,
    deviceEmulationViewport: null,
    deviceEmulationDirty: true,
    view: {
      setBounds: bounds => events.push(["bounds", bounds]),
      setVisible: visible => events.push(["visible", visible]),
      webContents: {
        enableDeviceEmulation: () => assert.fail("emulation started before dom-ready"),
        disableDeviceEmulation: () => assert.fail("emulation cleared before dom-ready"),
      },
    },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    window: {
      getContentSize: () => [1120, 720],
      isMinimized: () => false,
      isVisible: () => true,
    },
  });

  BrowserHost.prototype.presentTurnView.call(fixture, tab, false);

  assert.deepEqual(events, [
    ["bounds", { x: 1121, y: 721, width: 1120, height: 720 }],
    ["visible", true],
  ]);
  assert.equal(tab.deviceEmulationViewport, null);
  assert.equal(tab.deviceEmulationDirty, true);
});

test("navigation restores the task viewport at DOM readiness without completing bootstrap early", async () => {
  const emulations = [];
  let ownershipMarks = 0;
  const contents = Object.assign(new EventEmitter(), {
    setWindowOpenHandler() {}, getURL: () => "https://chatgpt.com/?temporary-chat=true",
    enableDeviceEmulation: options => emulations.push(options.viewSize),
    isDestroyed: () => false, insertCSS: async () => {},
    executeJavaScript: async script => { if (script.includes("__CODEX_WEB_GPT_SURFACE_ID__")) ownershipMarks++; },
  });
  const tab = {
    id: "navigating", status: "running", rendererReady: false,
    bootstrapReady: false, deviceEmulationDirty: true,
    view: { webContents: contents, setBounds() {}, setVisible() {} },
  };
  const host = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map([[tab.id, tab]]), selectedTabId: "home",
    boundsReady: true, bounds: { x: 280, y: 64, width: 840, height: 656 },
    window: { getContentSize: () => [1120, 760], isVisible: () => false, isMinimized: () => false },
    view: { setBounds() {}, setVisible() {} },
    snapshot() { return {}; },
  });
  host.bindTurnContents(tab);
  contents.emit("did-start-navigation", {}, contents.getURL(), false, true);
  host.syncViewVisibility();
  assert.equal(emulations.length, 0);
  contents.emit("dom-ready");
  assert.deepEqual(emulations, [{ width: 840, height: 656 }]);
  assert.equal(tab.loading, true);
  assert.equal(tab.bootstrapReady, false);
  assert.equal(ownershipMarks, 0);
  contents.emit("did-start-navigation", {}, contents.getURL(), true, true);
  contents.emit("did-start-navigation", {}, "https://example.com/iframe", false, false);
  assert.equal(tab.rendererReady, true, "hash and iframe navigation must not invalidate the viewport");
  contents.emit("did-finish-load");
  await new Promise(setImmediate);
  assert.equal(tab.loading, false);
  assert.equal(tab.bootstrapReady, true);
  assert.equal(ownershipMarks, 1);
  assert.equal(emulations.length, 1, "finishing resource loads must not resize the document again");
  contents.emit("did-start-navigation", {}, contents.getURL(), false, true);
  host.syncViewVisibility();
  assert.equal(tab.rendererReady, false);
  assert.equal(emulations.length, 1);
  contents.emit("dom-ready");
  assert.equal(emulations.length, 2, "each new document needs its viewport restored");
});

test("visible turn tabs keep the explicit viewport across background transitions", () => {
  const events = [];
  const tab = {
    id: "tab-visible-viewport",
    status: "running",
    rendererReady: true,
    deviceEmulationViewport: { width: 840, height: 656 },
    deviceEmulationDirty: false,
    view: {
      setBounds: bounds => events.push(["bounds", bounds]),
      setVisible: visible => events.push(["visible", visible]),
      webContents: {
        enableDeviceEmulation: options => events.push(["emulate", options]),
        disableDeviceEmulation: () => events.push(["disable-emulation"]),
      },
    },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    visible: true,
    surfaceActive: true,
    boundsReady: true,
    bounds: { x: 280, y: 64, width: 840, height: 656 },
    selectedTabId: tab.id,
    turnTabs: new Map([[tab.id, tab]]),
    authView: null,
    window: {
      getContentSize: () => [1120, 720],
      isMinimized: () => false,
      isVisible: () => true,
    },
    view: {
      setBounds: bounds => events.push(["home-bounds", bounds]),
      setVisible: visible => events.push(["home-visible", visible]),
    },
  });

  BrowserHost.prototype.syncViewVisibility.call(fixture);

  assert.deepEqual(events, [
    ["home-bounds", { x: 1121, y: 721, width: 840, height: 656 }],
    ["home-visible", true],
    ["bounds", { x: 280, y: 64, width: 840, height: 656 }],
    ["visible", true],
  ]);
  assert.deepEqual(tab.deviceEmulationViewport, { width: 840, height: 656 });
  assert.equal(tab.deviceEmulationDirty, false);
});

test("manual browser operations wait for the first measured surface", async () => {
  let readinessReads = 0;
  const fixture = {
    surfaceActive: true,
    get boundsReady() {
      readinessReads += 1;
      return readinessReads >= 3;
    },
  };

  await BrowserHost.prototype.waitForSurfaceReady.call(fixture, 5_000, 1);

  assert.equal(readinessReads, 3);
});

test("manual browser operations fail closed without measured surface bounds", async () => {
  await assert.rejects(
    BrowserHost.prototype.waitForSurfaceReady.call(
      { surfaceActive: true, boundsReady: false },
      2,
      1,
    ),
    /did not receive measured bounds/,
  );
});

test("browser bounds are clipped to the launcher content area", () => {
  assert.deepEqual(
    constrainBrowserBounds({ x: 260, y: 78, width: 1000, height: 900 }, { width: 1200, height: 800 }),
    { x: 260, y: 78, width: 940, height: 722 },
  );
  assert.deepEqual(
    constrainBrowserBounds({ x: -20, y: -10, width: 0, height: 0 }, { width: 1200, height: 800 }),
    { x: 0, y: 0, width: 1, height: 1 },
  );
});

test("zoomed renderer bounds are converted back to native window coordinates", () => {
  assert.deepEqual(
    scaleBrowserBounds({ x: 200, y: 60, width: 800, height: 500 }, 1.25),
    { x: 250, y: 75, width: 1000, height: 625 },
  );
  assert.throws(
    () => scaleBrowserBounds({ x: 1, y: 1, width: 1, height: 1 }, 0),
    /zoom factor must be positive/,
  );
});

test("shell zoom shortcuts recognize native CommandOrControl keys only", () => {
  const keyDown = { type: "keyDown", key: "=", meta: true, control: false, alt: false };

  assert.equal(shellZoomActionForInput(keyDown, "darwin"), "in");
  assert.equal(shellZoomActionForInput({ ...keyDown, key: "-" }, "darwin"), "out");
  assert.equal(shellZoomActionForInput({ ...keyDown, key: "0" }, "darwin"), "reset");
  assert.equal(
    shellZoomActionForInput({ ...keyDown, meta: false, control: true }, "win32"),
    "in",
  );
  assert.equal(shellZoomActionForInput({ ...keyDown, meta: false }, "darwin"), null);
  assert.equal(shellZoomActionForInput({ ...keyDown, key: "r" }, "darwin"), null);
  assert.equal(shellZoomActionForInput({ ...keyDown, type: "keyUp" }, "darwin"), null);
  assert.equal(shellZoomActionForInput({ ...keyDown, alt: true }, "darwin"), null);
});

test("guest and incomplete server sessions do not prove launcher authentication", async () => {
  const fixture = {
    state: { authenticated: true },
    activeTraceId: null,
    manualOperation: null,
    view: {
      webContents: {
        isDestroyed: () => false,
        getURL: () => "https://chatgpt.com/?temporary-chat=true",
        executeJavaScript: async () => ({
          composer: true,
          temporary: true,
          sessionAuthenticated: false,
          readyState: "complete",
        }),
      },
    },
    setState(patch) { this.state = { ...this.state, ...patch }; },
    snapshot() { return { ...this.state }; },
    logger: { info() {} },
  };

  const result = await BrowserHost.prototype.probeAuthentication.call(fixture);
  assert.equal(result.authenticated, false);
  assert.equal(result.status, "signed-out");
});

test("launcher authentication is established by the complete server session", async () => {
  const fixture = {
    state: { authenticated: false },
    activeTraceId: null,
    manualOperation: null,
    view: {
      webContents: {
        isDestroyed: () => false,
        getURL: () => "https://chatgpt.com/?temporary-chat=true",
        executeJavaScript: async () => ({
          composer: true,
          temporary: true,
          sessionAuthenticated: true,
          readyState: "complete",
        }),
      },
    },
    setState(patch) { this.state = { ...this.state, ...patch }; },
    snapshot() { return { ...this.state }; },
    logger: { info() {} },
  };

  const result = await BrowserHost.prototype.probeAuthentication.call(fixture);
  assert.equal(result.authenticated, true);
  assert.equal(result.status, "ready");
});

test("a verified session stays signed in while its composer is unavailable", async () => {
  const vm = require("node:vm");
  const { createDocument } = require("@mixmark-io/domino");
  const url = "https://chatgpt.com/?temporary-chat=true";
  for (const owned of [true, false]) {
    const document = createDocument(`<form ${owned ? "data-chatgpt-composer" : ""}>
      <div data-composer-markdown contenteditable="true" role="textbox"></div></form>`);
    const editor = document.querySelector("[data-composer-markdown]");
    Object.defineProperties(editor, {
      isConnected: { value: true },
      getBoundingClientRect: { value: () => ({ width: 300, height: 60 }) },
    });
    const fixture = {
      state: { authenticated: false }, activeTraceId: null, manualOperation: null,
      view: { webContents: {
        isDestroyed: () => false, getURL: () => url,
        executeJavaScript: script => vm.runInNewContext(script, {
          location: { href: url },
          document: { readyState: "complete", querySelectorAll: selector => document.querySelectorAll(selector) },
          getComputedStyle: () => ({ display: "block", visibility: "visible", opacity: "1" }),
          URL, AbortController, setTimeout, clearTimeout,
          fetch: async () => ({ ok: true, status: 200, url: "https://chatgpt.com/api/auth/session",
            headers: { get: () => "application/json" },
            json: async () => ({ user: { id: "fixture" }, expires: "2099-01-01T00:00:00Z" }),
          }),
        }),
      } },
      setState(patch) { this.state = { ...this.state, ...patch }; },
      snapshot() { return { ...this.state }; }, logger: { info() {} },
    };
    const result = await BrowserHost.prototype.probeAuthentication.call(fixture);
    assert.equal(result.authenticated, true);
  }
});

test("session verification distinguishes a missing login from network and invalid-response failures", async () => {
  const vm = require("node:vm");
  const url = "https://chatgpt.com/?temporary-chat=true";
  const sessionUrl = "https://chatgpt.com/api/auth/session";
  const response = (payload, overrides = {}) => ({
    ok: true, status: 200, url: sessionUrl,
    headers: { get: () => "application/json" }, json: async () => payload, ...overrides,
  });
  const validSession = { user: { id: "fixture" }, expires: "2099-01-01T00:00:00Z" };
  const cases = [
    { name: "valid", fetch: async () => response(validSession), status: "ready", authenticated: true },
    { name: "guest", fetch: async () => response({}), status: "signed-out" },
    { name: "expired", fetch: async () => response({ ...validSession, expires: "2000-01-01T00:00:00Z" }), status: "signed-out" },
    { name: "unauthorized", fetch: async () => response(null, { ok: false, status: 401 }), status: "signed-out" },
    { name: "network", fetch: async () => { throw new Error("private-proxy-secret"); }, status: "error", message: /connection|network/i },
    { name: "deadline", timeout: true, fetch: async (_url, { signal }) => {
      await new Promise(resolve => setImmediate(resolve));
      signal.throwIfAborted();
      throw new Error("Expected the session deadline to abort");
    }, status: "error", message: /timed out/i },
    { name: "server", fetch: async () => response(null, { ok: false, status: 503 }), status: "error", message: /503/ },
    { name: "html", fetch: async () => response(null, { headers: { get: () => "text/html" } }), status: "error" },
    { name: "redirect", fetch: async (_url, options) => {
      assert.equal(options.redirect, "error");
      throw new TypeError("Redirect rejected");
    }, status: "error" },
    { name: "invalid JSON", fetch: async () => response(null, { json: async () => { throw new SyntaxError("private-response"); } }), status: "error" },
    { name: "renderer", rendererError: true, status: "error", message: /browser/i },
  ];
  for (const item of cases) {
    const fixture = {
      state: { authenticated: true }, activeTraceId: null, manualOperation: null,
      view: { webContents: {
        isDestroyed: () => false, getURL: () => url,
        executeJavaScript: async script => {
          if (item.rendererError) throw new Error("private-renderer-error");
          return await vm.runInNewContext(script, {
            location: { href: url }, document: { readyState: "complete", querySelectorAll: () => [{
              isConnected: true, getBoundingClientRect: () => ({ width: 100, height: 30 }),
            }] }, getComputedStyle: () => ({ display: "block", visibility: "visible", opacity: "1" }),
            URL, AbortController, fetch: item.fetch,
            setTimeout: callback => item.timeout ? setImmediate(callback) : null,
            clearTimeout: handle => handle && clearImmediate(handle),
          });
        },
      } },
      setState(patch) { this.state = { ...this.state, ...patch }; },
      snapshot() { return { ...this.state }; }, logger: { info() {} },
    };
    const result = await BrowserHost.prototype.probeAuthentication.call(fixture);
    assert.equal(result.status, item.status, item.name);
    assert.equal(result.authenticated, item.authenticated === true, item.name);
    if (item.message) assert.match(result.message, item.message, item.name);
    assert.doesNotMatch(JSON.stringify(result), /private-/);
  }
});

test("authentication windows stay inside the launcher-owned browser partition", () => {
  assert.equal(allowedAuthUrl("https://accounts.google.com/o/oauth2/v2/auth"), true);
  assert.equal(allowedAuthUrl("https://chatgpt.com/auth/login"), true);
  assert.equal(allowedAuthUrl("https://platform.openai.com/settings/organization/tunnels"), false);
  assert.equal(allowedAuthUrl("https://example.com/login"), false);
  const source = fs.readFileSync(require.resolve("../electron/browser-host.cjs"), "utf8");
  assert.match(source, /createWindow:\s*\(options\)\s*=>\s*this\.createAuthView\(options,\s*url\)/);
  assert.match(source, /webContents:\s*options\.webContents/);
  assert.doesNotMatch(source, /loginWithSystemBrowser|captureSystemBrowserLogin|system_login_started/);
});

test("automatic turns allow transient ChatGPT auth redirects and block only settled login surfaces", () => {
  const contents = new EventEmitter();
  let currentUrl = "https://chatgpt.com/?temporary-chat=true";
  contents.setWindowOpenHandler = () => {};
  contents.getURL = () => currentUrl;
  const blocked = [];
  const host = Object.assign(Object.create(BrowserHost.prototype), {
    logger: { info() {}, warn() {}, error() {} },
    manualTurns: { navigation() {} },
    publishState() {},
    snapshot() { return {}; },
    syncViewVisibility() {},
    markTurnAuthenticationRequired(tab) { blocked.push(tab.url); },
  });
  const tab = {
    id: "automatic-auth-redirect",
    traceId: "automatic-auth-redirect",
    interactionMode: "automatic",
    initializingSurface: false,
    view: { webContents: contents },
  };
  host.bindTurnContents(tab);

  let prevented = false;
  contents.emit("will-redirect", { preventDefault: () => { prevented = true; } },
    "https://chatgpt.com/auth/login", false, true);
  assert.equal(prevented, false);
  assert.deepEqual(blocked, []);

  contents.emit("will-redirect", { preventDefault: () => { prevented = true; } },
    "https://accounts.google.com/o/oauth2/v2/auth", false, true);
  assert.equal(prevented, true);
  assert.equal(blocked.length, 1);

  currentUrl = "https://chatgpt.com/auth/login";
  contents.emit("did-finish-load");
  assert.equal(blocked.length, 2);
});

test("concurrent authentication probes share the same navigation and allow the next refresh", async () => {
  let probes = 0;
  let navigations = 0;
  let release;
  let temporary = false;
  const ready = new Promise(resolve => { release = resolve; });
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map(),
    state: { authenticated: false }, manualOperation: "ChatGPT login",
    view: { webContents: {
      isDestroyed: () => false,
      getURL: () => "https://chatgpt.com/",
      executeJavaScript: async () => {
        probes += 1;
        await ready;
        return { composer: true, temporary, sessionAuthenticated: true, url: "https://chatgpt.com/", readyState: "complete" };
      },
      loadURL: async () => { navigations += 1; temporary = true; },
    } },
    setState(patch) { this.state = { ...this.state, ...patch }; },
    snapshot() { return this.state; }, logger: { info() {} },
  });
  const first = fixture.probeAuthentication();
  const second = fixture.probeAuthentication();
  release();
  await Promise.all([first, second]);
  assert.equal(navigations, 1);
  assert.equal(probes, 2); // initial surface, then the one navigated temporary surface
  await fixture.probeAuthentication();
  assert.equal(probes, 3); // the settled operation must not cache stale authentication
});

test("shared session changes refresh hidden sign-in state without navigating any tab", async () => {
  const cookies = new EventEmitter();
  const requests = [];
  let payload = {};
  let mode = "automatic";
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    state: { authenticated: true, status: "ready" },
    turnTabs: new Map(),
    getBrowserInteractionMode: () => mode,
    view: { webContents: { isDestroyed: () => false, getURL: () => IDLE_BROWSER_URL, session: {
      cookies,
      fetch: async (url, options) => {
        requests.push({ url, options });
        await new Promise(resolve => setImmediate(resolve));
        cookies.emit("changed", {}, { httpOnly: true, domain: "chatgpt.com" }, "overwrite", true);
        cookies.emit("changed", {}, { httpOnly: true, domain: "chatgpt.com" }, "inserted", false);
        // Electron net.fetch returns an empty Response.url, unlike renderer fetch.
        return { url: "", ok: true, status: 200, headers: { get: () => "application/json" }, json: async () => payload };
      },
    } } },
    setState(patch) { this.state = { ...this.state, ...patch }; },
    logger: { warn() { assert.fail("Session refresh failed"); } },
  });
  fixture.bindAuthenticationChanges();
  const notify = cookie => cookies.emit("changed", {}, cookie, "explicit", true);
  notify({ httpOnly: false, domain: ".chatgpt.com" });
  notify({ httpOnly: true, domain: "example.com" });
  assert.equal(requests.length, 0);
  notify({ httpOnly: true, domain: ".chatgpt.com" });
  await fixture.authenticationRefresh;
  assert.equal(fixture.state.authenticated, false);
  assert.equal(fixture.state.status, "signed-out");
  payload = { user: { id: "test" }, expires: "2099-01-01T00:00:00Z" };
  notify({ httpOnly: true, domain: "chatgpt.com" });
  await fixture.authenticationRefresh;
  assert.equal(fixture.state.authenticated, true);
  assert.equal(fixture.state.status, "ready");
  assert.equal(requests[0].url, "https://chatgpt.com/api/auth/session");
  assert.equal(requests[0].options.credentials, "include");
  assert.equal(requests[0].options.redirect, "error");
  mode = "manual";
  notify({ httpOnly: true, domain: "chatgpt.com" });
  assert.equal(requests.length, 2);
  mode = "automatic";
  fixture.destroyed = true;
  notify({ httpOnly: true, domain: "chatgpt.com" });
  assert.equal(requests.length, 2);
});

test("a later sign-out wins over pending native and page authentication probes", async () => {
  let finishNative;
  let finishPage;
  let requests = 0;
  let url = "https://chatgpt.com/?temporary-chat=true";
  const updates = [];
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    authenticationRevision: 0, state: { authenticated: false },
    turnTabs: new Map(),
    view: { webContents: {
      getURL: () => url, isDestroyed: () => false,
      executeJavaScript: () => new Promise(resolve => { finishPage = resolve; }),
      session: { fetch: async url => {
        requests += 1;
        const payload = requests === 1 ? await new Promise(resolve => { finishNative = resolve; }) : {};
        return { url, ok: true, status: 200, headers: { get: () => "application/json" }, json: async () => payload };
      } },
    } },
    setState(patch) { updates.push(patch); this.state = { ...this.state, ...patch }; },
    snapshot() { return this.state; }, logger: { info() {}, warn() {} },
  });
  const page = fixture.probeAuthentication();
  url = IDLE_BROWSER_URL;
  const first = fixture.refreshAuthenticationFromSession();
  const second = fixture.refreshAuthenticationFromSession();
  assert.equal(first, second);
  finishNative({ user: { id: "previous-account" } });
  await second;
  finishPage({ composer: true, temporary: true, sessionAuthenticated: true });
  await page;
  assert.equal(requests, 2);
  assert.equal(updates.length, 1);
  assert.equal(fixture.state.authenticated, false);
  assert.equal(updates.some(update => update.authenticated === true), false);
});

test("session changes use the open page after invalidating an older check", async () => {
  for (const result of [
    { sessionAuthenticated: true, expected: "ready" },
    { sessionAuthenticated: false, expected: "signed-out" },
    { sessionAuthenticated: false, sessionCheckError: "HTTP 403", expected: "error" },
  ]) {
    let finishOld;
    let pageChecks = 0;
    const fixture = Object.assign(Object.create(BrowserHost.prototype), {
      authenticationRevision: 0, state: { authenticated: false }, turnTabs: new Map(),
      view: { webContents: {
        getURL: () => "https://chatgpt.com/?temporary-chat=true", isDestroyed: () => false,
        executeJavaScript: async () => {
          pageChecks++;
          if (pageChecks === 1) await new Promise(resolve => { finishOld = resolve; });
          return { composer: true, temporary: true, readyState: "complete", ...result };
        },
        session: { fetch: async () => { assert.fail("A loaded ChatGPT page owns session verification"); } },
      } },
      setState(patch) { this.state = { ...this.state, ...patch }; },
      snapshot() { return this.state; }, logger: { info() {}, warn() {} },
    });
    const old = fixture.probeAuthentication();
    const refresh = fixture.refreshAuthenticationFromSession();
    finishOld();
    await Promise.all([old, refresh]);
    assert.equal(pageChecks, 2);
    assert.equal(fixture.state.authenticated, result.sessionAuthenticated);
    assert.equal(fixture.state.status, result.expected);
  }
});

test("sign-out during a refreshed page check rejects its earlier signed-in result", async () => {
  let finishPage;
  let pageChecks = 0;
  const updates = [];
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    authenticationRevision: 0, state: { authenticated: false }, turnTabs: new Map(),
    view: { webContents: {
      getURL: () => "https://chatgpt.com/?temporary-chat=true", isDestroyed: () => false,
      executeJavaScript: async () => {
        const check = ++pageChecks;
        if (check === 1) await new Promise(resolve => { finishPage = resolve; });
        return { sessionAuthenticated: check === 1, readyState: "complete", composer: true, temporary: true };
      },
      session: { fetch: async () => { assert.fail("Must use the loaded page"); } },
    } },
    setState(patch) { updates.push(patch); this.state = { ...this.state, ...patch }; },
    snapshot() { return this.state; }, logger: { info() {}, warn() {} },
  });
  const first = fixture.refreshAuthenticationFromSession();
  const second = fixture.refreshAuthenticationFromSession();
  finishPage();
  await Promise.all([first, second]);
  assert.equal(pageChecks, 2);
  assert.equal(fixture.state.authenticated, false);
  assert.equal(fixture.state.status, "signed-out");
  assert.equal(updates.some(update => update.authenticated === true), false);
});

test("in-page account navigation schedules authentication refresh only for the main frame", async () => {
  const contents = Object.assign(new EventEmitter(), { setWindowOpenHandler() {} });
  let checks = 0;
  const fixture = { view: { webContents: contents }, setState() {},
    refreshAuthenticationFromSession: async () => { checks += 1; },
  };
  BrowserHost.prototype.bindWebContents.call(fixture);
  contents.emit("did-navigate-in-page", {}, "https://chatgpt.com/", false);
  assert.equal(checks, 0);
  contents.emit("did-navigate-in-page", {}, "https://chatgpt.com/", true);
  assert.equal(checks, 1);
});

test("concurrent embedded login requests share one authentication operation", async () => {
  let resolveLogin;
  let waits = 0;
  let inspections = 0;
  const fixture = {
    state: { authenticated: false },
    authNavigationError: null,
    loginOperation: null,
    show() {},
    snapshot() { return { authenticated: false }; },
    logger: { info() {} },
    view: {
      webContents: {
        getURL: () => "https://chatgpt.com/?temporary-chat=true",
        loadURL: async () => {},
      },
    },
    probeAuthentication: async () => ({ authenticated: false, status: "signed-out" }),
    waitForAuthenticated: async () => {
      waits += 1;
      return await new Promise((resolve) => { resolveLogin = resolve; });
    },
    runSessionInspection: async (detectCapabilities) => {
      assert.equal(detectCapabilities, false);
      inspections += 1;
    },
    activateHomeSurface() {},
    withManualOperation: async (_name, action) => await action(),
  };
  const first = BrowserHost.prototype.openLogin.call(fixture);
  const second = BrowserHost.prototype.openLogin.call(fixture);
  assert.equal(first, second);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(waits, 1);
  resolveLogin({ authenticated: true });
  assert.deepEqual(await first, { authenticated: true });
  assert.equal(inspections, 1);
});

test("explicit login waits for an in-flight saved-session refresh before taking browser ownership", async () => {
  const calls = [];
  let finishRefresh;
  const sessionRefreshOperation = new Promise((resolve) => { finishRefresh = resolve; });
  const fixture = {
    state: { authenticated: false },
    sessionRefreshOperation,
    loginOperation: null,
    authNavigationError: null,
    activateHomeSurface() {},
    show() {},
    snapshot: () => ({ authenticated: true }),
    logger: { info() {} },
    view: { webContents: {
      getURL: () => "https://chatgpt.com/?temporary-chat=true",
      loadURL: async () => {},
    } },
    probeAuthentication: async () => {
      calls.push("probe");
      return { authenticated: false, status: "signed-out" };
    },
    waitForAuthenticated: async () => ({ authenticated: true }),
    runSessionInspection: async () => calls.push("inspect"),
    withManualOperation: async (name, action) => {
      calls.push(name);
      return await action();
    },
  };

  const login = BrowserHost.prototype.openLogin.call(fixture);
  await Promise.resolve();
  assert.deepEqual(calls, []);
  finishRefresh();
  await login;
  assert.deepEqual(calls, ["ChatGPT login", "probe", "inspect"]);
});

test("choosing passkey during embedded sign-in switches the owned operation instead of swallowing the click", async () => {
  let finishCapture, opened;
  const capture = new Promise(resolve => { finishCapture = resolve; });
  const ready = new Promise(resolve => { opened = resolve; });
  let captures = 0;
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    state: { authenticated: false }, manualOperation: null, loginOperation: null,
    turnTabs: new Map(), ready: async () => {}, activateHomeSurface() {}, show() {}, hide() {},
    view: { webContents: { isDestroyed: () => false, setBackgroundThrottling() {}, loadURL: async () => {},
      getURL: () => "https://chatgpt.com/?temporary-chat=true" } },
    logger: { info() {} }, setState(patch) { Object.assign(this.state, patch); },
    snapshot() { return { ...this.state }; },
    probeAuthentication: async () => ({ authenticated: false }),
    loginWithPasskey: async onProgress => {
      captures++;
      onProgress("waiting");
      opened();
      await capture;
      return { storageState: {} };
    },
    installPasskeyLogin: async () => { fixture.setState({ authenticated: true, status: "ready" }); },
  });
  const embedded = fixture.openLogin();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(fixture.manualOperation, "ChatGPT login");
  const passkey = fixture.openPasskeyLogin();
  assert.equal(passkey, embedded);
  await ready;
  assert.equal(captures, 1);
  assert.equal(fixture.manualOperation, "ChatGPT passkey login");
  assert.equal(fixture.state.passkeyPhase, "waiting");
  assert.equal(fixture.openPasskeyLogin(), passkey);
  finishCapture();
  const result = await passkey;
  assert.equal(result.authenticated, true);
  assert.equal(result.passkeyPhase, null);
  assert.equal(fixture.manualOperation, null);
  assert.equal(fixture.loginOperation, null);
  assert.equal(fixture.loginMode, null);
});

test("failed passkey launch clears its progress and releases the browser operation", async () => {
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    state: { authenticated: false }, turnTabs: new Map(),
    ready: async () => {}, activateHomeSurface() {}, hide() {},
    view: { webContents: { isDestroyed: () => false, setBackgroundThrottling() {} } },
    logger: { info() {} }, setState(patch) { Object.assign(this.state, patch); },
    snapshot() { return { ...this.state }; },
    loginWithPasskey: async () => { throw new Error("Chrome could not start"); },
  });
  await assert.rejects(fixture.openPasskeyLogin(), /Chrome could not start/);
  assert.equal(fixture.state.passkeyPhase, null);
  assert.equal(fixture.state.loading, false);
  assert.equal(fixture.state.status, "error");
  assert.equal(fixture.state.authenticated, false);
  assert.equal(fixture.manualOperation, null);
  assert.equal(fixture.loginOperation, null);
});

test("passkey login imports only validated state and re-proves the Launcher session", async () => {
  const calls = [];
  const browserSession = {
    clearStorageData: async () => calls.push("clear"),
    flushStorageData: () => calls.push("flush-storage"),
    cookies: {
      set: async cookie => calls.push(["cookie", cookie]),
      flushStore: async () => calls.push("flush-cookies"),
    },
  };
  const contents = {
    session: browserSession,
    isDestroyed: () => false,
    loadURL: async url => calls.push(["load", url]),
    executeJavaScript: async script => calls.push(["script", script]),
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    authView: null,
    turnTabs: new Map(),
    view: { webContents: contents },
    state: { authenticated: false },
    waitForAuthenticated: async () => {
      calls.push("prove-session");
      fixture.state.authenticated = true;
      return { authenticated: true };
    },
    runSessionInspection: async detectCapabilities => calls.push(["inspect", detectCapabilities]),
    activateHomeSurface: () => calls.push("activate"),
    show: () => calls.push("show"),
    logger: { info: event => calls.push(["log", event]) },
    snapshot: () => ({ ...fixture.state }),
  });
  let cleaned = false;
  const result = await BrowserHost.prototype.installPasskeyLogin.call(fixture, {
    storageState: {
      cookies: [{
        name: "session",
        value: "private",
        domain: ".chatgpt.com",
        path: "/",
        expires: -1,
        httpOnly: true,
        secure: true,
        sameSite: "Lax",
      }],
      origins: [{ origin: "https://chatgpt.com", localStorage: [{ name: "setting", value: "value" }] }],
    },
    cleanup: async () => { cleaned = true; },
  });

  assert.equal(result.authenticated, true);
  assert.equal(cleaned, true);
  assert.equal(calls[0][0], "load");
  assert.match(calls[0][1], /^data:text\/html/);
  assert.equal(calls[1], "clear");
  assert.ok(calls.some(value => Array.isArray(value) && value[0] === "cookie"));
  assert.ok(calls.some(value => Array.isArray(value) && value[0] === "script" && value[1].includes("localStorage.setItem")));
  assert.ok(calls.includes("prove-session"));
  assert.ok(calls.some(value => Array.isArray(value) && value[0] === "inspect" && value[1] === false));
});

test("invalid passkey transfer is removed without mutating the embedded session", async () => {
  let cleared = false;
  let cleaned = false;
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map(),
    view: { webContents: {
      isDestroyed: () => false,
      session: { clearStorageData: async () => { cleared = true; } },
    } },
  });
  await assert.rejects(
    BrowserHost.prototype.installPasskeyLogin.call(fixture, {
      storageState: {
        cookies: [{
          name: "identity-provider",
          value: "private",
          domain: ".accounts.google.com",
          path: "/",
          expires: -1,
          httpOnly: true,
          secure: true,
          sameSite: "Lax",
        }],
        origins: [],
      },
      cleanup: async () => { cleaned = true; },
    }),
    /no ChatGPT\/OpenAI cookies/,
  );
  assert.equal(cleared, false);
  assert.equal(cleaned, true);
});

test("failed private-transfer cleanup also discards an otherwise imported passkey session", async () => {
  let resets = 0;
  const browserSession = {
    cookies: { set: async () => {}, flushStore: async () => {} },
    flushStorageData() {},
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    view: { webContents: {
      session: browserSession,
      isDestroyed: () => false,
      loadURL: async () => {},
    } },
    clearOwnedSessionForPasskey: async () => {},
    resetFailedPasskeyLogin: async () => { resets += 1; },
    waitForAuthenticated: async () => ({ authenticated: true }),
    runSessionInspection: async () => {},
    activateHomeSurface() {},
    show() {},
    logger: { info() {} },
    snapshot: () => ({ authenticated: true }),
  });
  await assert.rejects(
    BrowserHost.prototype.installPasskeyLogin.call(fixture, {
      storageState: {
        cookies: [{
          name: "session",
          value: "private",
          domain: ".chatgpt.com",
          path: "/",
          expires: -1,
          httpOnly: true,
          secure: true,
          sameSite: "Lax",
        }],
        origins: [],
      },
      cleanup: async () => { throw new Error("synthetic private-file lock"); },
    }),
    /Removing temporary passkey state failed/,
  );
  assert.equal(resets, 1);
});
test("launcher quit remains gated through an active embedded-browser operation", () => {
  const source = fs.readFileSync(require.resolve("../electron/main.cjs"), "utf8");
  assert.match(
    source,
    /runtimeHost\?\.currentOperation\(\) \|\| browserHost\?\.currentOperation\(\)/,
  );
});

test("logout clears only the owned ChatGPT session and returns to the sign-in surface", async () => {
  const calls = [];
  let currentUrl = "https://chatgpt.com/?temporary-chat=true";
  const authView = { webContents: { isDestroyed: () => false } };
  const fixture = {
    authView,
    state: { authenticated: true, status: "ready" },
    view: {
      webContents: {
        getURL: () => currentUrl,
        loadURL: async (url) => {
          calls.push(["loadURL", url]);
          currentUrl = url;
        },
        session: {
          clearStorageData: async () => calls.push(["clearStorageData"]),
        },
      },
    },
    closeAuthView(view, closeContents, refreshMain) {
      calls.push(["closeAuthView", view, closeContents, refreshMain]);
      this.authView = null;
    },
    setState(patch) {
      this.state = { ...this.state, ...patch };
      calls.push(["setState", patch]);
    },
    probeAuthentication: async function () {
      this.state = { ...this.state, authenticated: false, status: "signed-out" };
      calls.push(["probeAuthentication"]);
      return this.snapshot();
    },
    activateHomeSurface() { calls.push(["activateHomeSurface"]); },
    show() { calls.push(["show"]); },
    snapshot() { return { ...this.state, url: currentUrl }; },
    logger: { info(event) { calls.push(["log", event]); } },
    withManualOperation: async (name, action) => {
      calls.push(["manualOperation", name]);
      return await action();
    },
  };

  const result = await BrowserHost.prototype.logout.call(fixture);

  assert.equal(result.authenticated, false);
  assert.equal(result.status, "signed-out");
  assert.deepEqual(calls[0], ["manualOperation", "ChatGPT logout"]);
  assert.deepEqual(calls[1], ["closeAuthView", authView, true, false]);
  assert.deepEqual(calls[2], ["clearStorageData"]);
  assert.deepEqual(calls[4], ["loadURL", "https://chatgpt.com/?temporary-chat=true"]);
  assert.ok(calls.some(([name]) => name === "activateHomeSurface"));
  assert.ok(calls.some(([name]) => name === "show"));
});

test("launcher shutdown persists ChatGPT DOM storage and cookies before browser destruction", async () => {
  const calls = [];
  const fixture = {
    view: {
      webContents: {
        isDestroyed: () => false,
        session: {
          flushStorageData: () => calls.push("storage"),
          cookies: { flushStore: async () => calls.push("cookies") },
        },
      },
    },
  };

  await BrowserHost.prototype.persistSession.call(fixture);

  assert.deepEqual(calls, ["storage", "cookies"]);
});

test("OAuth completion is re-proved on the primary Temporary Chat surface before login succeeds", async () => {
  let primaryReady = false;
  const completedAuthView = {
    webContents: {
      isDestroyed: () => false,
      executeJavaScript: async () => ({
        composer: true,
        temporary: false,
        sessionAuthenticated: true,
        readyState: "complete",
      }),
    },
  };
  const fixture = {
    activeTraceId: null,
    manualOperation: "ChatGPT login",
    authView: completedAuthView,
    state: { authenticated: false },
    logger: { info() {} },
    view: {
      webContents: {
        getURL: () => primaryReady
          ? "https://chatgpt.com/?temporary-chat=true"
          : "https://chatgpt.com/auth/login",
        isDestroyed: () => false,
        executeJavaScript: async () => ({
          composer: primaryReady,
          temporary: primaryReady,
          sessionAuthenticated: primaryReady,
          readyState: "complete",
          url: primaryReady
            ? "https://chatgpt.com/?temporary-chat=true"
            : "https://chatgpt.com/auth/login",
        }),
        loadURL: async (url) => {
          assert.equal(url, "https://chatgpt.com/?temporary-chat=true");
          primaryReady = true;
        },
      },
    },
    closeAuthView(view, closeContents, refreshMain) {
      assert.equal(view, completedAuthView);
      assert.equal(closeContents, true);
      assert.equal(refreshMain, false);
      this.authView = null;
    },
    setState(patch) { this.state = { ...this.state, ...patch }; },
    snapshot() { return this.state; },
  };

  const result = await BrowserHost.prototype.probeAuthentication.call(fixture);
  assert.equal(result.authenticated, true);
  assert.equal(fixture.authView, null);
  assert.equal(result.url, "https://chatgpt.com/?temporary-chat=true");
});

test("a successful primary login redirect is re-proved on Temporary Chat before login completes", async () => {
  let currentUrl = "https://chatgpt.com/";
  const loadedUrls = [];
  const fixture = {
    activeTraceId: null,
    manualOperation: "ChatGPT login",
    authView: null,
    state: { authenticated: false },
    logger: { info() {} },
    view: {
      webContents: {
        getURL: () => currentUrl,
        isDestroyed: () => false,
        executeJavaScript: async () => ({
          composer: true,
          temporary: currentUrl === "https://chatgpt.com/?temporary-chat=true",
          sessionAuthenticated: true,
          readyState: "complete",
          url: currentUrl,
        }),
        loadURL: async (url) => {
          loadedUrls.push(url);
          currentUrl = url;
        },
      },
    },
    setState(patch) { this.state = { ...this.state, ...patch }; },
    snapshot() { return this.state; },
  };

  const result = await BrowserHost.prototype.probeAuthentication.call(fixture);

  assert.deepEqual(loadedUrls, ["https://chatgpt.com/?temporary-chat=true"]);
  assert.equal(result.authenticated, true);
  assert.equal(result.url, "https://chatgpt.com/?temporary-chat=true");
});

test("an authenticated primary surface closes a stale embedded auth popup", async () => {
  const staleAuthView = {
    webContents: {
      isDestroyed: () => false,
      executeJavaScript: async () => ({
        composer: false,
        temporary: false,
        sessionAuthenticated: false,
        readyState: "complete",
      }),
    },
  };
  const closed = [];
  const fixture = {
    activeTraceId: null,
    manualOperation: "connector verification",
    authView: staleAuthView,
    state: { authenticated: true },
    logger: { info() {} },
    view: {
      webContents: {
        getURL: () => "https://chatgpt.com/?temporary-chat=true",
        isDestroyed: () => false,
        executeJavaScript: async () => ({
          composer: true,
          temporary: true,
          sessionAuthenticated: true,
          readyState: "complete",
          url: "https://chatgpt.com/?temporary-chat=true",
        }),
      },
    },
    closeAuthView(view, closeContents, refreshMain) {
      closed.push([view, closeContents, refreshMain]);
      this.authView = null;
    },
    setState(patch) { this.state = { ...this.state, ...patch }; },
    snapshot() { return this.state; },
  };

  const result = await BrowserHost.prototype.probeAuthentication.call(fixture);
  assert.equal(result.authenticated, true);
  assert.equal(fixture.authView, null);
  assert.deepEqual(closed, [[staleAuthView, true, false]]);
});

test("browser chrome navigation delegates to WebContents navigation history", () => {
  const { calls, webContents } = createContents();
  navigateBrowser(webContents, "back");
  navigateBrowser(webContents, "forward");
  navigateBrowser(webContents, "reload");

  assert.deepEqual(calls, ["back", "reload"]);
  assert.throws(() => navigateBrowser(webContents, "unknown"), /Unknown browser navigation action/);
});

test("browser zoom in, out, and reset are symmetric across owned views", () => {
  const home = createContents();
  const turn = createContents();
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    state: { zoomFactor: 1 },
    view: { webContents: home.webContents },
    turnTabs: new Map([["turn", { view: { webContents: turn.webContents } }]]),
    snapshot() { return { zoomFactor: this.state.zoomFactor }; },
    setState(patch) { this.state = { ...this.state, ...patch }; },
    publishState() {},
  });

  assert.equal(BrowserHost.prototype.zoom.call(fixture, "in").zoomFactor, 1.1);
  assert.equal(BrowserHost.prototype.zoom.call(fixture, "out").zoomFactor, 1);
  BrowserHost.prototype.zoom.call(fixture, "in");
  assert.equal(BrowserHost.prototype.zoom.call(fixture, "reset").zoomFactor, 1);
  assert.deepEqual(home.calls.filter((call) => Array.isArray(call) && call[0] === "zoom"), [
    ["zoom", 1.1],
    ["zoom", 1],
    ["zoom", 1.1],
    ["zoom", 1],
  ]);
  assert.deepEqual(turn.calls.filter((call) => Array.isArray(call) && call[0] === "zoom"), [
    ["zoom", 1.1],
    ["zoom", 1],
    ["zoom", 1.1],
    ["zoom", 1],
  ]);
  assert.throws(() => BrowserHost.prototype.zoom.call(fixture, "fit"), /Unknown browser zoom action/);
});

test("Command zoom changes only the launcher shell while browser zoom stays independent", () => {
  const focusedBrowserContents = new EventEmitter();
  focusedBrowserContents.isDestroyed = () => false;
  let shellZoomLevel = 0;
  const shellContents = {
    getZoomLevel: () => shellZoomLevel,
    isDestroyed: () => false,
    setZoomLevel: (next) => { shellZoomLevel = next; },
  };
  const originalBounds = { x: 280, y: 76, width: 840, height: 644 };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    state: { zoomFactor: 1 },
    bounds: originalBounds,
    window: { webContents: shellContents },
    shellZoomShortcutBindings: new Map(),
    logger: { error() {} },
  });
  let prevented = 0;

  BrowserHost.prototype.bindShellZoomShortcuts.call(fixture, focusedBrowserContents);
  focusedBrowserContents.emit(
    "before-input-event",
    { preventDefault: () => { prevented += 1; } },
    {
      type: "keyDown",
      key: "=",
      meta: process.platform === "darwin",
      control: process.platform !== "darwin",
      alt: false,
    },
  );

  assert.equal(prevented, 1);
  assert.equal(shellZoomLevel, 0.5);
  assert.equal(fixture.state.zoomFactor, 1);
  assert.deepEqual(fixture.bounds, originalBounds);
});

test("browser chrome state is read from the owned WebContents", () => {
  const { webContents } = createContents();
  const state = readBrowserNavigationState(webContents, {
    title: "Fallback",
    url: "about:blank",
    loading: true,
    canGoBack: false,
    canGoForward: true,
  });
  assert.deepEqual(state, {
    title: "ChatGPT",
    url: "https://chatgpt.com/?temporary-chat=true",
    loading: false,
    canGoBack: true,
    canGoForward: false,
  });
});

test("launcher delegates every ChatGPT model and turn operation to the shared browser worker", async () => {
  const calls = [];
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    helper: { executable: "/runtime/electron", script: "/runtime/browser-helper.cjs" },
    descriptorPath: "/runtime/launcher-browser.json",
    getConnectorName: () => "Codex Native2",
    logger: { info: (...args) => calls.push(["log", ...args]) },
    show: () => calls.push(["show"]),
    waitForSurfaceReady: async () => calls.push(["ready"]),
    setState: patch => calls.push(["state", patch]),
    runBrowserHelperOperation: async options => {
      calls.push(["helper", options]);
      return { type: "result", value: { effort: "High", response: "CODEX WEB GPT READY" } };
    },
  });

  assert.deepEqual(await BrowserHost.prototype.runSmokeTest.call(fixture), {
    ok: true,
    effort: "High",
    response: "CODEX WEB GPT READY",
  });
  const helperCall = calls.find(call => call[0] === "helper")[1];
  assert.equal(helperCall.operation, "smoke");
  assert.equal(helperCall.appName, "Codex Native2");
});

test("browser helper operations fail closed when the configured connector name is invalid", async () => {
  let helperCalls = 0;
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    getConnectorName: () => "   ",
    runBrowserHelperOperation: async () => { helperCalls += 1; },
  });

  await assert.rejects(
    BrowserHost.prototype.runSmokeTest.call(fixture),
    /Connector name is invalid/,
  );
  assert.equal(helperCalls, 0);
});

test("connector verification is effort-independent and works while the browser surface is hidden", async () => {
  const calls = [];
  const fixture = {
    helper: { executable: "/runtime/electron", script: "/runtime/browser-helper.cjs" },
    descriptorPath: "/runtime/launcher-browser.json",
    logger: { info: (event, detail) => calls.push(["log", event, detail]) },
    setState: (patch) => calls.push(["state", patch]),
    show: () => calls.push(["show"]),
    refreshChatGptHomeDocument: async () => calls.push(["refresh"]),
    selectHighEffort: async () => {
      throw new Error("connector verification must not select an effort");
    },
    verifyConnectorWithBrowserHelper: async (options) => {
      calls.push(["helper", options]);
      return { ok: true, appName: options.appName };
    },
  };

  const result = await BrowserHost.prototype.runConnectorVerification.call(fixture, "Codex Native2");

  assert.deepEqual(result, { ok: true, appName: "Codex Native2" });
  assert.equal(calls.some(([type]) => type === "show"), false);
  assert.deepEqual(
    calls.filter(([type]) => ["refresh", "helper"].includes(type)),
    [
      ["refresh"],
      ["helper", {
        helper: fixture.helper,
        descriptorPath: fixture.descriptorPath,
        appName: "Codex Native2",
        logger: fixture.logger,
      }],
    ],
  );
});

test("connector verification records the helper failure in launcher diagnostics", async () => {
  const calls = [];
  const failure = new Error("private-account private-composer https://chatgpt.com/?secret=value");
  failure.name = "ChatGptPersistentBrowserStateError";
  failure.operationId = "verify-contract-trace";
  const fixture = {
    helper: { executable: "/runtime/electron", script: "/runtime/browser-helper.cjs" },
    descriptorPath: "/runtime/launcher-browser.json",
    logger: {
      info: (event, detail) => calls.push(["info", event, detail]),
      error: (event, detail) => calls.push(["error", event, detail]),
    },
    setState: (patch) => calls.push(["state", patch]),
    refreshChatGptHomeDocument: async () => calls.push(["refresh"]),
    verifyConnectorWithBrowserHelper: async () => { throw failure; },
  };

  await assert.rejects(
    BrowserHost.prototype.runConnectorVerification.call(fixture, "Codex Native2"),
    failure,
  );
  assert.deepEqual(calls.find(call => call[1] === "connector.verification_failed"), [
    "error",
    "connector.verification_failed",
    {
      traceId: "verify-contract-trace",
      classification: "cleanup_failed",
    },
  ]);
});

test("a live helper retains exclusive ownership of its running turn", async () => {
  const tab = {
    id: "tab-live-owner",
    traceId: "trace_live_owner",
    helperPid: process.pid,
    status: "running",
    interactionMode: "automatic",
  };
  await assert.rejects(
    () => BrowserHost.prototype.beginTurn.call({
      manualOperation: null,
      turnTabs: new Map([[tab.id, tab]]),
      userCancelledTurnOwners: new Map(),
    }, tab.traceId, false, process.pid + 1),
    /owned by another helper process/,
  );
});

test("a replacement helper takes over only after the previous owner exited", async () => {
  const deadPid = 2_147_483_647;
  const tab = {
    id: "tab-dead-owner",
    surfaceId: "surface-dead-owner",
    traceId: "trace_dead_owner",
    helperPid: deadPid,
    status: "running",
    interactionMode: "automatic",
    loading: true,
    message: "ChatGPT is working",
    view: {
      webContents: {
        isDestroyed: () => false,
        setBackgroundThrottling() {},
      },
    },
  };
  const warnings = [];
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    manualOperation: null,
    turnTabs: new Map([[tab.id, tab]]),
    userCancelledTurnOwners: new Map(),
    selectedTabId: "home",
    syncViewVisibility() {},
    snapshot: () => ({ tabs: [] }),
    publishState() {},
    writeDescriptor() {},
    logger: { info() {}, warn: (event, detail) => warnings.push([event, detail]) },
  });

  const lease = await BrowserHost.prototype.beginTurn.call(fixture, tab.traceId, false, process.pid);

  assert.deepEqual(lease, { surfaceId: tab.surfaceId, tabId: tab.id, reused: false });
  assert.equal(tab.helperPid, process.pid);
  assert.equal(warnings.length, 1);
  assert.equal(warnings[0][0], "browser.stale_turn_owner_replaced");
  assert.equal(warnings[0][1].previousHelperPid, deadPid);
});

test("a live turn heartbeat refreshes its lease and rejects another helper", () => {
  const tab = {
    id: "tab-heartbeat",
    traceId: "trace_heartbeat",
    helperPid: 444,
    status: "running",
    lastHeartbeatAt: 1,
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map([[tab.id, tab]]),
    closedTurnOwners: new Map(),
    snapshot: () => ({ activeTabId: tab.id }),
  });

  const before = Date.now();
  const snapshot = BrowserHost.prototype.heartbeatTurn.call(fixture, tab.traceId, tab.helperPid);

  assert.deepEqual(snapshot, { activeTabId: tab.id });
  assert.ok(tab.lastHeartbeatAt >= before);
  assert.throws(
    () => BrowserHost.prototype.heartbeatTurn.call(fixture, tab.traceId, 445),
    /ownership mismatch: expected 444, received 445/,
  );
});

test("an uninitialized browser surface cancels runtime ownership before reaping the gray orphan tab", async () => {
  const closed = [];
  const warnings = [];
  const tab = {
    id: "tab-orphan",
    traceId: "trace_orphan",
    helperPid: 555,
    status: "running",
    loading: true,
    bootstrapReady: false,
    bootstrapDeadlineAt: 100,
    lastHeartbeatAt: 100,
    view: {
      webContents: {
        isDestroyed: () => false,
        close: () => closed.push("contents"),
      },
    },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map([[tab.id, tab]]),
    closedTurnOwners: new Map(),
    selectedTabId: tab.id,
    window: { contentView: { removeChildView: () => closed.push("view") } },
    syncViewVisibility() {},
    snapshot: () => ({ tabs: [] }),
    publishState() {},
    writeDescriptor() {},
    cancelTurn: async (traceId, reason) => closed.push(`cancel:${traceId}:${reason}`),
    logger: { warn: (event, detail) => warnings.push([event, detail]) },
  });

  await BrowserHost.prototype.reapExpiredTurnTabs.call(fixture, 101);

  assert.equal(fixture.turnTabs.size, 0);
  assert.equal(fixture.selectedTabId, "home");
  assert.deepEqual(fixture.closedTurnOwners.get(tab.traceId), { helperPid: tab.helperPid, remainingAcks: 2 });
  assert.deepEqual(closed, ["cancel:trace_orphan:browser_surface_bootstrap_timeout", "view", "contents"]);
  const detail = {
    tabId: tab.id,
    traceId: tab.traceId,
    helperPid: tab.helperPid,
    evidence: "browser_surface_bootstrap_timeout",
  };
  assert.deepEqual(warnings, [
    ["browser.orphan_turn_expired", detail],
    ["browser.orphan_turn_reaped", detail],
  ]);
});

test("removing the final turn tab hides an uninitialized idle host instead of exposing gray content", () => {
  const calls = [];
  const tab = {
    id: "tab-gray-host",
    traceId: "trace_gray_host",
    helperPid: 666,
    status: "aborted",
    view: {
      webContents: {
        isDestroyed: () => false,
        close: () => calls.push("contents-close"),
      },
    },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map([[tab.id, tab]]),
    closedTurnOwners: new Map(),
    selectedTabId: tab.id,
    window: { contentView: { removeChildView: () => calls.push("view-remove") } },
    view: { webContents: { getURL: () => IDLE_BROWSER_URL } },
    syncViewVisibility() {},
    hide: () => calls.push("hide"),
    snapshot: () => ({ tabs: [] }),
    publishState() {},
    writeDescriptor() {},
  });

  BrowserHost.prototype.removeTurnTab.call(fixture, tab, false);

  assert.deepEqual(calls, ["view-remove", "contents-close", "hide"]);
});

test("hard refresh accepts Chromium's completed loading cycle even without did-finish-load", async () => {
  const calls = [];
  const contents = new EventEmitter();
  contents.isDestroyed = () => false;
  contents.reloadIgnoringCache = () => {
    calls.push("reload");
    queueMicrotask(() => {
      contents.emit("did-start-loading");
      contents.emit("did-stop-loading");
    });
  };
  contents.stop = () => calls.push("stop");
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    view: { webContents: contents },
    setState: patch => calls.push(["state", patch]),
  });

  await fixture.hardRefreshHome(100);

  assert.deepEqual(calls.filter(call => call === "reload" || call === "stop"), ["reload"]);
  assert.equal(contents.listenerCount("did-start-loading"), 0);
  assert.equal(contents.listenerCount("did-stop-loading"), 0);
  assert.equal(contents.listenerCount("did-finish-load"), 0);
});

test("hard refresh timeout cannot become success when stopping emits did-stop-loading", async () => {
  const contents = new EventEmitter();
  contents.isDestroyed = () => false;
  contents.reloadIgnoringCache = () => queueMicrotask(() => contents.emit("did-start-loading"));
  contents.stop = () => contents.emit("did-stop-loading");
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    view: { webContents: contents },
    setState() {},
  });

  const keepTestAlive = setTimeout(() => {}, 100);
  try {
    await assert.rejects(
      fixture.hardRefreshHome(5),
      /ChatGPT hard refresh did not finish within 60 seconds/,
    );
  } finally {
    clearTimeout(keepTestAlive);
  }
});

test("launcher session refresh resolves persisted authentication before setup actions", async () => {
  const calls = [];
  const fixture = {
    state: { authenticated: false },
    snapshot: () => ({ authenticated: true }),
    setState: (patch) => calls.push(["state", patch]),
    probeAuthentication: async () => {
      calls.push(["probe"]);
      return { authenticated: true };
    },
    withManualOperation: async (name, action) => {
      calls.push(["operation", name]);
      return await action();
    },
    view: {
      webContents: {
        getURL: () => IDLE_BROWSER_URL,
        loadURL: async (url) => calls.push(["load", url]),
      },
    },
  };

  const state = await BrowserHost.prototype.refreshAuthentication.call(fixture);

  assert.deepEqual(state, { authenticated: true });
  assert.deepEqual(calls, [
    ["operation", "session refresh"],
    ["state", { status: "loading", message: "Checking saved ChatGPT session" }],
    ["load", "https://chatgpt.com/?temporary-chat=true"],
    ["probe"],
    ["state", { status: "ready", message: "ChatGPT is ready" }],
  ]);
});

test("manual browser operations disable background throttling until completion", async () => {
  const throttling = [];
  const surfaces = [];
  const fixture = {
    ready: async () => surfaces.push("ready"),
    activeTraceId: null,
    manualOperation: null,
    activateHomeSurface: () => surfaces.push("home"),
    setState() {},
    view: {
      webContents: {
        isDestroyed: () => false,
        setBackgroundThrottling: (enabled) => throttling.push(enabled),
      },
    },
  };

  const result = await BrowserHost.prototype.withManualOperation.call(fixture, "hidden check", async () => "ok");

  assert.equal(result, "ok");
  assert.deepEqual(surfaces, ["ready", "home"]);
  assert.deepEqual(throttling, [false, true]);
  assert.equal(fixture.manualOperation, null);
});

test("manual operations show the home surface without discarding retained task tabs", () => {
  const events = [];
  const taskTab = { id: "tab-ready", status: "ready" };
  const fixture = {
    selectedTabId: taskTab.id,
    turnTabs: new Map([[taskTab.id, taskTab]]),
    visible: true,
    surfaceActive: true,
    activeView: () => ({ webContents: { focus: () => events.push("focus") } }),
    syncViewVisibility: () => events.push("visibility"),
    snapshot: () => ({ activeTabId: "home" }),
    publishState: () => events.push("publish"),
    writeDescriptor: () => events.push("descriptor"),
  };

  BrowserHost.prototype.activateHomeSurface.call(fixture);

  assert.equal(fixture.selectedTabId, "home");
  assert.equal(fixture.turnTabs.size, 1);
  assert.deepEqual(events, ["visibility", "focus", "publish", "descriptor"]);
});

test("selected home surface remains represented while task tabs are retained", () => {
  const { webContents } = createContents();
  const taskTab = { id: "tab-ready", traceId: "trace_ready" };
  const fixture = {
    selectedTabId: "home",
    turnTabs: new Map([[taskTab.id, taskTab]]),
    state: {
      title: "ChatGPT",
      status: "signed-out",
      loading: false,
      visible: true,
      surfaceActive: true,
    },
    visible: true,
    surfaceActive: true,
    activeView: () => ({ webContents }),
    selectedTurnTab: () => null,
    tabSnapshot: (tab) => ({ id: tab.id, traceId: tab.traceId, active: false }),
  };

  const snapshot = BrowserHost.prototype.snapshot.call(fixture);

  assert.equal(snapshot.activeTabId, "home");
  assert.deepEqual(snapshot.tabs.map((tab) => tab.id), ["home", "tab-ready"]);
  assert.equal(snapshot.tabs[0].active, true);
});

test("selecting a task tab shows and focuses its owned Playwright surface", () => {
  const visibility = [];
  const focused = [];
  const makeView = (id) => ({
    setBounds() {},
    setVisible: (visible) => visibility.push([id, visible]),
    webContents: {
      disableDeviceEmulation() {},
      enableDeviceEmulation() {},
      focus: () => focused.push(id),
    },
  });
  const first = { id: "tab-first", status: "running", view: makeView("first") };
  const second = { id: "tab-second", status: "running", view: makeView("second") };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    view: makeView("home"),
    turnTabs: new Map([[first.id, first], [second.id, second]]),
    selectedTabId: first.id,
    visible: true,
    surfaceActive: true,
    boundsReady: true,
    bounds: { x: 260, y: 78, width: 800, height: 600 },
    authView: null,
    window: {
      getContentSize: () => [1120, 720],
      isMinimized: () => false,
      isVisible: () => true,
    },
    snapshot: () => ({ activeTabId: fixture.selectedTabId }),
    publishState() {},
    writeDescriptor() {},
  });

  const state = BrowserHost.prototype.selectTab.call(fixture, second.id);

  assert.equal(fixture.selectedTabId, second.id);
  assert.deepEqual(visibility, [
    ["home", true],
    ["first", true],
    ["second", true],
  ]);
  assert.deepEqual(focused, ["second"]);
  assert.equal(state.activeTabId, second.id);
});

test("a stale helper cannot end a replacement turn with the same trace id", async () => {
  const turnTabs = new Map([["tab-1", {
    id: "tab-1",
    traceId: "trace_same_retry",
    helperPid: 222,
  }]]);
  await assert.rejects(
    BrowserHost.prototype.endTurn.call(
      { turnTabs, closedTurnOwners: new Map() },
      "trace_same_retry",
      111,
      "failed",
      false,
      "stale helper exited",
    ),
    /Browser helper ownership mismatch: expected 222, received 111/,
  );
});

test("closing a running browser tab reports terminal user cancellation to its helper", async () => {
  const closed = [];
  const tab = {
    id: "tab-running",
    traceId: "trace_running",
    helperPid: 333,
    status: "running",
    view: {
      webContents: { isDestroyed: () => false, close: () => closed.push("contents") },
    },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map([[tab.id, tab]]),
    closedTurnOwners: new Map(),
    userCancelledTurnOwners: new Map(),
    selectedTabId: tab.id,
    window: { contentView: { removeChildView: () => closed.push("view") } },
    syncViewVisibility() {},
    snapshot: () => ({ tabs: [] }),
    publishState() {},
    writeDescriptor() {},
    cancelTurn: async (traceId) => closed.push(`cancel:${traceId}`),
    logger: { info() {} },
  });

  await BrowserHost.prototype.closeTab.call(fixture, tab.id);

  assert.deepEqual(closed, ["cancel:trace_running", "view", "contents"]);
  assert.deepEqual(fixture.closedTurnOwners.get("trace_running"), { helperPid: 333, remainingAcks: 2 });
  assert.throws(() => fixture.heartbeatTurn(tab.traceId, tab.helperPid), /already released/);
  assert.throws(() => fixture.heartbeatTurn(tab.traceId, 444), /ownership mismatch/);
  assert.equal(fixture.userCancelledTurnOwners.get("trace_running"), 333);
  assert.equal(fixture.selectedTabId, "home");
  await assert.rejects(
    () => BrowserHost.prototype.beginTurn.call(fixture, tab.traceId, false, 444),
    error => error?.code === "turn_cancelled",
  );

  assert.deepEqual(
    await BrowserHost.prototype.endTurn.call(
      fixture,
      tab.traceId,
      tab.helperPid,
      "failed",
      false,
      "page closed",
    ),
    { cancelledByUser: true },
  );
  assert.deepEqual(fixture.closedTurnOwners.get("trace_running"), { helperPid: 333, remainingAcks: 1 });
  await assert.rejects(fixture.endTurn(tab.traceId, 444, "failed", false), /ownership mismatch/);
  assert.deepEqual(await fixture.endTurn(tab.traceId, tab.helperPid, "failed", false), { cancelledByUser: true });
  assert.equal(fixture.closedTurnOwners.has("trace_running"), false);
  assert.equal(fixture.userCancelledTurnOwners.get("trace_running"), 333);
});

test("a failed runtime cancellation keeps the running DOM attached", async () => {
  const closed = [];
  const tab = {
    id: "tab-cancel-failed",
    traceId: "trace_cancel_failed",
    helperPid: 334,
    status: "running",
    view: {
      webContents: { isDestroyed: () => false, close: () => closed.push("contents") },
    },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map([[tab.id, tab]]),
    closedTurnOwners: new Map(),
    userCancelledTurnOwners: new Map(),
    selectedTabId: tab.id,
    window: { contentView: { removeChildView: () => closed.push("view") } },
    syncViewVisibility() {},
    snapshot: () => ({ tabs: [] }),
    publishState() {},
    writeDescriptor() {},
    cancelTurn: async () => { throw new Error("runtime cancellation unavailable"); },
    logger: { info() {} },
  });

  await assert.rejects(
    BrowserHost.prototype.closeTab.call(fixture, tab.id),
    /runtime cancellation unavailable/,
  );

  assert.equal(fixture.turnTabs.get(tab.id), tab);
  assert.equal(tab.status, "running");
  assert.deepEqual(closed, []);
});

test("a later provider round reuses the connector-bound conversation with a new trace id", async () => {
  const throttling = [];
  const tab = {
    id: "tab-reused",
    surfaceId: "surface-reused",
    traceId: "trace_reused",
    conversationKey: "conversation-a",
    connectorIdentity: "Codex Native2",
    connectorBound: true,
    interactionMode: "automatic",
    helperPid: 111,
    status: "ready",
    loading: false,
    message: "Task completed",
    view: {
      webContents: {
        isDestroyed: () => false,
        setBackgroundThrottling: (enabled) => throttling.push(enabled),
      },
    },
  };
  const events = [];
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    manualOperation: null,
    turnTabs: new Map([[tab.id, tab]]),
    userCancelledTurnOwners: new Map(),
    selectedTabId: "home",
    syncViewVisibility: () => events.push("visible"),
    snapshot: () => ({ tabs: [] }),
    publishState: () => events.push("published"),
    writeDescriptor: () => events.push("descriptor"),
    logger: { info: (event) => events.push(event) },
  });

  const lease = await BrowserHost.prototype.beginTurn.call(
    fixture,
    "trace_next",
    false,
    222,
    true,
    "conversation-a",
    "Codex Native2",
  );

  assert.deepEqual(lease, {
    surfaceId: "surface-reused",
    tabId: "tab-reused",
    reused: true,
    connectorBound: true,
  });
  assert.equal(tab.traceId, "trace_next");
  assert.equal(tab.helperPid, 222);
  assert.equal(tab.status, "running");
  assert.equal(tab.loading, true);
  assert.equal(tab.message, "ChatGPT is working");
  assert.equal(fixture.selectedTabId, tab.id);
  assert.deepEqual(throttling, [false]);
  assert.deepEqual(events, ["visible", "published", "descriptor", "browser.tab_reused"]);
});

test("six browser tabs are a hard account-safety limit", () => {
  const turnTabs = new Map(Array.from({ length: 6 }, (_unused, index) => [
    `tab-${index + 1}`,
    { ordinal: index + 1 },
  ]));

  assert.throws(
    () => BrowserHost.prototype.createTurnTab.call({ turnTabs }, "trace_seven", 444),
    /already has 6 browser tabs.*avoid excessive parallel traffic/,
  );
});

test("a retained conversation is not reused for a different connector identity", async () => {
  const retained = {
    id: "retained",
    traceId: "trace_old",
    status: "ready",
    conversationKey: "conversation-a",
    connectorIdentity: "Codex Native2",
    connectorBound: true,
    interactionMode: "automatic",
  };
  const created = { id: "fresh", surfaceId: "surface-fresh" };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    manualOperation: null,
    turnTabs: new Map([[retained.id, retained]]),
    userCancelledTurnOwners: new Map(),
    createTurnTab: (...args) => {
      assert.deepEqual(args, ["trace_next", 222, true, "conversation-a", "Other Connector", false, undefined]);
      return created;
    },
    writeDescriptor() {},
    syncViewVisibility() {},
    publishState() {},
    snapshot: () => ({ tabs: [] }),
    logger: { info() {} },
  });

  const lease = await BrowserHost.prototype.beginTurn.call(
    fixture,
    "trace_next",
    false,
    222,
    true,
    "conversation-a",
    "Other Connector",
  );
  assert.deepEqual(lease, { surfaceId: "surface-fresh", tabId: "fresh", reused: false });
  assert.equal(retained.status, "ready");
});

test("a required retained conversation fails before creating a browser tab", async () => {
  const retained = {
    id: "retained",
    traceId: "trace_old",
    status: "ready",
    conversationKey: "conversation-a",
    connectorIdentity: "Codex Native2",
    connectorBound: true,
    interactionMode: "automatic",
  };
  let created = false;
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    manualOperation: null,
    turnTabs: new Map([[retained.id, retained]]),
    userCancelledTurnOwners: new Map(),
    createTurnTab: () => {
      created = true;
      throw new Error("must not create a replacement tab");
    },
  });

  await assert.rejects(
    () => BrowserHost.prototype.beginTurn.call(
      fixture,
      "trace_next",
      false,
      222,
      true,
      "missing-conversation",
      "Codex Native2",
      true,
    ),
    /retained ChatGPT conversation is no longer available/,
  );
  assert.equal(created, false);
  assert.equal(retained.status, "ready");
});

test("ending one browser turn does not stop another running tab", async () => {
  let closedViews = 0;
  let removedViews = 0;
  const ended = {
    id: "tab-ended",
    traceId: "trace_ended",
    helperPid: 555,
    status: "running",
    loading: true,
    view: { webContents: { isDestroyed: () => false, setBackgroundThrottling() {}, close: () => { closedViews += 1; } } },
  };
  const active = {
    id: "tab-active",
    traceId: "trace_active",
    helperPid: 666,
    status: "running",
    loading: true,
    view: { webContents: { isDestroyed: () => false, setBackgroundThrottling() {} } },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map([[ended.id, ended], [active.id, active]]),
    closedTurnOwners: new Map(),
    userCancelledTurnOwners: new Map(),
    selectedTabId: ended.id,
    window: { contentView: { removeChildView: (view) => {
      assert.equal(view, ended.view);
      removedViews += 1;
    } } },
    syncViewVisibility() {},
    writeDescriptor() {},
    publishState() {},
    snapshot: () => ({ tabs: [] }),
    hide: () => assert.fail("a second running tab must keep the browser host active"),
    logger: { info() {} },
  });

  await BrowserHost.prototype.endTurn.call(
    fixture,
    ended.traceId,
    ended.helperPid,
    "completed",
    true,
  );

  assert.equal(ended.status, "ready");
  assert.equal(fixture.turnTabs.has(ended.id), false);
  assert.equal(fixture.turnTabs.has(active.id), true);
  assert.equal(fixture.selectedTabId, active.id);
  assert.equal(closedViews, 1);
  assert.equal(removedViews, 1);
  assert.equal(active.status, "running");
  assert.equal(fixture.activeTraceId, active.traceId);
});

test("completed Claude conversations retain and reuse their browser tab", async () => {
  const throttling = [];
  const tab = {
    id: "tab-claude",
    interactionMode: "automatic",
    conversationKey: "claude-retained-thread",
    surfaceId: "surface-claude",
    traceId: "trace_claude",
    helperPid: 555,
    status: "running",
    loading: true,
    bootstrapReady: true,
    view: { webContents: { isDestroyed: () => false, setBackgroundThrottling: value => throttling.push(value) } },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    manualOperation: null,
    turnTabs: new Map([[tab.id, tab]]),
    closedTurnOwners: new Map(),
    userCancelledTurnOwners: new Map(),
    selectedTabId: tab.id,
    syncViewVisibility() {},
    writeDescriptor() {},
    publishState() {},
    snapshot: () => ({ tabs: [] }),
    hide() {},
    logger: { info() {} },
  });

  await BrowserHost.prototype.endTurn.call(fixture, tab.traceId, tab.helperPid, "completed", true, undefined, true);
  assert.equal(fixture.turnTabs.get(tab.id), tab);
  assert.equal(tab.status, "ready");

  const lease = await BrowserHost.prototype.beginTurn.call(fixture, tab.traceId, false, 777, true, tab.conversationKey);
  assert.deepEqual(lease, { surfaceId: tab.surfaceId, tabId: tab.id, reused: true });
  assert.equal(tab.status, "running");
  assert.equal(tab.helperPid, 777);
  assert.equal(tab.bootstrapReady, true);
  assert.deepEqual(throttling, [true, false]);
});

test("retained Claude conversation tabs expire after thirty minutes", () => {
  let removed = false;
  const tab = {
    id: "tab-expired",
    traceId: "trace_expired",
    helperPid: 555,
    status: "ready",
    lastHeartbeatAt: 100,
  };
  const fixture = {
    turnTabs: new Map([[tab.id, tab]]),
    logger: { info() {} },
    removeTurnTab(candidate, abortRunning) {
      assert.equal(candidate, tab);
      assert.equal(abortRunning, false);
      removed = true;
      this.turnTabs.delete(candidate.id);
    },
  };

  BrowserHost.prototype.reapExpiredTurnTabs.call(fixture, 100 + (30 * 60 * 1000));

  assert.equal(removed, true);
  assert.equal(fixture.turnTabs.size, 0);
});

test("a new turn evicts the oldest retained conversation before a running tab", () => {
  const oldest = { id: "oldest", status: "ready", lastHeartbeatAt: 10 };
  const newer = { id: "newer", status: "ready", lastHeartbeatAt: 20 };
  const running = { id: "running", status: "running", lastHeartbeatAt: 1 };
  const removed = [];
  const fixture = {
    turnTabs: new Map([[oldest.id, oldest], [newer.id, newer], [running.id, running]]),
    removeTurnTab(tab, abortRunning) { removed.push([tab.id, abortRunning]); },
  };

  const evicted = BrowserHost.prototype.evictOldestRetainedTurnTab.call(fixture);

  assert.equal(evicted, true);
  assert.deepEqual(removed, [["oldest", false]]);
});

test("disabling enhanced sessions releases retained tabs without stopping running turns", () => {
  const retained = { id: "retained", status: "ready" };
  const running = { id: "running", status: "running" };
  const removed = [];
  const fixture = {
    turnTabs: new Map([[retained.id, retained], [running.id, running]]),
    removeTurnTab: (tab, abortRunning) => removed.push([tab.id, abortRunning]),
  };

  assert.equal(BrowserHost.prototype.releaseRetainedTurnTabs.call(fixture), 1);
  assert.deepEqual(removed, [["retained", false]]);
});

test("aborted, uninitialized and signed-out browser turns release their tab slots", async () => {
  for (const [status, bootstrapReady, authenticationRequired] of [
    ["aborted", true, false], ["failed", false, false], ["failed", true, true],
  ]) {
    let closed = false;
    const tab = {
      id: `tab-${status}`,
      traceId: `trace_${status}`,
      helperPid: 777,
      interactionMode: "automatic",
      bootstrapReady,
      authenticationRequired,
      status: "running",
      loading: true,
      view: { webContents: {
        isDestroyed: () => false,
        setBackgroundThrottling() {},
        close: () => { closed = true; },
      } },
    };
    const fixture = Object.assign(Object.create(BrowserHost.prototype), {
      turnTabs: new Map([[tab.id, tab]]),
      closedTurnOwners: new Map(),
      userCancelledTurnOwners: new Map(),
      selectedTabId: tab.id,
      window: { contentView: { removeChildView() {} } },
      syncViewVisibility() {},
      writeDescriptor() {},
      publishState() {},
      snapshot: () => ({ tabs: [] }),
      hide() {},
      logger: { info() {} },
    });

    await BrowserHost.prototype.endTurn.call(
      fixture,
      tab.traceId,
      tab.helperPid,
      status,
      true,
      `turn ${status}`,
    );

    assert.equal(fixture.turnTabs.size, 0);
    assert.equal(fixture.selectedTabId, "home");
    assert.equal(tab.status, status === "aborted" ? "aborted" : "error");
    assert.equal(closed, true);
  }
});

function primaryLoginFixture() {
  let loads = 0;
  let probes = 0;
  const contents = Object.assign(new EventEmitter(), {
    setWindowOpenHandler() {}, isDestroyed: () => false, isLoadingMainFrame: () => true, stop() {},
    getURL: () => "https://chatgpt.com/?temporary-chat=true",
    loadURL: async url => { loads++; contents.emit("did-start-navigation", {}, url, false, true); },
  });
  const host = Object.assign(Object.create(BrowserHost.prototype), {
    state: { authenticated: false }, turnTabs: new Map(), view: { webContents: contents },
    setState(patch) { Object.assign(this.state, patch); }, snapshot() { return { ...this.state }; },
    logger: { info() {}, error() {} }, show() {}, activateHomeSurface() {},
    armHomeNavigationTimeout() {}, clearHomeNavigationTimeout() {},
    withManualOperation: async (_name, action) => action(),
    probeAuthentication: async () => { probes++; return { authenticated: true }; },
    runSessionInspection: async () => {},
  });
  host.bindWebContents();
  return { host, contents, loads: () => loads, probes: () => probes };
}

test("failed primary navigation rejects login and an explicit retry replaces the failed document", async () => {
  const { host, contents, loads, probes } = primaryLoginFixture();
  contents.emit("did-fail-load", {}, -331, "ERR_NETWORK_IO_SUSPENDED", contents.getURL(), true);
  await assert.rejects(host.waitForAuthenticated(), /ERR_NETWORK_IO_SUSPENDED/);
  assert.equal(probes(), 0, "cached authentication cannot validate a failed page");
  contents.emit("did-finish-load"); // Chromium's error document is not a recovered ChatGPT page.
  assert.equal(host.state.status, "error");
  host.state.authenticated = true; // The account cookie can outlive the failed document.
  await host.openLogin();
  assert.equal(loads(), 1);
  assert.equal(host.primaryNavigationError, null);
  await host.openLogin();
  assert.equal(loads(), 1, "an authenticated, valid document is preserved");
});

test("only failed main-frame loads and renderer exits invalidate the primary login document", async () => {
  const { host, contents, loads } = primaryLoginFixture();
  contents.emit("did-fail-load", {}, -331, "ERR_NETWORK_IO_SUSPENDED", contents.getURL(), false);
  contents.emit("did-fail-load", {}, -3, "ERR_ABORTED", contents.getURL(), true);
  await host.openLogin();
  assert.equal(loads(), 0);
  contents.emit("render-process-gone", {}, { reason: "crashed", exitCode: 1 });
  await assert.rejects(host.waitForAuthenticated(), /renderer stopped: crashed/);
  contents.emit("did-start-navigation", {}, contents.getURL(), true, true);
  await assert.rejects(host.waitForAuthenticated(), /renderer stopped: crashed/);
  await host.openLogin();
  assert.equal(loads(), 1);
});

test("the primary navigation deadline is reported to the login waiter", async t => {
  t.mock.timers.enable({ apis: ["setTimeout", "Date"], now: 1_000_000 });
  const { host, contents } = primaryLoginFixture();
  BrowserHost.prototype.armHomeNavigationTimeout.call(host, contents, contents.getURL());
  t.mock.timers.tick(60_000);
  await assert.rejects(host.waitForAuthenticated(), /did not finish loading within 60 seconds/);
});

function failedAutomaticTurnFixture() {
  const closed = [];
  const tab = {
    id: "failed-tab", traceId: "failed-trace", helperPid: 777,
    status: "running", interactionMode: "automatic", bootstrapReady: true,
    conversationKey: "f".repeat(64), connectorIdentity: "Codex Native2", connectorBound: true,
    approvalPending: true, turnProgress: { stage: "chatgpt", activeToolCalls: 0 },
    view: { webContents: {
      isDestroyed: () => false, setBackgroundThrottling() {}, close: () => closed.push(tab.id),
    } },
  };
  const fixture = Object.assign(Object.create(BrowserHost.prototype), {
    turnTabs: new Map([[tab.id, tab]]), userCancelledTurnOwners: new Map(), closedTurnOwners: new Map(),
    selectedTabId: tab.id, manualOperation: null,
    window: { contentView: { removeChildView() {} } },
    syncViewVisibility() {}, writeDescriptor() {}, publishState() {}, snapshot: () => ({ tabs: [] }),
    hide() { throw new Error("do not hide the failed page the user is inspecting"); },
    logger: { info() {} },
    createTurnTab: async (traceId, helperPid, _interactionLocked, conversationKey, connectorIdentity) => {
      const fresh = { id: "fresh-tab", surfaceId: "fresh-surface", traceId, helperPid,
        conversationKey, connectorIdentity, status: "running", interactionMode: "automatic" };
      fixture.turnTabs.set(fresh.id, fresh);
      return fresh;
    },
  });
  return { fixture, tab, closed };
}
test("startup sign-in redirects become signed-out state while real navigation errors remain errors", async () => {
  for (const redirected of [true, false]) {
    let url = IDLE_BROWSER_URL;
    const failure = Object.assign(new Error("navigation stopped"), { code: -3 });
    const fixture = Object.assign(Object.create(BrowserHost.prototype), {
      state: { authenticated: true }, sessionRefreshOperation: null,
      snapshot() { return { ...this.state }; },
      setState(patch) { Object.assign(this.state, patch); },
      withManualOperation: async (_name, action) => await action(),
      view: { webContents: {
        isDestroyed: () => false,
        getURL: () => url,
        loadURL: async () => {
          if (redirected) url = "https://chatgpt.com/auth/login?next=%2F";
          throw failure;
        },
        executeJavaScript: async () => { throw new Error("must not probe a login page"); },
      } },
    });
    if (redirected) {
      const state = await fixture.refreshAuthentication();
      assert.equal(state.status, "signed-out");
      assert.equal(state.authenticated, false);
      assert.equal(state.message, "Sign in to ChatGPT");
    } else {
      await assert.rejects(fixture.refreshAuthentication(), error => error === failure);
      assert.equal(fixture.state.status, "error");
      assert.equal(fixture.state.loading, false);
    }
    assert.equal(fixture.sessionRefreshOperation, null);
  }
});

test("failed ChatGPT pages remain inspectable but lose turn ownership and cannot become successful", async () => {
  const { fixture, tab, closed } = failedAutomaticTurnFixture();
  assert.deepEqual(await fixture.endTurn(tab.traceId, tab.helperPid, "failed", true, "Check the ChatGPT tab"),
    { cancelledByUser: false });
  assert.equal(fixture.turnTabs.get(tab.id), tab);
  assert.equal(fixture.selectedTabId, tab.id);
  assert.equal(tab.status, "error");
  assert.equal(tab.message, "Check the ChatGPT tab");
  assert.equal(tab.approvalPending, false);
  assert.equal(tab.turnProgress, undefined);
  assert.equal(tab.connectorBound, false);
  assert.equal(fixture.activeTraceId, null);
  assert.throws(() => fixture.heartbeatTurn(tab.traceId, tab.helperPid), /no longer running/);
  assert.throws(() => fixture.setTurnApprovalPending(tab.traceId, tab.helperPid, true), /no longer running/);
  await assert.rejects(() => fixture.endTurn(tab.traceId, 778, "failed", true), /helper ownership mismatch/);
  await assert.rejects(() => fixture.endTurn(tab.traceId, tab.helperPid, "completed", true, undefined, true, true),
    /already failed/);
  const failedAt = tab.failedAt;
  await fixture.endTurn(tab.traceId, tab.helperPid, "failed", true);
  assert.equal(tab.failedAt, failedAt, "repeated end notifications cannot extend retention");
  assert.deepEqual(closed, []);

  fixture.lastTurnSweepAt = failedAt + 30 * 60_000 - 2;
  await fixture.reapExpiredTurnTabs(failedAt + 30 * 60_000 - 1);
  assert.equal(fixture.turnTabs.get(tab.id), tab, "helper liveness is irrelevant to a terminal page");
  await fixture.reapExpiredTurnTabs(failedAt + 30 * 60_000);
  assert.deepEqual(closed, [tab.id]);
  assert.equal(fixture.turnTabs.size, 0);
});

test("failed pages cannot supply retained history and a same-trace retry gets a fresh document", async () => {
  const { fixture, tab, closed } = failedAutomaticTurnFixture();
  await fixture.endTurn(tab.traceId, tab.helperPid, "failed", false);
  for (const traceId of [tab.traceId, "next-trace"]) {
    await assert.rejects(() => fixture.beginTurn(traceId, false, 778, false, tab.conversationKey, tab.connectorIdentity, true),
      error => error.code === "retained_conversation_unavailable");
  }
  assert.deepEqual(closed, []);
  const next = await fixture.beginTurn("next-trace", false, 778, false, tab.conversationKey, tab.connectorIdentity);
  assert.equal(next.reused, false);
  assert.equal(fixture.turnTabs.get(tab.id), tab, "another turn does not immediately erase failure evidence");
  fixture.turnTabs.delete(next.tabId);
  const retry = await fixture.beginTurn(tab.traceId, false, 778, false, tab.conversationKey, tab.connectorIdentity);
  assert.equal(retry.reused, false);
  assert.notEqual(retry.tabId, tab.id);
  assert.deepEqual(closed, [tab.id]);
  assert.equal([...fixture.turnTabs.values()].filter(item => item.traceId === tab.traceId).length, 1);
});

test("failed pages free capacity before reusable conversations without evicting active error states", async () => {
  const { fixture, tab, closed } = failedAutomaticTurnFixture();
  await fixture.endTurn(tab.traceId, tab.helperPid, "failed", false);
  const reusable = { id: "reusable", status: "ready", lastHeartbeatAt: 1 };
  const activeError = { id: "active-error", status: "error", interactionMode: "automatic", lastHeartbeatAt: 1 };
  fixture.turnTabs.set(reusable.id, reusable);
  fixture.turnTabs.set(activeError.id, activeError);
  assert.equal(fixture.evictOldestReclaimableTurnTab(), true);
  assert.deepEqual(closed, [tab.id]);
  assert.equal(fixture.turnTabs.get(reusable.id), reusable);
  assert.equal(fixture.turnTabs.get(activeError.id), activeError);
});
