const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const {
  SESSION_REFRESH_REMINDER_INTERVAL_MS,
  createStateStore,
  nextSessionRefreshReminderAt,
  validateSidebarState,
} = require("../electron/state.cjs");

test("launcher state persists onboarding, language, and autostart atomically", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "codex-web-gpt-launcher-state-"));
  const file = path.join(root, "state.json");
  try {
    const store = createStateStore(file);
    assert.deepEqual(store.read(), {
      version: 1,
      language: null,
      onboardingComplete: false,
      githubOpened: false,
      xOpened: false,
      autoStart: true,
      autoApproveToolCalls: false,
      bridgeEnabled: true,
      useEnhancedWebSessionMode: true,
      useEnhancedOutputTunnel: true,
      maxBrowserTabs: 6,
      automaticWebSessionLimitCount: 15,
      automaticWebSessionLimitMinutes: 300,
      automaticWebSessionLimitEnabled: false,
      experimentalBiggerContext: false,
      experimentalSkillAttachments: false,
      experimentalPlusNativeContext: false,
      experimentalNoAutoCompact: false,
      experimentalPreparedWebSession: false,
      keepRunningOnClose: true,
      showBrowserDuringTurns: true,
      lockBrowserDuringTurns: true,
      browserInteractionMode: "automatic",
      experimentalFreshConversationPerTurn: false,
      useSavedChats: false,
      zeroRiskProEnabled: false,
      browserSmokePassed: false,
      browserSmokeVersion: null,
      codexSetupComplete: false,
      claudeSetupComplete: false,
      claudeSetupOutdated: false,
      sidebarOpen: true,
      sidebarWidth: 252,
      mcpGuideStep: 0,
      sessionRefreshReminderAt: null,
    });
    store.update({
      language: "zh-CN",
      onboardingComplete: true,
      keepRunningOnClose: false,
      lockBrowserDuringTurns: false,
      browserSmokePassed: true,
      browserSmokeVersion: "0.2.0",
    });
    assert.deepEqual(createStateStore(file).read(), {
      version: 1,
      language: "zh-CN",
      onboardingComplete: true,
      githubOpened: false,
      xOpened: false,
      autoStart: true,
      autoApproveToolCalls: false,
      bridgeEnabled: true,
      useEnhancedWebSessionMode: true,
      useEnhancedOutputTunnel: true,
      maxBrowserTabs: 6,
      automaticWebSessionLimitCount: 15,
      automaticWebSessionLimitMinutes: 300,
      automaticWebSessionLimitEnabled: false,
      experimentalBiggerContext: false,
      experimentalSkillAttachments: false,
      experimentalPlusNativeContext: false,
      experimentalNoAutoCompact: false,
      experimentalPreparedWebSession: false,
      keepRunningOnClose: false,
      showBrowserDuringTurns: true,
      lockBrowserDuringTurns: false,
      browserInteractionMode: "automatic",
      experimentalFreshConversationPerTurn: false,
      useSavedChats: false,
      zeroRiskProEnabled: false,
      browserSmokePassed: true,
      browserSmokeVersion: "0.2.0",
      codexSetupComplete: false,
      claudeSetupComplete: false,
      claudeSetupOutdated: false,
      sidebarOpen: true,
      sidebarWidth: 252,
      mcpGuideStep: 0,
      sessionRefreshReminderAt: null,
    });
    if (process.platform !== "win32") assert.equal(fs.statSync(file).mode & 0o077, 0);
    assert.equal(fs.readdirSync(root).some(name => name.includes(".tmp-")), false);
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
});

test("sidebar state accepts only bounded native shell dimensions", () => {
  assert.deepEqual(validateSidebarState({ open: false, width: 300.4 }), {
    sidebarOpen: false,
    sidebarWidth: 300,
  });
  assert.throws(() => validateSidebarState({ open: "yes", width: 300 }), /invalid/);
  assert.throws(() => validateSidebarState({ open: true, width: 100 }), /between 240 and 420/);
  assert.throws(() => validateSidebarState({ open: true, width: 900 }), /between 240 and 420/);
});

test("every supported launcher language survives a state update and reload", () => {
  const languages = require("../electron/languages.json");
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "codex-web-gpt-locale-state-"));
  const file = path.join(root, "state.json");
  try {
    for (const language of Object.keys(languages)) {
      const store = createStateStore(file);
      store.update({ language, onboardingComplete: true });
      assert.equal(createStateStore(file).read().language, language);
      assert.equal(createStateStore(file).read().onboardingComplete, true);
    }
    for (const language of ["__proto__", "constructor", "unknown", [], {}]) {
      fs.writeFileSync(file, JSON.stringify({ version: 1, language, onboardingComplete: true }));
      const state = createStateStore(file).read();
      assert.equal(state.language, null);
      assert.equal(state.onboardingComplete, true);
    }
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
});

test("persisted sidebar corruption is repaired without changing the rest of launcher state", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "codex-web-gpt-sidebar-state-"));
  const file = path.join(root, "state.json");
  try {
    fs.writeFileSync(file, JSON.stringify({
      version: 1,
      language: "zh-CN",
      onboardingComplete: "yes",
      autoStart: "yes",
      experimentalFreshConversationPerTurn: "true",
      bridgeEnabled: false,
      browserSmokePassed: "yes",
      browserSmokeVersion: { invalid: true },
      sidebarOpen: "yes",
      sidebarWidth: 900,
      mcpGuideStep: 99,
      sessionRefreshReminderAt: "not-a-date",
      coreSetupComplete: "yes",
    }));
    assert.deepEqual(createStateStore(file).read(), {
      version: 1,
      language: "zh-CN",
      onboardingComplete: false,
      githubOpened: false,
      xOpened: false,
      autoStart: true,
      autoApproveToolCalls: false,
      bridgeEnabled: false,
      useEnhancedWebSessionMode: false,
      useEnhancedOutputTunnel: true,
      maxBrowserTabs: 6,
      automaticWebSessionLimitCount: 15,
      automaticWebSessionLimitMinutes: 300,
      automaticWebSessionLimitEnabled: false,
      experimentalBiggerContext: false,
      experimentalSkillAttachments: false,
      experimentalNoAutoCompact: false,
      experimentalPreparedWebSession: false,
      keepRunningOnClose: true,
      experimentalPlusNativeContext: false,
      showBrowserDuringTurns: true,
      lockBrowserDuringTurns: true,
      browserInteractionMode: "automatic",
      experimentalFreshConversationPerTurn: false,
      useSavedChats: false,
      zeroRiskProEnabled: false,
      browserSmokePassed: false,
      browserSmokeVersion: null,
      codexSetupComplete: false,
      claudeSetupComplete: false,
      claudeSetupOutdated: false,
      sidebarOpen: true,
      sidebarWidth: 252,
      mcpGuideStep: 0,
      sessionRefreshReminderAt: null,
    });
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
});

test("existing launcher state without a mode stays original while the legacy opt-in migrates", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "codex-web-gpt-launcher-mode-state-"));
  const file = path.join(root, "state.json");
  try {
    fs.writeFileSync(file, JSON.stringify({ version: 1, onboardingComplete: true }));
    assert.equal(createStateStore(file).read().useEnhancedWebSessionMode, false);

    fs.writeFileSync(file, JSON.stringify({
      version: 1,
      onboardingComplete: true,
      useNewCompactMode: true,
    }));
    assert.equal(createStateStore(file).read().useEnhancedWebSessionMode, true);
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
});

test("legacy combined setup is migrated as both client integrations installed", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "codex-web-gpt-legacy-setup-state-"));
  const file = path.join(root, "state.json");
  try {
    fs.writeFileSync(file, JSON.stringify({ version: 1, coreSetupComplete: true }));
    const state = createStateStore(file).read();
    assert.equal(state.codexSetupComplete, true);
    assert.equal(state.claudeSetupComplete, true);
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
});

test("session refresh reminders are deferred by exactly 48 hours", () => {
  const now = Date.UTC(2026, 7, 5, 12, 0, 0);
  assert.equal(SESSION_REFRESH_REMINDER_INTERVAL_MS, 48 * 60 * 60 * 1000);
  assert.equal(nextSessionRefreshReminderAt(now), "2026-08-07T12:00:00.000Z");
  assert.throws(() => nextSessionRefreshReminderAt(Number.NaN), /must be finite/);
});


test("saved chats persist in manual and Enhanced modes while fresh-per-turn is Original-only", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "launcher-conversation-preferences-"));
  const file = path.join(root, "state.json");
  try {
    for (const mode of ["automatic", "manual"]) for (const enhanced of [false, true]) {
      const store = createStateStore(file);
      store.update({ onboardingComplete: true, coreSetupComplete: true,
        browserInteractionMode: mode, useEnhancedWebSessionMode: enhanced,
        experimentalFreshConversationPerTurn: true, useSavedChats: true });
      const state = createStateStore(file).read();
      assert.equal(state.browserInteractionMode, mode);
      assert.equal(state.useSavedChats, true);
      assert.equal(state.experimentalFreshConversationPerTurn, mode === "automatic" && !enhanced);
      fs.writeFileSync(file, JSON.stringify({ ...state, experimentalFreshConversationPerTurn: true }));
      assert.equal(createStateStore(file).read().experimentalFreshConversationPerTurn, mode === "automatic" && !enhanced);
    }
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
});
