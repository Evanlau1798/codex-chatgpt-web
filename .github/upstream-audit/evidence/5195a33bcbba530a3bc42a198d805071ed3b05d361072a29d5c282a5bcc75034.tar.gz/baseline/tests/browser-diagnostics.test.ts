import { expect, test } from "bun:test";
import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, utimesSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { Page } from "playwright-core";
import { chromium } from "playwright-core";
import { ChatGptBrowserDiagnostics, readChatGptUpstreamFailureUiState, sanitizeChatGptBrowserDiagnosticState } from "../src/adapters/chatgpt-web/browser-diagnostics";

test.skipIf(!process.env.CHATGPT_DOM_TEST_BROWSER)("composer diagnostics recognize native textarea editability without recording its content", async () => {
  const root = mkdtempSync(join(tmpdir(), "textarea-diagnostics-"));
  const browser = await chromium.launch({ executablePath: process.env.CHATGPT_DOM_TEST_BROWSER, headless: true });
  try {
    const page = await browser.newPage();
    const cases = [
      ['<textarea id="prompt-textarea">private-draft</textarea>', true],
      ['<textarea id="prompt-textarea" readonly>private-draft</textarea>', false],
      ['<textarea id="prompt-textarea" disabled>private-draft</textarea>', false],
      ['<fieldset disabled><textarea id="prompt-textarea">private-draft</textarea></fieldset>', false],
      ['<div id="prompt-textarea" contenteditable="true">private-draft</div>', true],
      ['<div id="prompt-textarea" contenteditable="false">private-draft</div>', false],
      ['<textarea id="prompt-textarea" style="display:none">private-draft</textarea>', false],
      ['<textarea id="prompt-textarea"></textarea><textarea data-testid="prompt-textarea"></textarea>', false],
    ] as const;
    for (const [index, [html, editable]] of cases.entries()) {
      await page.setContent(`<form>${html}</form>`);
      const trace = `textarea_case_${index}`;
      await new ChatGptBrowserDiagnostics(trace, root, true).capture(page, "connector-verification-started");
      const directory = readdirSync(root).find(name => name.startsWith(trace))!;
      const content = readFileSync(join(root, directory, "01-connector-verification-started.json"), "utf8");
      expect(JSON.parse(content).state.composerEditable).toBe(editable);
      expect(content).not.toContain("private-draft");
    }
  } finally { await browser.close(); rmSync(root, { recursive: true, force: true }); }
}, 30_000);

test("upstream failure UI summary records only visible control counts", async () => {
  const selectors: string[] = [];
  const page = {
    locator: (selector: string) => {
      selectors.push(selector);
      return { filter: () => ({ count: async () => selector.includes("regenerate-thread-error-button") ? 1 : 2 }) };
    },
  } as unknown as Page;
  expect(await readChatGptUpstreamFailureUiState(page)).toEqual({
    globalErrorActions: 1, assistantTurns: 2, stopButtons: 2, globalAlerts: 2,
  });
  expect(selectors.join(" ")).toContain("regenerate-thread-error-button");
  expect(selectors.join(" ")).not.toMatch(/textContent|innerText/);
});

test("upstream failure UI observation is bounded when the renderer never answers", async () => {
  const page = { locator: () => ({ filter: () => ({ count: () => new Promise(() => {}) }) }) } as unknown as Page;
  await expect(readChatGptUpstreamFailureUiState(page, 10)).rejects.toMatchObject({
    name: "ChatGptBrowserObservationTimeoutError",
  });
});

const diagnosticState = {
  url: "https://chatgpt.com/",
  title: "Temporary Chat",
  surfaceId: "surface-test",
  bodyTextChars: 100,
  composer: { visibleCount: 1, textChars: [0], composerSelectedConnectors: [], mentionMenuConnectors: [] },
  effortControls: [],
  effortItems: [],
  effortSliders: [{ min: 0, max: 4, value: 3 }],
  menus: [],
  connectorRows: [],
  overlays: [],
  turns: {
    user: 1,
    stopButtonCount: 1,
    assistant: [{
      textChars: 42, htmlChars: 80, markdownCount: 1, streamingStatusCount: 0,
      completionActionCount: 1, renderedCompletionActionCount: 1,
    }],
  },
  completion: {
    actionVisible: false,
    lastNodePresent: true,
    boundaryStart: "0",
    boundaryEnd: "42",
    finiteAnimations: 0,
    infiniteAnimations: 1,
  },
};

test("completed retries remain bounded without evicting failed captures from unrelated traces", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-retry-diagnostics-"));
  const page = { evaluate: async () => ({ composerVisible: false }) } as unknown as Page;
  const firstTrace = "original_stall";
  const capture = async (trace: string, checkpoint: string, status: "failed" | "completed", error?: Error) => {
    const diagnostics = new ChatGptBrowserDiagnostics(trace, root, true);
    await diagnostics.capture(page, checkpoint, error);
    diagnostics.finish(status);
  };
  try {
    await capture(firstTrace, "initial-failure", "failed", new Error("private"));
    const first = readdirSync(root)[0]!;
    utimesSync(join(root, first), 1, 1);
    for (let i = 0; i < 8; i++) {
      await capture(`unrelated_${i}`, "initial", "failed");
    }
    for (let i = 0; i < 12; i++) {
      await capture(firstTrace, `retry-${i}`, "completed");
    }
    const dirs = readdirSync(root);
    expect(dirs).toContain(first);
    expect(dirs.filter(name => name.startsWith(firstTrace))).toHaveLength(11);
    expect(dirs.filter(name => name.startsWith("unrelated_"))).toHaveLength(8);
    const latest = dirs.find(name => existsSync(join(root, name, "01-retry-11.json")))!;
    expect(readdirSync(join(root, latest)).sort()).toEqual([".trace-state", "01-retry-11.json"]);
    expect(JSON.parse(readFileSync(join(root, latest, ".trace-state"), "utf8")).status).toBe("completed");
    expect(readFileSync(join(root, first, "01-initial-failure.json"), "utf8")).not.toContain("private");
    for (let i = 8; i < 18; i++) {
      await capture(`unrelated_${i}`, "initial", "completed");
    }
    expect(readdirSync(root).length).toBeLessThanOrEqual(20);
    expect(readdirSync(root).filter(name => name.startsWith(firstTrace))).toEqual([first]);
    for (let i = 0; i < 18; i++) {
      expect(readdirSync(root).some(name => name.startsWith(`unrelated_${i}-`))).toBeTrue();
    }
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("connector verification records only capabilities even when screenshots are enabled", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-verification-private-"));
  const previous = process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS;
  let screenshots = 0;
  let verificationEvaluator = "";
  try {
    process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS = "1";
    const page = {
      evaluate: async (evaluator: Function) => {
        verificationEvaluator = evaluator.toString();
        return {
          composerVisible: true, connectorSelected: false, mentionMenuVisible: false,
          effortControlVisible: false, effortItemsVisible: false, menuVisible: false,
          connectorRowsVisible: false, overlayVisible: false,
        };
      },
      locator: () => ({}),
      screenshot: async () => { screenshots++; return Buffer.from("private-image"); },
    } as unknown as Page;
    const capture = new ChatGptBrowserDiagnostics("verify_private_trace", root, true);
    await capture.capture(page, "connector-verification-started");
    await capture.capture(page, "connector-verification-failed", new Error("private-error"));
    capture.finish("failed");
    const directory = join(root, readdirSync(root)[0]!);
    expect(JSON.parse(readFileSync(join(directory, ".trace-state"), "utf8")).status).toBe("failed");
    const files = readdirSync(directory).filter(name => name !== ".trace-state").sort();
    expect(files.length).toBe(2);
    expect(screenshots).toBe(0);
    expect(verificationEvaluator).not.toMatch(/location\.href|document\.title|innerText|textContent/);
    expect(verificationEvaluator).toContain("app-mention-path");
    expect(verificationEvaluator).toContain("data-mention-list-scroll-area");
    for (const file of files) {
      const content = readFileSync(join(directory, file), "utf8");
      expect(content).not.toContain("private-");
      const entry = JSON.parse(content);
      expect(entry.traceId).toBe("verify_private_trace");
      expect(entry.state.composerVisible).toBe(true);
      expect(Object.values(entry.state).every(value => typeof value === "boolean")).toBe(true);
    }
    expect(JSON.parse(readFileSync(join(directory, files[1]!), "utf8")).error).toBe("verification_failed");
  } finally {
    if (previous === undefined) delete process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS;
    else process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS = previous;
    rmSync(root, { recursive: true, force: true });
  }
});

function artifact(root: string, extension: string): string {
  const directory = join(root, readdirSync(root)[0]!);
  const name = readdirSync(directory).find(value => value.endsWith(extension));
  if (!name) throw new Error(`missing diagnostic ${extension}`);
  return join(directory, name);
}

test("preserves DOM diagnostic JSON when screenshot capture times out", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-browser-diagnostic-"));
  const originalInfo = console.info;
  const logs: string[] = [];
  console.info = value => { logs.push(String(value)); };
  try {
    let screenshotCalls = 0;
    const page = {
      evaluate: async () => diagnosticState,
      screenshot: async () => { screenshotCalls += 1; throw new Error("screenshot timeout"); },
    } as unknown as Page;
    await new ChatGptBrowserDiagnostics("trace_json_survives", root).capture(page, "turn-failed");

    const json = JSON.parse(readFileSync(artifact(root, ".json"), "utf8"));
    expect(json.state).toEqual(sanitizeChatGptBrowserDiagnosticState(diagnosticState));
    expect(JSON.stringify(json.state)).not.toMatch(/https:|Temporary Chat|surface-test/);
    expect(json.screenshotError).toBeUndefined();
    expect(screenshotCalls).toBe(0);
    const logged = JSON.parse(logs.find(line => line.startsWith("[chatgpt-web] page_state "))!.slice("[chatgpt-web] page_state ".length));
    expect(logged.traceId).toBe("trace_json_survives");
    expect(logged.state).toEqual(json.state);
    expect(JSON.stringify(logged)).not.toMatch(/https:|Temporary Chat|surface-test/);
    expect(() => artifact(root, ".png")).toThrow("missing diagnostic .png");
  } finally {
    console.info = originalInfo;
    rmSync(root, { recursive: true, force: true });
  }
});

test("opt-in screenshots mask sensitive UI regions and preserve the error envelope", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-browser-diagnostic-"));
  const previous = process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS;
  try {
    process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS = "1";
    const locatorSelectors: string[] = [];
    let screenshotOptions: Record<string, unknown> | undefined;
    const page = {
      evaluate: async () => { throw new Error("execution context unavailable"); },
      locator: (selector: string) => {
        locatorSelectors.push(selector);
        return { selector };
      },
      screenshot: async (options: Record<string, unknown>) => {
        screenshotOptions = options;
        return Buffer.from("png");
      },
    } as unknown as Page;
    await new ChatGptBrowserDiagnostics("trace_png_survives", root).capture(page, "turn-failed");

    const json = JSON.parse(readFileSync(artifact(root, ".json"), "utf8"));
    expect(json.state).toBeNull();
    expect(json.stateError).toContain("execution context unavailable");
    expect(locatorSelectors.join(" ")).toContain("conversation-turn-");
    expect(locatorSelectors.join(" ")).toContain("[data-turn-key]");
    expect(locatorSelectors.join(" ")).toMatch(/prompt-textarea|contenteditable/);
    expect(locatorSelectors.join(" ")).toContain("dialog");
    expect(locatorSelectors.join(" ")).toMatch(/account|profile/i);
    expect(Array.isArray(screenshotOptions?.mask)).toBe(true);
    expect((screenshotOptions?.mask as unknown[]).length).toBeGreaterThanOrEqual(4);
    expect(readFileSync(artifact(root, ".png")).toString()).toBe("png");
  } finally {
    if (previous === undefined) delete process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS;
    else process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS = previous;
    rmSync(root, { recursive: true, force: true });
  }
});

test("opt-in screenshot fails closed when the redaction mask cannot be built", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-browser-diagnostic-"));
  const previous = process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS;
  try {
    process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS = "1";
    let screenshotCalls = 0;
    const page = {
      evaluate: async () => diagnosticState,
      locator: () => { throw new Error("locator unavailable"); },
      screenshot: async () => { screenshotCalls += 1; return Buffer.from("unsafe"); },
    } as unknown as Page;
    await new ChatGptBrowserDiagnostics("trace_mask_failure", root).capture(page, "turn-failed");

    const json = JSON.parse(readFileSync(artifact(root, ".json"), "utf8"));
    expect(json.screenshotError).toContain("locator unavailable");
    expect(screenshotCalls).toBe(0);
    expect(() => artifact(root, ".png")).toThrow("missing diagnostic .png");
  } finally {
    if (previous === undefined) delete process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS;
    else process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS = previous;
    rmSync(root, { recursive: true, force: true });
  }
});

test("scopes diagnostic capture to the bound assistant turn", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-browser-diagnostic-"));
  try {
    let evaluateArgument: unknown;
    let evaluateSource = "";
    const page = {
      evaluate: async (callback: unknown, argument: unknown) => {
        evaluateSource = String(callback);
        evaluateArgument = argument;
        return diagnosticState;
      },
      screenshot: async () => Buffer.from("png"),
    } as unknown as Page;
    const diagnostics = new ChatGptBrowserDiagnostics("trace_bound_turn", root);
    diagnostics.bindAssistantTurn({ id: "conversation-turn-9", ordinal: 3, generation: 1 });
    await diagnostics.capture(page, "bound-turn");

    expect(evaluateArgument).toMatchObject({
      binding: { id: "conversation-turn-9", ordinal: 3, generation: 1 },
      selectors: {
        effortSliderContainer: expect.any(String),
        userTurn: expect.any(String),
        stopButton: expect.any(String),
        completionAction: expect.any(String),
      },
    });
    expect(evaluateSource).toContain("effortSliders");
    expect(evaluateSource).toContain("stopButtonCount");
    expect(evaluateSource).toContain("renderedCompletionActionCount");
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});
