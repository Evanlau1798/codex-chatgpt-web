import { BrowserDiagnosticHistory } from "./browser-diagnostic-history";
import { randomUUID } from "node:crypto";
import { join } from "node:path";
import type { Page } from "playwright-core";
import { chatGptResponseStructureLogEntries, chatGptResponseStructures } from "./browser-response-structure";
import { chatGptInteractionState } from "./browser-interaction-state";
import { atomicWriteFile, getConfigDir } from "../../config";
import {
  CHATGPT_ASSISTANT_TURN_SELECTOR,
  CHATGPT_COMPLETION_ACTION_SELECTOR,
  CHATGPT_COMPOSER_SELECTOR,
  CHATGPT_EFFORT_CONTROL_SELECTOR,
  CHATGPT_EFFORT_ITEM_SELECTOR,
  CHATGPT_EFFORT_SLIDER_CONTAINER_SELECTOR,
  CHATGPT_STOP_BUTTON_SELECTOR,
  CHATGPT_USER_TURN_SELECTOR,
} from "../../chatgpt-session";
import type { ChatGptAssistantTurnBinding } from "./response-turn-boundary";
import { CHATGPT_BROWSER_OBSERVATION_PROBE_TIMEOUT_MS, withChatGptBrowserObservationTimeout } from "./browser-observation";

const SAFE_STRING_KEYS = new Set(["tag", "role", "ariaExpanded", "ariaChecked", "dataState", "dataHighlighted", "origin"]);
export function sanitizeChatGptBrowserDiagnosticState(value: unknown): unknown {
  if (value === null || typeof value === "number" || typeof value === "boolean") return value;
  if (Array.isArray(value)) return value.map(sanitizeChatGptBrowserDiagnosticState);
  if (!value || typeof value !== "object") return undefined;
  return Object.fromEntries(Object.entries(value).flatMap(([key, candidate]) => {
    if (typeof candidate === "string") return SAFE_STRING_KEYS.has(key) && candidate.length <= 200 ? [[key, candidate]] : [];
    const sanitized = sanitizeChatGptBrowserDiagnosticState(candidate);
    return sanitized === undefined ? [] : [[key, sanitized]];
  }));
}

export async function readChatGptUpstreamFailureUiState(
  page: Page,
  timeoutMs = CHATGPT_BROWSER_OBSERVATION_PROBE_TIMEOUT_MS,
): Promise<{
  globalErrorActions: number | null;
  assistantTurns: number | null;
  stopButtons: number | null;
  globalAlerts: number | null;
}> {
  const visibleCount = (selector: string) => page.locator(selector).filter({ visible: true }).count().catch(() => null);
  const [globalErrorActions, assistantTurns, stopButtons, globalAlerts] = await withChatGptBrowserObservationTimeout(Promise.all([
    visibleCount('[data-testid="regenerate-thread-error-button"]'),
    visibleCount(CHATGPT_ASSISTANT_TURN_SELECTOR),
    visibleCount(CHATGPT_STOP_BUTTON_SELECTOR),
    visibleCount('[role="alert"], [role="dialog"]'),
  ]), timeoutMs);
  return { globalErrorActions, assistantTurns, stopButtons, globalAlerts };
}

export function redactChatGptUiDiagnostic(value: string): string {
  return value
    .replace(/<codex_context_json>[\s\S]*?<\/codex_context_json>/gi, "<codex_context_json>[redacted]</codex_context_json>")
    .replace(/\b(turn|binding|call)_[A-Za-z0-9_-]{12,}\b/g, "$1_[redacted]");
}

export function browserDiagnosticCheckpoint(value: string): string {
  const safe = value.replace(/[^A-Za-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
  return safe || "checkpoint";
}

export function browserDiagnosticIncludesScreenshot(
  _checkpoint: string,
  captureAll = process.env.CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS === "1",
): boolean {
  return captureAll;
}

function diagnosticScreenshotMask(page: Page) {
  return [
    page.locator('[data-testid^="conversation-turn-"], [data-turn-key]'),
    page.locator(CHATGPT_COMPOSER_SELECTOR),
    page.locator('[role="dialog"], [role="alert"], [role="status"], [data-radix-popper-content-wrapper]'),
    page.locator('[data-testid*="profile" i], [data-testid*="account" i], [aria-label*="profile" i], [aria-label*="account" i], [aria-label*="profil" i], [aria-label*="compte" i]'),
  ];
}

function diagnosticError(error: unknown): string {
  return redactChatGptUiDiagnostic(error instanceof Error ? error.message : String(error));
}

function verificationFailure(error: unknown): string {
  if (error instanceof Error && error.name === "AbortError") return "cancelled";
  if (error instanceof Error && error.name === "TimeoutError") return "timeout";
  const code = error && typeof error === "object" && "code" in error ? error.code : undefined;
  return typeof code === "string" && ["chatgpt_connector_unavailable", "chatgpt_rate_limited", "chatgpt_session_expired", "chatgpt_sign_in_required", "chatgpt_surface_changed"].includes(code)
    ? code : "verification_failed";
}

export class ChatGptBrowserDiagnostics {
  private readonly directory: string;
  private readonly history: BrowserDiagnosticHistory;
  private sequence = 0;
  private initialized = false;
  private assistantTurnBinding?: ChatGptAssistantTurnBinding;

  constructor(
    private readonly traceId: string,
    private readonly root = join(getConfigDir(), "diagnostics", "browser-turns"),
    private readonly contentFree = false,
  ) {
    if (!/^[A-Za-z0-9_-]{6,128}$/.test(traceId)) {
      throw new Error("ChatGPT browser diagnostic trace id is invalid");
    }
    this.directory = join(this.root, `${traceId}-${randomUUID().slice(0, 8)}`);
    this.history = new BrowserDiagnosticHistory(this.root, this.directory);
  }

  finish(status: "completed" | "failed"): void {
    try { this.history.finish(status); }
    catch { console.warn("[chatgpt-web] browser diagnostic retention failed"); }
  }

  bindAssistantTurn(binding: ChatGptAssistantTurnBinding): void {
    this.assistantTurnBinding = { ...binding };
  }

  async capture(page: Page, checkpoint: string, error?: unknown): Promise<void> {
    try {
      this.initialize();
      const sequence = String(++this.sequence).padStart(2, "0");
      const stem = `${sequence}-${browserDiagnosticCheckpoint(checkpoint)}`;
      const capturedAt = new Date().toISOString();
      let state: unknown = null;
      let stateError: string | undefined;
      try {
        state = await withChatGptBrowserObservationTimeout(this.contentFree
          ? captureVerificationCapabilities(page)
          : captureBrowserDiagnosticState(page, this.assistantTurnBinding));
      } catch (captureError) {
        stateError = this.contentFree ? verificationFailure(captureError) : diagnosticError(captureError);
      }

      const responseStructure = await withChatGptBrowserObservationTimeout(
        Promise.resolve().then(() => page.locator(CHATGPT_ASSISTANT_TURN_SELECTOR).evaluateAll(chatGptResponseStructures)),
      ).catch(() => undefined);
      const failed = /turn-failed|response-stalled/.test(checkpoint);
      // Verification remains content-free and normal captures avoid extra DOM work.
      // Detailed actionability probes run only for a failing owned turn.
      const interaction = failed && !this.contentFree
        ? await withChatGptBrowserObservationTimeout(page.evaluate(chatGptInteractionState, {
          selector: CHATGPT_EFFORT_CONTROL_SELECTOR,
          sampleFrames: true,
        })).catch(() => undefined)
        : undefined;
      const safeInteraction = interaction === undefined ? undefined : sanitizeChatGptBrowserDiagnosticState(interaction);
      const envelope: Record<string, unknown> = {
        version: 2,
        capturedAt,
        traceId: this.traceId,
        checkpoint,
        ...(responseStructure ? { responseStructure } : {}),
        ...(safeInteraction !== undefined ? { interaction: safeInteraction } : {}),
        ...(error !== undefined ? { error: this.contentFree ? verificationFailure(error) : diagnosticError(error) } : {}),
        state: sanitizeChatGptBrowserDiagnosticState(state),
        ...(stateError ? { stateError } : {}),
      };
      const jsonPath = join(this.directory, `${stem}.json`);
      this.writeEnvelope(jsonPath, envelope);

      if (failed) {
        console.info(`[chatgpt-web] page_state ${JSON.stringify({
          traceId: this.traceId, checkpoint: stem,
          ...(stateError ? { unavailable: true } : { state: sanitizeChatGptBrowserDiagnosticState(state) }),
        })}`);
        // Preserve bounded, content-free structural and actionability evidence
        // when a failing renderer is replaced. Never log account or prompt text.
        if (responseStructure) {
          for (const entry of chatGptResponseStructureLogEntries(this.traceId, stem, responseStructure)) console.info(entry);
        }
        console.info(`[chatgpt-web] interaction_state ${JSON.stringify({
          traceId: this.traceId,
          checkpoint: stem,
          ...(safeInteraction !== undefined ? { state: safeInteraction } : { unavailable: true }),
        })}`);
      }

      if (!this.contentFree && browserDiagnosticIncludesScreenshot(checkpoint)) {
        try {
          const mask = diagnosticScreenshotMask(page);
          const screenshot = await page.screenshot({ animations: "disabled", caret: "hide", mask, timeout: 5_000, type: "png" });
          atomicWriteFile(join(this.directory, `${stem}.png`), screenshot);
        } catch (screenshotCaptureError) {
          envelope.screenshotError = diagnosticError(screenshotCaptureError);
          this.writeEnvelope(jsonPath, envelope);
          console.warn(
            `[chatgpt-web] browser diagnostic screenshot failed trace=${this.traceId}`
            + ` checkpoint=${browserDiagnosticCheckpoint(checkpoint)}: ${envelope.screenshotError}`,
          );
        }
      }
      console.info(`[chatgpt-web] browser diagnostic trace=${this.traceId} checkpoint=${stem}${this.contentFree ? "" : ` path=${this.directory}`}`);
    } catch (captureError) {
      console.warn(
        `[chatgpt-web] browser diagnostic capture failed trace=${this.traceId}`
        + ` checkpoint=${browserDiagnosticCheckpoint(checkpoint)}: ${this.contentFree ? verificationFailure(captureError) : diagnosticError(captureError)}`,
      );
    }
  }

  private initialize(): void {
    if (this.initialized) return;
    this.history.start();
    this.initialized = true;
  }

  private writeEnvelope(path: string, envelope: Record<string, unknown>): void {
    atomicWriteFile(path, `${JSON.stringify(envelope, null, 2)}\n`);
  }
}

async function captureVerificationCapabilities(page: Page): Promise<Record<string, boolean>> {
  return page.evaluate(selectors => {
    const rendered = (element: Element): boolean => {
      const candidate = element as HTMLElement;
      const style = getComputedStyle(candidate);
      return candidate.isConnected && style.display !== "none"
        && style.visibility !== "hidden" && style.opacity !== "0";
    };
    const any = (selector: string, root: ParentNode = document): boolean =>
      [...root.querySelectorAll(selector)].some(rendered);
    const composers = [...document.querySelectorAll(selectors.composer)].filter(rendered);
    const composerForm = composers.length === 1 ? composers[0]!.closest("form") : null;
    const effortControls = composerForm ? [...composerForm.querySelectorAll(selectors.effortControl)].filter(rendered) : [];
    return {
      composerVisible: composers.length === 1,
      composerEditable: composers.length === 1 && (composers[0] instanceof HTMLTextAreaElement
        ? !composers[0].matches(":disabled") && !composers[0].readOnly
        : (composers[0] as HTMLElement).isContentEditable),
      effortControlUnique: effortControls.length === 1,
      effortControlExpanded: effortControls.length === 1 && effortControls[0]!.getAttribute("aria-expanded") === "true",
      effortControlClosed: effortControls.length === 1 && effortControls[0]!.getAttribute("aria-expanded") === "false",
      connectorSelected: composerForm !== null
        && any('[data-id^="plugin:"][data-keyword], [app-mention-path^="app://"][app-mention-display-name][contenteditable="false"]', composerForm),
      mentionMenuVisible: any('.__menu-item[tabindex="0"][data-id^="plugin:"][data-keyword], .__menu-item[tabindex="0"] [data-id^="plugin:"][data-keyword], [data-mention-list-scroll-area] button[data-list-navigation-item="true"]'),
      effortControlVisible: any(selectors.effortControl),
      effortItemsVisible: any(selectors.effortItem),
      menuVisible: any('[role="menu"], [role="listbox"], [data-testid="composer-intelligence-picker-content"]'),
      connectorRowsVisible: any('.__menu-item[tabindex="0"], [data-mention-list-scroll-area] button[data-list-navigation-item="true"]'),
      overlayVisible: any('[role="dialog"], [role="alert"], [role="status"]'),
    };
  }, {
    composer: CHATGPT_COMPOSER_SELECTOR,
    effortControl: CHATGPT_EFFORT_CONTROL_SELECTOR,
    effortItem: CHATGPT_EFFORT_ITEM_SELECTOR,
  });
}

async function captureBrowserDiagnosticState(
  page: Page,
  binding?: ChatGptAssistantTurnBinding,
): Promise<unknown> {
  return page.evaluate(({ selectors, binding }) => {
    const rendered = (element: Element): boolean => {
      const candidate = element as HTMLElement;
      const style = getComputedStyle(candidate);
      return candidate.isConnected && style.display !== "none"
        && style.visibility !== "hidden" && style.opacity !== "0";
    };

    const rows = (selector: string, limit = 40) => [...document.querySelectorAll(selector)]
      .filter(rendered).slice(-limit).map(element => ({
        tag: element.tagName.toLowerCase(),
        role: element.getAttribute("role"),
        testId: element.getAttribute("data-testid"),
        ariaExpanded: element.getAttribute("aria-expanded"),
        ariaChecked: element.getAttribute("aria-checked"),
        dataState: element.getAttribute("data-state"),
        textChars: (element.textContent ?? "").length,
      }));
    const scopedRows = (root: Element | null, selector: string, limit = 40) => root
      ? [...root.querySelectorAll(selector)].filter(rendered).slice(-limit).map(element => ({
          tag: element.tagName.toLowerCase(),
          dataKeyword: element.getAttribute("data-keyword"),
          textChars: (element.textContent ?? "").length,
        }))
      : [];
    const composers = [...document.querySelectorAll(selectors.composer)].filter(rendered);
    const composerForm = composers.length === 1 ? composers[0]!.closest("form") : null;
    const assistantTurns = [...document.querySelectorAll(selectors.assistantTurn)].filter(rendered);
    const latestAssistant = binding?.id
      ? assistantTurns.find(element => binding.id.startsWith("group:assistant:")
        ? element.getAttribute("data-turn-key") === binding.id.slice("group:assistant:".length)
        : element.getAttribute("data-turn-id") === binding.id)
      : assistantTurns.at(binding?.ordinal ?? -1);
    const finalRoot = latestAssistant
      ? [...latestAssistant.querySelectorAll<HTMLElement>('.markdown, [data-markdown-text-style="assistant-message"]')]
        .filter(candidate => !candidate.parentElement?.closest('.markdown, [data-markdown-text-style="assistant-message"]'))
        .filter(candidate => candidate.closest("[data-streaming-response-status]") === null)
        .filter(rendered).at(-1)
      : undefined;
    const boundaryNodes = finalRoot
      ? [...(finalRoot.matches("[data-start], [data-end], [data-is-last-node]") ? [finalRoot] : []), ...finalRoot.querySelectorAll<HTMLElement>("[data-start], [data-end], [data-is-last-node]")]
      : [];
    const lastNode = finalRoot
      ? [...(finalRoot.matches("[data-is-last-node]") ? [finalRoot] : []), ...finalRoot.querySelectorAll<HTMLElement>("[data-is-last-node]")].at(-1)
      : undefined;
    const animations = finalRoot && typeof finalRoot.getAnimations === "function"
      ? finalRoot.getAnimations({ subtree: true })
      : [];
    const infiniteAnimations = animations.filter(animation => {
      const timing = animation.effect?.getTiming();
      const endTime = animation.effect?.getComputedTiming().endTime;
      return timing?.iterations === Infinity || endTime === Infinity;
    }).length;
    const finiteAnimations = animations.filter(animation => {
      const timing = animation.effect?.getTiming();
      const endTime = animation.effect?.getComputedTiming().endTime;
      const infinite = timing?.iterations === Infinity || endTime === Infinity;
      return !infinite && (animation.playState === "running" || animation.pending);
    }).length;
    const integerAttribute = (element: Element, name: string): number | null => {
      const raw = element.getAttribute(name);
      return raw !== null && /^-?\d+$/.test(raw) && Number.isSafeInteger(Number(raw))
        ? Number(raw) : null;
    };
    return {
      location: { origin: location.origin, pathSegments: location.pathname.split("/").filter(Boolean).length,
        temporaryChat: new URL(location.href).searchParams.has("temporary-chat") },
      titleChars: document.title.length,
      documentComplete: document.readyState === "complete",
      surfaceId: (globalThis as typeof globalThis & { __CODEX_WEB_GPT_SURFACE_ID__?: unknown }).__CODEX_WEB_GPT_SURFACE_ID__ ?? null,
      bodyTextChars: document.body?.textContent?.length ?? 0,
      composer: {
        visibleCount: composers.length,
        textChars: composers.map(element => (
          element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement
            ? element.value : element.textContent ?? ""
        ).length),
        editors: composers.map(element => ({
          tag: element.tagName.toLowerCase(),
          contentEditable: (element as HTMLElement).isContentEditable,
          focused: element === document.activeElement,
        })),
        unrecognizedEditors: composers.length === 0
          ? [...document.querySelectorAll('textarea, [contenteditable="true"]')]
            .filter(rendered).slice(0, 10).map(element => ({
              tag: element.tagName.toLowerCase(),
              role: element.getAttribute("role"),
              attributes: Object.fromEntries([
                "id", "data-testid", "data-lexical-editor", "data-composer-markdown",
                "contenteditable", "placeholder", "autofocus", "disabled", "readonly",
              ].map(name => [name, element.hasAttribute(name)])),
              inForm: Boolean(element.closest("form")),
              inComposerForm: Boolean(element.closest("form[data-chatgpt-composer]")),
              focused: element === document.activeElement,
            }))
          : [],
        composerSelectedConnectors: scopedRows(composerForm, '[data-id^="plugin:"][data-keyword], [app-mention-path^="app://"][app-mention-display-name][contenteditable="false"]', 20),
        mentionMenuConnectors: rows('.__menu-item[tabindex="0"][data-id^="plugin:"][data-keyword], .__menu-item[tabindex="0"] [data-id^="plugin:"][data-keyword], [data-mention-list-scroll-area] button[data-list-navigation-item="true"]', 20),
      },
      focus: {
        tag: document.activeElement?.tagName.toLowerCase() ?? null,
        role: document.activeElement?.getAttribute("role") ?? null,
        documentFocused: document.hasFocus(),
      },
      effortControls: rows(selectors.effortControl, 10),
      effortItems: rows(selectors.effortItem, 20),
      effortSliders: [...document.querySelectorAll(selectors.effortSliderContainer)]
        .filter(rendered).slice(-10)
        .flatMap(container => [...container.querySelectorAll('[role="slider"]')].map(element => ({
          min: integerAttribute(element, "aria-valuemin"),
          max: integerAttribute(element, "aria-valuemax"),
          value: integerAttribute(element, "aria-valuenow"),
          power: container.hasAttribute("data-model-picker-power-slider"),
          enabled: Boolean(container.querySelector('[data-orientation="horizontal"][aria-disabled="false"]')),
          ticks: [...container.querySelectorAll("[data-selected]")].slice(0, 10).map(tick => ({
            locked: tick.getAttribute("data-locked") === "true" ? true
              : tick.getAttribute("data-locked") === "false" ? false : null,
          })),
        }))),
      menus: rows('[role="menu"], [role="listbox"], [data-testid="composer-intelligence-picker-content"]', 20),
      connectorRows: rows('.__menu-item[tabindex="0"], [data-mention-list-scroll-area] button[data-list-navigation-item="true"]', 40),
      overlays: rows('[role="dialog"], [role="alert"], [role="status"]', 30),
      turns: {
        user: document.querySelectorAll(selectors.userTurn).length,
        stopButtonCount: [...document.querySelectorAll(selectors.stopButton)].filter(rendered).length,
        boundAssistant: binding ? {
          id: binding.id ?? null,
          ordinal: binding.ordinal,
          generation: binding.generation,
          present: latestAssistant !== undefined,
        } : null,
        assistant: assistantTurns.map(element => ({
          testId: element.getAttribute("data-testid"),
          textChars: (element.textContent ?? "").length,
          htmlChars: (element as HTMLElement).innerHTML.length,
          markdownCount: element.querySelectorAll('.markdown, [data-markdown-text-style="assistant-message"]').length,
          streamingStatusCount: element.querySelectorAll("[data-streaming-response-status]").length,
          completionActionCount: element.querySelectorAll(selectors.completionAction).length,
          renderedCompletionActionCount: [...element.querySelectorAll(selectors.completionAction)]
            .filter(rendered).length,
        })),
      },
      completion: {
        actionVisible: latestAssistant
          ? [...latestAssistant.querySelectorAll(selectors.completionAction)].some(rendered)
          : false,
        globalActionVisible: [...document.querySelectorAll(selectors.completionAction)].some(rendered),
        boundaryProtocolPresent: boundaryNodes.length > 0,
        lastNodePresent: lastNode !== undefined,
        boundaryStart: lastNode?.getAttribute("data-start") ?? null,
        boundaryEnd: lastNode?.getAttribute("data-end") ?? null,
        finiteAnimations,
        infiniteAnimations,
      },
    };
  }, {
    selectors: {
      composer: CHATGPT_COMPOSER_SELECTOR,
      effortControl: CHATGPT_EFFORT_CONTROL_SELECTOR,
      effortItem: CHATGPT_EFFORT_ITEM_SELECTOR,
      effortSliderContainer: CHATGPT_EFFORT_SLIDER_CONTAINER_SELECTOR,
      assistantTurn: CHATGPT_ASSISTANT_TURN_SELECTOR,
      userTurn: CHATGPT_USER_TURN_SELECTOR,
      stopButton: CHATGPT_STOP_BUTTON_SELECTOR,
      completionAction: CHATGPT_COMPLETION_ACTION_SELECTOR,
    },
    binding,
  });
}
