# v6.1.12 continuing upstream merge — 唯讀獨立審查

審查對象：`G:\codex-chatgpt-web\tmp\upstream-6.1.11\candidate`，基線 `9237eeee52623a40a55c44228bfb80d58ce00592`，上游 `cdfceafd51df9ab6f19818c145eac5a99c593a3d`。初始核對顯示已解決 index tree 為 `7f8a9dcc3d9ddff8147fe02d06a101e036fd2e26`、working diff 為空。

## 結論

發現一項違反明確驗收條件的 P1，以及兩項有明確觸發路徑的 P2。第 1 項會讓仍在生成的有效工具請求先逾時或被拒絕，應先修正；第 2、3 項不阻擋合併，但分別削弱錯誤契約與診斷輸出的固定上限。

## Findings

### 1. Stop 還可見時，工具審批仍會逾時或自動拒絕 — P1，阻擋指定審批契約

位置：`src/adapters/chatgpt-web/browser-worker.ts:724-729`、`:743-757`。

觸發方式：Saved Chats 中，ChatGPT 在原訊息尚未完成時就顯示工具批准卡，Stop 持續可見超過預設 60 秒。自動批准分支會在 `readyDeadline` 到期時丟錯；手動分支的期限不檢查 Stop，逾時後會按 Deny。兩個 worker observer 呼叫點都會等待此函式（約 `:5472`、`:5707`）。新增測試 `tests/tool-approval-dom.test.ts:96-105` 也明確驗證 Stop 仍存在時可逾時，因此目前綠色測試不符合本次要求「Stop 消失前不可 timeout」。

影響：原訊息仍在 ChatGPT 生成時，adapter 可能先回報失敗，或由手動分支拒絕有效批准；用戶無法等原訊息完成後再處理該批准。這是實際請求失敗，不是純風格建議。

最小修法：Stop 可見期間不要啟動內部批准逾時計時，也不要自動按 Deny；Stop 消失後才開始原有批准期限。明確的呼叫端取消仍應即時生效，以保留既有取消契約；相應測試應區分外部取消與內部批准逾時。

### 2. 啟動頁清理失敗會遮掉 typed 409 — P2，非一般路徑的協定缺口

位置：`src/adapters/chatgpt-web/browser-worker.ts:4372-4381`。

觸發方式：請求已取得 startup page claim，launcher 回傳 `LauncherBrowserTurnOwnerLostError`；接著 `startupPages.releaseClaim(startup)` 因 retired resource cleanup 失敗。catch 會先在 `:4375-4376` 丟出一般 `AggregateError`，因此到不了 `:4378-4381` 的 `ChatGptWebAdapterError(status: 409, retryable: false)` 轉換。`releaseClaim()` 確實可由 cleanup 拒絕；既有 `claimed startup cleanup failure still settles the newly acquired real turn` 測試覆蓋了這種清理失敗邊界。

影響：這個可達分支不保證將 owner-lost 的 409、`browser_turn_owner_lost` 與 non-retryable 狀態傳到 adapter 呼叫端。launcher 本身仍 fail-closed、保留原 running 頁，因此我沒有證據認定這裡會直接重送；問題是呼叫端收到一般清理錯誤，失去「檢查原頁面、不可重試」的明確訊號。

最小修法：先保留 owner-lost 的 typed adapter error，再把 cleanup failure 保留為其 cause/aggregate detail；不可讓清理錯誤抹掉 409 與 non-retryable 分類。補一個 owner-lost 與 startup cleanup 同時失敗的聚焦測試。

### 3. `page_state` 日誌沒有固定大小上限 — P2，非阻擋

位置：`src/adapters/chatgpt-web/browser-diagnostics.ts:163-166`；資料來源 `:385-394`。

觸發方式：失敗 checkpoint 將整個已 sanitize 的 `state` 序列化到一行 console log；其中 `captureBrowserDiagnosticState` 對所有 rendered assistant turns 使用未設上限的 `assistantTurns.map(...)`。長 Saved Chat 在 DOM 中保留大量 assistant turns 時，單一失敗就會輸出與訊息數成正比的長行。sanitizer 移除文字欄位可避免內容洩漏，但不限制陣列長度；診斷保留政策也不會限制這條 console 輸出。

影響：大量已載入歷史可放大 launcher/runtime log，違反 bounded diagnostics 要求。內容仍是結構計數，不是對話文字。

最小修法：console payload 僅輸出 assistant turn 總數與最近固定數量（例如 40 個）的摘要，並記錄 omitted count；不必改動磁碟診斷 envelope。

## 覆蓋範圍

已逐項讀取 HEAD..index 的 25 個 source/test/readme 檔案：

- README：`README.md`、`README.ja.md`、`README.ko.md`、`README.zh-CN.md`。
- 套件與 launcher：`package.json`、`launcher/package.json`、`launcher/electron/browser-host.cjs`、`launcher/electron/control-server.cjs`、`launcher/tests/browser-host.test.cjs`、`launcher/tests/control-server.test.cjs`。
- Source：`src/adapters/chatgpt-web/browser-diagnostics.ts`、`browser-user-message.ts`、`browser-worker.ts`、`personalization.ts`、`thread-environment.ts`、`src/launcher-browser-host.ts`。
- Tests：`tests/attachment-upload.test.ts`、`browser-diagnostics.test.ts`、`browser-turn-binding.test.ts`、`browser-worker-contract.test.ts`、`launcher-browser-host.test.ts`、`multipart-history.test.ts`、`personalization-visible-control.test.ts`、`tool-approval-dom.test.ts`、`upstream-audit-v613.test.ts`。

另讀取 staged 的 `.github/upstream-audit/v6.1.12.json`、`v6.1.12-followups.json` 與兩個 content-addressed evidence archives。新增 archive SHA-256 與 ledger 相符；目前 `codex-v6112-audit.log` 已顯示 closure/reconstruction 測試通過（1 pass、474 assertions）。這確認機械閉合與原始 merge 重建測試，不取代語義審查。

`9fe005e..cdfceaf` 的 23 個 upstream 路徑、44 個 hunks、16 個 test deltas 均已對照 raw diff、ledger source anchors 與 staged resolution：四個 README；launcher 的 browser-host、control-server、package 與兩個 tests；root `package.json`；`scripts/install.sh`；`src/adapters/chatgpt-web/browser-user-message.ts`、`browser-worker.ts`、`thread-environment.ts`；`src/launcher-browser-host.ts`、`src/version.ts`；以及 attachment、browser-turn-binding、browser-worker-contract、launcher-browser-host、multipart-history、personalization-connector-preflight、tool-approval 七個 test files。16 項涵蓋 helper owner replacement 改為 fail-closed、typed conflict、active composer upload、collapsed history exact binding、literal auto-link、viewport/focus restoration、turn token、virtualized acknowledged stage、multipart history、personalization guidance relocation，以及 streaming tool approval。`scripts/install.sh` 保持釘選最後已發布的 Enhanced 版本；`src/version.ts` 的上游常數改動以讀取 root package metadata 的 fork 實作承接。

使用者列出的其餘 fork 邊界已追蹤相關實際呼叫者與現有測試證據：一般 lost-owner 路徑保留原頁並在無 cleanup error 時傳出 non-retryable 409；附件輸入限定 active composer form；auto-link 僅接受 label 與 HTTP(S) URL 完全一致；歷史 bubble 的展開在 `finally` 收回並還原仍連線的 focus 與 scroll；已確認 stage identity 併入 baseline；Saved Chats guidance 留在拆分後的 `personalization.ts`。thread environment 的變動僅加上不含路徑/內容的狀態旗標，既有 strict current-native-root、多 home、post-compaction 與 observer lease 邏輯未被本次 source diff 改寫。API always-Temporary、`store:true` 拒絕、Native2 ABI 與 context cap 的生產路徑未在本次 diff 變更；既有 invariant 批次紀錄為 81 pass。四個 README 的下載按鈕仍指向 fork 的 latest release；root 與 launcher package 版本一致。

v6.1.11 的既有 audit 與 reviewer reports 視為已閉合，未重做。此審查沒有發現其他明確的 P0/P1/P2。

## 已有驗證證據與未執行項目

重用既有 log，沒有重跑測試：launcher 122 pass；browser-turn-binding 單檔 14 pass；invariants 81 pass；owner diagnostics 29 pass、1 DOM skip；root 與 launcher TypeScript checks 的既有結果為通過。原 RED log 中 active-composer、streaming approval 與 exact URL 測試各自證明舊行為失敗。affected 批次仍保留 207 pass、3 fail：其中 read-only DOM 測試逾時 20 秒並關閉共享 browser，後兩個失敗為連帶錯誤；該 browser-turn-binding 檔案後續獨立完整紀錄為 14 pass。失敗 log 保留，不能將 affected 批次報成全綠。

依要求沒有執行完整 suite、Web/live request、runtime/build/restart、package、CI 或發布操作；亦未重審 v6.1.11。沒有進行部署或安裝。

## 唯讀限制偏差記錄

初始狀態檢查誤執行 `git write-tree`，它可能建立 Git object；同一輪未設定 `GIT_OPTIONAL_LOCKS=0` 的 `git status` 也可能刷新 index stat cache。無法由事後狀態判定是否實際寫入新 object/cache；我未嘗試回復，以免再違反禁止 Git 寫入的限制。之後的檢索均設 `GIT_OPTIONAL_LOCKS=0`，未改 source 或 index 內容。這代表本次操作未能完全符合「禁止 git 寫入」要求。

**Verdict: fix 1 before merge; 2 and 3 are P2.**