# 唯讀審查報告

## 審查識別

- 基準：`9ed929efa060b09ba5f136266892cfcaf683d52f`
- 候選 staged tree：`750fb502ce901ae0bcda38df8b360b1704114051`（已確認目標路徑的 tree blob 與 index 一致）
- 審查範圍：`tests/compaction-task-restart.test.ts`、`.github/upstream-audit/v6.1.17-followups.json`，以及判斷其正確性所需的 config、compact request 與 upstream audit 路徑。
- 另有既存未 staged 的 `.gitignore` 修改；未納入審查，也未更動。

## 結論

未發現新的可確認缺陷。先前 P1「乾淨 checkout 缺少專案 `tmp/` 父目錄」已修正：測試先遞迴建立該目錄，再以 `mkdtempSync` 建立隨機 scratch 子目錄；原有路徑界限斷言與 `finally` 清理仍保留（測試第 12 行及第 109 行）。

**Verdict: Ship（限本次 scoped code review；CI 尚未完成，不代表 CI 通過）。**

## 覆蓋與證據

- 實體 probe 寫在各測試獨立的 scratch 目錄中，並以 `spawnSync(process.execPath, [entry])` 執行。每個測試內的同步子程序依序重用自己的 `probe.ts`；兩個測試各有獨立隨機目錄，避免互相覆寫。probe 和 continuation snapshot 都在 `finally` 清理。
- 原有 provenance、重啟、summary trimming、privacy、409 與 legacy checkpoint assertions 均仍在 staged diff 中，沒有移除或放寬。browser worker 的 `run` 被替換為立即丟錯的 guard（測試第 95 行）；測試呼叫直接的 `compactRequest`，沒有呼叫 `startServer`。因此修補未新增真實 browser 或服務啟動。
- `src/config.ts` 的 evaluated Bun entry 拒絕（第 193–197 行）與 ephemeral runtime path 驗證（第 210–221 行）未修改。實體 entry 讓測試子程序不再以 `[eval]` 執行；沒有移除或放寬 production guard。
- staged follow-up 的 `currentSha256` 為 `6f11db870719086313e7e280e13a6b0a31b9cfe1f4b51303d4daf70334280978`，與目前測試檔 LF 正規化後實算值相同；`baselineSha256` 記錄原始測試版本 `92b34578b77dd9085d28bb7eb55534766ce1e2fe7eb8bb4502193c7f3efef9c8`。既有 upstream-audit 收據也通過該 audit 檢查。
- 已讀取既有收據：乾淨 facade 的 RED 為兩例因缺少父目錄而出現 `ENOENT`；修正後 GREEN 為 2 pass、74 assertions；typecheck PASS；upstream audit 為 1 pass、5989 assertions。這些是既有結果，本次依指示沒有重跑測試或 typecheck。

## 尚未確認

- CI run `40977353602` 有四筆同一 fixture 的失敗紀錄；其後整體 run 被外部取消，最終狀態未知，Windows 工作未完成。本審查保留這些失敗事實，不將取消或本機收據解讀為 CI 綠燈。
- 沒有在本次候選上實際執行 Linux/macOS/Windows CI；跨平台執行仍待後續 CI 證明。既有 full product verify:release 與三份 Luna scoped review 涉及未變更的 production source，不能代替這個新 fixture 的跨平台結果。
- source/no-finalROOT 仍未解決，與本次測試 fixture 修正無關；未納入本次審查。