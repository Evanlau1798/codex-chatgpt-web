# CI probe entry 變更審查

## 變更摘要
`tests/compaction-task-restart.test.ts` 將每個獨立 probe 寫成專案內的實體 `probe.ts`，再以新的 Bun 子程序執行；既有 compaction、隱私、HTTP 與 browser guard 斷言均保留。`.github/upstream-audit/v6.1.17-followups.json` 為這個測試記錄原始與目前內容的 SHA-256。

## 必須修正

1. **P1 — 乾淨 checkout 沒有 `tmp` 父目錄**（`tests/compaction-task-restart.test.ts:12`）
   - **情境與證據：** `mkdtempSync` 不會建立父目錄，而 `tmp/` 未納入 HEAD 的 Git tree，且被忽略。預設 CI 驗證流程在 `scripts/verify.ts` 先執行 root tests；`scripts/run-root-tests.ts` 只在作業系統的 `tmpdir()` 建立隔離目錄，沒有建立專案的 `tmp/`。因此乾淨的 Linux、macOS 或 Windows checkout 會在測試本體執行前因 `ENOENT` 失敗；目前本機有既存 `tmp/`，所以既有綠燈收據沒有覆蓋這個情境。
   - **修正方向：** 在 `mkdtempSync` 前以 `mkdirSync(resolve(project, "tmp"), { recursive: true })` 建立父目錄；保留隨機 scratch 子目錄、路徑斷言與 `finally` 清理。
   - **若不修：** 乾淨 runner 的 `bun run verify` 會在 compaction 測試處失敗，這項 CI portability 修正無法通過驗收。

## 審查範圍與證據

- 比對基準為 HEAD `9ed929efa060b09ba5f136266892cfcaf683d52f`；staged tree 為 `af2fce06e118adacab8d929c2b0f46644daf752c`。staged 變更只有指定的兩個路徑；既存未 staged `.gitignore` 修改未納入。
- `baselineSha256` 的 LF 正規化結果 `92b34578b77dd9085d28bb7eb55534766ce1e2fe7eb8bb4502193c7f3efef9c8`，符合 HEAD 中舊測試檔內容（blob `86901939dbb651f315869a96c17e8cd70a29822f`）。`currentSha256` 的 LF 正規化結果 `6228553baa4cbd1a64b43626c55d94c2c643e3e9c8ca0f7073916605601fa7c6`，符合目前 staged 測試檔。歷史 worktree 中沒有另一份同路徑測試檔；未更動歷史 archive 內容，僅新增本次獲准的審查報告。
- 測試 diff 只新增 `writeFileSync`、將共同 probe 程式寫入 scratch，並改為以實體 entry 啟動子程序；原有 assertions 沒有放寬或移除。每個測試使用獨立隨機 scratch；同一測試內的 probe 由 `spawnSync` 逐次執行，持續共用該測試的 hash-only continuation state 以驗證重啟行為。
- `src/config.ts` 的 evaluated-script 拒絕與 durable runtime path 驗證未變。實體 `.ts` 路徑會作為 Bun 的 entry 傳入，靜態上不再符合 `[eval]` 拒絕條件；`compactRequest` 是直接呼叫，且缺少 provenance 時的 browser worker guard 會阻止 browser work，這段測試不安裝或啟動服務。
- 已讀取既有收據：probe 測試 2 pass／74 assertions、typecheck PASS、audit 1 pass／5989 assertions。依指示沒有重跑測試、typecheck、服務或跨平台操作。**未確認**此次候選在 Linux/macOS runner 的實際執行結果；目前跨平台結論是靜態檢視，且仍被上述缺少父目錄問題阻斷。

## 結論

**Verdict: fix 1 first.**