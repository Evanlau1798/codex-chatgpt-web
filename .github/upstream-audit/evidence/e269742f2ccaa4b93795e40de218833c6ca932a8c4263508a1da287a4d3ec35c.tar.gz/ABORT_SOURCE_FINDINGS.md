# ERR_ABORTED source investigation, 2026-10-17

User permits releasing if causal evidence identifies an external GPT Web problem. This does not waive actual local bugs, independent review or the final release gate.

## Observed C9 evidence

Probe installed 12:42:44Z before owned POST 12:47:53Z. Trace4888bc75bb2d, daemon113984, surface sUNaLxWBsF-RddqnE2Dpze3aIXilYkUS. HTTP200/h2/fromServiceWorker=false. Original profile preserved. The probe records only transport/control metadata and sanitized static-script frames, no response text or credentials.

Browser clock order for request1:
-12:54:50.594Z SSE `[DONE]` consumed.
-12:54:50.597Z owned signal aborted and reader canceled by chatgpt.com static scripts.
-12:54:50.663Z CDP reports canceled=true/net::ERR_ABORTED.
-12:55:51.554Z runtime missing-final recovery decision (61s AFTER DONE).
-12:57:17.064Z Native final accepted on recovery;12:57:22.652Z tunnel completion.

Request2 also received `[DONE]`, then Web reader cancellation and ERR_ABORTED; its Native final was already accepted and completed successfully. No observed window.stop, Stop gesture, main navigation or crash preceded request1 cancellation. The captured error is therefore a post-DONE Web cleanup artifact, not evidence of a server disconnect. This observation does NOT prove all earlier HTTP2/abort failures share the cause, nor explain why the first model response omitted Native final. Missing protocol metadata beyond literal DONE is inconclusive because parser coverage is deliberately narrow.

Actual cached Electron isolated loopback selftest distinguishes five cases: page AbortController, local CDP stop, server destruction, normal EOF and normal DONE followed by reader cancellation. The last case reproduces ERR_ABORTED after successful server completion. C8 was not prearmed and is not ERR_ABORTED causal evidence.

## Separate confirmed local bug

C8 accepted an initial final, requested an answer correction, then rejected the retry BEFORE its Send activation: the trusted correction producer omitted the current prepared token. Persistent production-factory/real-worker regression first fails because the correction lacks its token. The factory now binds ordinary correction/steering retries to the registered active token, preserves metadata and strict worker validation, and excludes compaction/control-only paths. No new finalization-only instruction or tool closure is introduced. Original model omission remains separate.

## Review and cleanup

C9 Carson FINAL incomplete/no confirmed finding; closed, not Ship approval. Outstanding scope: complete C4-C6 review, auth source ownership, surrounding liveness/stream guards. Prior UA snapshot belonged to an earlier restart; provide a fresh snapshot for the next reviewer. Manifest digest is SHA256(JSON.stringify(trimmed UTF8 git diff --binary excluding .gitignore)), not raw diff bytes.

SIGINT ended probe8245; explicit cleanup verified restoration of the one instrumented page, all other pages uninstrumented. No browser/page was closed. Before any new reviewer, apply correction through canonical atomic restart and verify settings/source.

## Similar public reports (not causal proof)

July30 first-hand Web custom-MCP interruption report: https://community.openai.com/t/custom-mcp-connector-web-client-drops-the-stream-mid-turn-connection-interrupted-works-fine-on-mobile-same-server-same-connector/1388400

October12 follow-up with server-side tool data, explicitly unproven cause: https://community.openai.com/t/web-client-connection-interrupted-with-a-custom-mcp-connector-server-side-evidence-from-187k-tool-calls-follow-up-to-the-closed-topic-1388400/1405722

Chromium primary error definitions: https://chromium.googlesource.com/chromium/src/+/main/net/base/net_error_list.h

These reports support investigating Web/frontend behavior; they do not prove an OpenAI outage, fixed session-duration limit or a universal fix.
