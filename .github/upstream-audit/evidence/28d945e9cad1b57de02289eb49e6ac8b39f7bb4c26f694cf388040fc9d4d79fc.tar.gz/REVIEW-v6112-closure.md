# v6.1.12 targeted review closure

## 範圍與結論

唯讀覆核候選目錄 `G:\codex-chatgpt-web\tmp\upstream-6.1.11\candidate`。目前 `HEAD` 為 `9237eeee52623a40a55c44228bfb80d58ce00592`；將原 review tree `7f8a9dcc3d9ddff8147fe02d06a101e036fd2e26` 與目前工作檔案比較後，差異限於指定四檔：`src/adapters/chatgpt-web/browser-worker.ts`、`src/adapters/chatgpt-web/browser-diagnostics.ts`、`tests/launcher-browser-host.test.ts`、`tests/browser-diagnostics.test.ts`。未重做原報告的全量覆蓋。

**結論：兩項 P2 修正成立；原 P1 是把 brief 誤寫的「Stop 消失前不得 timeout」當成驗收條件，不是目前 auto-approval 契約的 blocker。指定範圍沒有未解 P0/P1/P2。**

## P2 #1：owner lost 與 startup cleanup 同時失敗

`browser-worker.ts` 在清理 claim 前先將 `LauncherBrowserTurnOwnerLostError` 轉為 `ChatGptWebAdapterError`（409、`browser_turn_owner_lost`、`retryable: false`）。清理也失敗時，typed error 的 `cause` 改為 `AggregateError([raw owner error, cleanup error])`，AggregateError 的 cause 是 raw owner error；沒有引用 typed error 本身，因此不形成循環。一般取消與其他 cleanup-failure 分支仍維持原錯誤包裝。

`tests/launcher-browser-host.test.ts` 新增同時觸發 owner loss 與 cleanup rejection 的回歸案例，確認 typed 欄位及兩個 raw error 均保留。既有 `codex-v6112-review-red.log` 記錄 0 pass、2 fail：新測試收到一般 AggregateError，診斷測試輸出超過 8,000 字元；`codex-v6112-review-green.log` 記錄 31 pass、1 個既有 DOM skip、0 fail、137 assertions。既有 TypeScript check 紀錄為 PASS；本次沒有重跑。

## P2 #2：`page_state` console log 陣列上限

`browser-diagnostics.ts` 只在 `page_state` 的 console JSON replacer 中摘要長度超過 40 的陣列，保留總數、略過數與最近 40 筆。磁碟 envelope 先以無 replacer 的 `JSON.stringify` 寫出，未受 console 摘要影響。新增的診斷測試以 1,000 筆 assistant history 驗證 console 只保留最近 40 筆且行長低於 8,000 字元，同時磁碟 JSON 保留全部 1,000 筆；上述 GREEN 紀錄通過此測試。

## 原 P1：streaming approval deadline disposition

目前契約由整合差異及 DOM 測試共同限定為 **自動批准** 的 bounded streaming wait。`browser-worker.ts` 在 `autoApprove` 分支先等 Allow/Deny 控制項掛載，接著以呼叫端傳入的 `timeoutMs` 設定 `readyDeadline`；兩個 worker 呼叫點均傳入 `CHATGPT_TOOL_CONFIRMATION_TIMEOUT_MS`（60 秒）。Stop 可見期間每輪檢查 abort；deadline 到期會丟錯且不按 Allow。Stop 消失後，程式再次檢查 dialog 與 abort，才按一次性 Allow。整合新增的 `tests/tool-approval-dom.test.ts` 明確測試：Stop 持續可見時 timeout 或 cancellation 都不會按任何 permission button、批准卡仍存在；另一測試驗證 Stop 消失前不按、消失後才按 Allow。

我也核對了相對候選起點 `9237eeee...` 的 approval 專項差異：Stop/deadline 邏輯只新增在 `autoApprove` 分支；手動分支 deadline 到期時 Deny 的路徑沒有被該 delta 改動。原報告所述「手動批准會在 Stop 可見時到期 Deny」是可觀察的既有行為，但不違反這項 auto-approval delta 的 bounded wait 契約。若需求改成手動批准也必須等 Stop 消失，才需要另立行為變更；本次沒有此驗收依據。

因此，停止生成持續超過 deadline 時 auto-approval 會 timeout，是明確 bounded contract 的預期結果，不是缺陷。timeout/cancel 不會誤送 Allow。原 P1 不阻擋本候選。

## 限制

本次只讀取差異、指定程式與測試及既有報告／log；沒有執行測試、Web、build、runtime、restart，沒有操作 Git index 或 source/index。結論限於上述兩項 P2 與 P1 disposition，不延伸原報告的完整 review。
