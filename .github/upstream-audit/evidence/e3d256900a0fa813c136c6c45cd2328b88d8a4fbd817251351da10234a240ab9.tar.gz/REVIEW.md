# v6.1.11 Saved Chat retry 針對性覆核

## 結論

在本次限定範圍內，沒有確認的 P0、P1 或 P2 blocker。Saved Chat 首次送出後由首頁 `/` 轉到 `/c/<id>` 時，重試會重新驗證同一 model/effort；原本已在 `/c/<id>` 的會話不能藉重試轉移到另一會話，Saved/Temporary 模式轉換也會拒絕。

覆核範圍是舊 tree `bfaeff19e6c222fb908dfbaf871e8f9695035027` 到 staged tree `9c709dcf9ae5a116b118f05f3753edb6cebb706a` 的兩檔增量。兩檔 staged blob 與 `9c709d…` tree 一致；HEAD 為 `7016a0cf8bf421ab4944f782ebf140ff93d1657f`，MERGE_HEAD 為 `9fe005eefb93913c138368b0972b8a0c476fcf54`，working-tree diff 為空。

## 覆核證據

- 在 [browser-worker.ts:4895](G:/codex-chatgpt-web/tmp/upstream-6.1.11/candidate/src/adapters/chatgpt-web/browser-worker.ts:4895)，僅在 retry 且選擇 URL 已改變時進入檢查。舊 URL 與目前 URL 都必須通過 `isSelectedChatGptTurnUrl(..., useSavedChats)`，舊 URL 的 pathname 還必須是 `/`；通過後於 4903 行以原 `turn.modelId`、`mode.effort`、`turn.modelFamily` 再跑 `selectModelAndEffort`。舊 URL 若為既有 `/c/<id>`，即使新 URL 仍是合法 Saved Chat 路徑，也會因舊 pathname 非 `/` 而拒絕轉移。
- 共用 helper [chatgpt-session.ts:153](G:/codex-chatgpt-web/tmp/upstream-6.1.11/candidate/src/chatgpt-session.ts:153) 對 Saved Chat 限定 `https://chatgpt.com`、首頁或單一 `/c/<id>` 路徑，並拒絕 `temporary-chat=true`；Temporary 模式沿用原 Temporary URL 驗證。其他 helper 呼叫點是 tunneled 與一般 response observer，本次沒有改動它們。
- [browser-tunneled-fallback.test.ts:940](G:/codex-chatgpt-web/tmp/upstream-6.1.11/candidate/tests/browser-tunneled-fallback.test.ts:940) 驅動 `runBrowserTurn` fixture，要求首頁轉新 `/c/` 後正常完成、共兩次 send，且兩次選擇都保留 `gpt-5.6-sol`、`xhigh`、`5.6`。951 行案例分別驗證既有會話間轉移與 Saved 到 Temporary 模式轉換：均只送出一次、沒有答案，也沒有再次選擇。
- 封存的 RED log 在舊 guard 上讓首頁重試案例以預期錯誤失敗；GREEN log 顯示兩個新增案例通過，整組三個測試檔共 274 pass、2,618 assertions。封存 SHA-256 與檔名相符；封存 test source 經 CRLF 正規化後與 candidate 檔案相同，worker source 位元組完全相同。
- Temporary-only 的 post-Send extra-navigation fallback（browser-worker.ts 約 2055 行）與本次兩檔增量無關且未變更；依本輪範圍，沒有把它擴成額外提交或 live 證據要求。前兩個 P2 與 selected-mode/secondary-home 修正不重審。

## 範圍與限制

本報告只覆核上述 retry 修正、其 URL helper 與相鄰會話隔離測試；不構成整個 merge 或 release review。沒有修改 source、index 或 commit，也沒有執行測試、runtime、瀏覽器/Web/live 或外部寫入。沿用所提供且與候選內容相符的 RED/GREEN 證據；整合 6.1.12 後的完整 release gate 仍待執行，但不否定本次 source closure。
