# Round 2 C-settings-audit 獨立唯讀審查

## 身分與範圍

審查以基線 tree `d686b4a04b0823fa15e22bacdc95da219d181048` 對凍結候選 tree `66791c6624b954920dc7624e7201a9431072f35c` 的差異為準；canonical `HEAD` 仍是 `972b19b7088ab4d843e2954346c22fe0afb071b4`。依 `round2-review-manifest.json`，審查模型／effort 為 `gpt-6-luna`／`max`。未派工或建立子代理。

已覆蓋 C-settings-audit 六項：舊 target archive `2e29eab6…` 移除、新 archive `84fd5e58…` 加入、`.github/upstream-audit/v6.1.17.json`、`scripts/lifecycle-sim/manifest.ts`、`tests/lifecycle-profiles.test.ts`、`tests/runtime-layout.test.ts`。另讀取前次 finding 報告與必要的 production/helper/test 呼叫路徑。沒有執行測試或 gate，沒有操作瀏覽器、帳戶、服務或安裝程序；只寫入本 ignored 報告。

## Finding

### [P2] Audit ledger 仍把已完成的 Round 2 gate 與 restart 列為待辦

位置：[v6.1.17.json](/G:/codex-chatgpt-web/.github/upstream-audit/v6.1.17.json:18)。`validation.status` 與 `validation.pending` 仍寫著 Round 2 `verify:release` 和 canonical atomic restart 待執行。

候選 tree 相同的 [remediation-freeze.json](/G:/codex-chatgpt-web/tmp/upstream-6.1.15/remediation-freeze.json) 記錄 gate exit code 0，且其 log SHA-256 與 `verify-release-v617-round2-third.log` 相符；[remediation-restart-verification.json](/G:/codex-chatgpt-web/tmp/upstream-6.1.15/remediation-restart-verification.json) 記錄 `sourceTree=66791c6624b954920dc7624e7201a9431072f35c`、健康且接受請求。偏好比較檔兩筆 `changed` 陣列皆為空。也就是說，ledger 的 pending 清單落後於同候選的收據；`coverage.pending=0` 是 upstream 映射缺漏數，與這些執行 gate 的狀態不同。

發布前應更新 ledger 狀態，將已通過的 gate/restart 標為完成，保留仍未完成的獨立審查及 exact-head CI 狀態。若此欄位設計上是凍結當時的快照，需明確標示其時間／基準，避免讀者把它當成目前狀態。這是 audit metadata 的準確性問題，沒有證明 runtime 行為錯誤；本次依唯讀限制未改候選檔。

## 修復與呼叫路徑核對

### Archive、ledger 與 upstream mapping

候選 tree 刪除舊 archive，新增 SHA-256 為 `84fd5e58b1a28817b5b809e9bdc9f8099cc80ae674f2aad0c44dad5bd995825e`、765,585 bytes 的 archive；ledger 指向同一路徑與雜湊。archive 的 165 個 tar member 與 ledger `targetBlobs.objects` 完全相同，沒有缺項或額外項。新增的 hash anchors 可對應到候選中的 manifest、config 測試、lifecycle manifest、compaction restart/local-release 測試及相關 production 檔案。

映射數仍為 118 paths、555 hunks、226 upstream test-case deltas；403 筆 fork supplemental test anchors 獨立記在 `supplementalTests`，未併入 upstream 計數。`tests/upstream-audit-v613.test.ts` 的實際 verifier 會檢查 archive digest/bytes、每個成員的 Git blob SHA-1、member 集合、source line hashes 與目前 follow-up anchors；`next.tests.length` 仍必須等於 upstream `testCaseDeltas`。提供的 `round2-audit-closure.log` 顯示 1 test、5,929 assertions 通過。這支持「舊 archive 內容過時後刷新」的說明；我沒有找到可單獨重建該次 whole-file mismatch 的 log，但沒有看到 verifier 被放寬。

prior ledger 仍精確引用基線中的 v6.1.13 blob `2a223541791abf53b36919d4499a524bbc8be778`；我以 `git cat-file` 讀取該 blob 計得 SHA-256 `c700a8ce…`，與 ledger 相同。其 prior evidence archive SHA-256 也符合記錄值 `e3d9ece5…`。新 archive 僅保存 hash 命名的 Git blobs；測試與 audit metadata 不含帳戶狀態或執行期偏好內容。

### 核心 config 覆蓋

前次報告指出的覆蓋缺口已補上：[runtime-layout.test.ts](/G:/codex-chatgpt-web/tests/runtime-layout.test.ts:408) 現在測試舊 `useTemporaryChats` 單獨存在時的 true/false 情況，以及新舊旗標四種互相衝突組合；兩者都走 `loadConfig()` 和 `loadConfigForSetup()`。斷言涵蓋 Saved Chats 缺省為 false、新值優先、舊鍵不回存、`saveConfig` 後新值不被相反舊鍵覆蓋，以及 `unrelatedPreference` 跨存檔保留；也檢查 provider config 的兩種互動模式。

[config.ts](/G:/codex-chatgpt-web/src/config.ts:447) 的 parse/save 行為在此候選沒有變更：缺省值仍是 false，解析及存檔都移除退役鍵，存檔先展開其他設定以保留未知偏好。`config-retired-red.log`／`config-retired-green.log` 記錄舊行為失敗及修復後通過；Round 2 的 `round2-config-matrix-green.log` 為 27 pass、0 fail。這次是對測試證據的補強，沒有發現新的 config runtime 缺陷。

### Lifecycle manifest 與實際 production primitives

[manifest.ts](/G:/codex-chatgpt-web/scripts/lifecycle-sim/manifest.ts:20) 將 `compaction-task-restart.test.ts` 與 `local-compaction-release.test.ts` 加到 Codex lane；[lifecycle-profiles.test.ts](/G:/codex-chatgpt-web/tests/lifecycle-profiles.test.ts:105) 明確斷言兩者已註冊。`scripts/lifecycle-sim/run.ts` 直接匯入該 manifest，在 `codex`／`all` lane 以 Bun 對清單中的測試檔執行；Codex lane 仍先跑 Compatibility V1、Native V2、interrupt 與 compact-client smoke。凍結候選的 release log 有 `CODEX_DETERMINISTIC_LIFECYCLE_LANE_OK` 及 `ALL_DETERMINISTIC_LIFECYCLE_LANES_OK` 標記，該 gate 收據 hash 已核對。

兩個新增測試不是重寫 business rules：

- `local-compaction-release.test.ts` 使用 production `parseRequest`、execution/retry/model-failure identity helpers、`ChatGptTurnSessions`、`sessionForChatGptRequest` 與 adapter `runTurn`。它驗證 response/local_compaction/compaction 身分分離、local compact 對應正確來源 owner、先退休並釋放舊 tool owner，再建立沒有 tool token 的 read-only runtime；外部 browser worker 只用 deterministic stub 隔離。
- `compaction-task-restart.test.ts` 在新 Bun 子程序中呼叫 production continuation load/save、request parser、prompt compiler 與 `compactRequest`。它驗證重啟後只接受被認證的當前 goal/delegation，不把較舊 human message 升格成任務；持久化檔不含任務文字、summary、thread/turn ID。缺少來源時，production handler 回 409、不產生 summary、不洩漏輸入，且 browser worker guard 確認沒有啟動 browser work。

連接的 `compaction-task-context` 測試以真實 prompt compiler 驗證 inline/multipart 預算下任務、累積 summary、最新 steering 與 final compact instruction 的保留；不可縮減的輸入 fail closed，且不改寫 parsed context。`submitted-delivery-retry` 仍覆蓋 accepted canonical tool result 不可重播，以及 call/result 證據不匹配時不授權 retry。這些測試與 V1/V2 smoke 保留 Native2 ABI、checkpoint/budget 隔離及 accepted-work replay 的相關防線；本次 C 路徑未改 public ABI 或 production compaction code。

## 驗證限制與結論

本報告重用已保存收據，沒有重跑任何測試或完整 gate。獨立確認 Round 2 gate 的候選 tree、exit code、log hash，以及 canonical restart 的來源 tree、健康／accepting 狀態；HTTP 測試直接呼叫 production `compactRequest` handler，沒有自行啟動 listener，因此不把它描述成 live socket 驗證。未審完整 A/B 領域，也未驗 exact-head main CI。ChatGPT 長時間 Web turn 缺少 final 的 ROOT 仍未解決；本次修復不構成其根因已解決的證據。

**結論：先修正 1 項 audit metadata 狀態差異，再依發布流程處理。C-settings-audit 範圍未發現 runtime 行為缺陷；這不是對其他審查領域或整合候選的 blanket approval。**
