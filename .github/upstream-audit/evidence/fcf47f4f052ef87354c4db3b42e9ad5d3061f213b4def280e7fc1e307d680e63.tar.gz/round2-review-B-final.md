# Round 2 B-native 修補獨立審查

## 結論

在本次負責的 7 個 B-native 檔案與必要呼叫路徑中，**沒有確認的 actionable findings**。修補把 legacy local compaction 從一般 response 的 execution、round、retry、model-failure 與 trace 身分分離；透過來源 response 身分保留 admission；並讓相同 retained conversation 的活躍 owner 完成退休後才建立唯讀 compaction runtime。accepted canonical delivery 的 retry 例外也明確排除 local compaction。

這是範圍限定的修補審查，不是對整個 v6.1.17 整合的 blanket approval。既有長時間 Web turn 缺少 final 的 ROOT 問題仍未解決；本次修補沒有證據顯示它處理了該問題。

## 候選版本與限制

- Canonical checkout：`G:/codex-chatgpt-web`；`HEAD`/C0：`972b19b7088ab4d843e2954346c22fe0afb071b4`。
- 比較基線：`d686b4a04b0823fa15e22bacdc95da219d181048`；凍結候選 tree：`66791c6624b954920dc7624e7201a9431072f35c`。
- 審查前確認目前 7 個指定檔案與 frozen candidate 相同；沒有改動 source、tests、config、index 或其他檔案。
- 未重跑測試、完整 gate、build 或 runtime 操作。使用既有 RED/GREEN logs，以及 `round2-review-manifest.json`、`remediation-freeze.json`、`remediation-restart-verification.json` 作為提供的驗證紀錄；沒有把通過 gate 當成程式正確性的替代證明。

## 指定檔案覆蓋

Production：

- `src/adapters/chatgpt-web/conversation-key.ts`
- `src/adapters/chatgpt-web/index.ts`
- `src/adapters/chatgpt-web/submitted-turn.ts`
- `src/adapters/chatgpt-web/turn-execution-key.ts`
- `src/adapters/chatgpt-web/turn-retry-identity.ts`

Tests：

- `tests/local-compaction-release.test.ts`
- `tests/submitted-delivery-retry.test.ts`

另讀取 parser、turn environment/revision、`sessionForChatGptRequest`、session registry、runtime factory、model mode、server model-rejection receipt 與 retry policy，確認實際呼叫鏈和 retirement/release 邊界。

## 修補路徑結論

### Request flags、目的與各種 identity

`parseRequest` 會把沒有 remote/native compaction item、但 metadata `request_kind=compaction` 的 legacy 請求標成 `_localCompactionRequest`；一般 turn 和帶 `compaction_trigger` 的 remote compaction 分別走不同旗標（`src/responses/parser.ts:659-673`）。

`chatGptTurnPurpose` 將三種目的分成 `response`、`local_compaction`、`compaction`。Execution key 對兩種 compaction 都包含完整 raw input revision；round key 同時含 purpose 與 input；retry key 使用相同 purpose。Model-failure key 對 local compaction 以 turn/purpose、model 身分及去除 developer/system items 後的 native input 建立拒絕收據，因此只刷新 harness developer/system 文字不會重新送出相同被拒模型；改變 native work 或 model 身分才會換 key（`turn-execution-key.ts:18-75`、`turn-retry-identity.ts:23-65`）。RED/GREEN 證據中的 developer-only refresh 與新增 user work 正好區分這兩種情況。

`chatGptTurnTraceId` 現在對 local compaction 使用其 execution identity；一般 response 仍走原本 conversation-key 分支，remote compaction 仍使用原 compaction identity。`chatGptCompactionSourceExecutionKey` 維持 response purpose，沿用相同 thread/turn/model 身分時會指回一般 response owner。這保留來源查找與 admission 身分，同時讓 local compaction 自身的 trace 不與原 response 混用（`conversation-key.ts:95-105`、`turn-execution-key.ts:30-59`）。

### Admission、session replacement 與唯讀 runtime

Adapter 先由 local compaction 導出 source execution key，再以已存在來源 session 的 trace 執行 `requireAutomaticAdmission`；建立或重建 compaction runtime 前也會重新檢查同一 admission trace。新 local-compaction trace 不會被誤當成全新帳戶 session（`index.ts:258-280`）。

Local compaction 雖進入一般 `sessionForChatGptRequest` 分支，但其 execution key 已與 response 分離。該函式把解析出的 retained conversation key 傳給 registry；registry 找到同 conversation 且 browser 尚未 physical-settle 的 owner 時，先移除該 owner、取消它、等待 physical settlement/release，再建立新 session（`steering.ts:101-136`、`turn-session-registry.ts:90-114,244-255`）。不同 conversation 的 owner 不會符合該條件。Runtime factory 收到 adapter 設定的 `localToolsEnabled: false`，解析為 `localTools=false`，建立 read-only runtime，且不走 tool-token 註冊分支；factory 的 runtime execution key 亦使用新的 local-compaction execution identity（`index.ts:276-283,311-372`、`adapter-runtime-factory.ts:79-88,155-160,221-293`）。

新增 lifecycle 測試使用 production parser、key functions、`sessionForChatGptRequest` 與 registry。它建構 accepted、尚未 physical-settle 的 tool owner，透過 production session 方法記錄 outstanding call 及已送達 canonical result，再要求同 turn local compaction，並檢查新唯讀 owner、來源取消/release、來源 key 移除和 unrelated owner 保留（`tests/local-compaction-release.test.ts:59-133`）。受控 runtime/Promise 是外部瀏覽器邊界的 fixture；測試沒有重寫 registry 的 ownership 判斷。Production 的 read-only factory 接線則由上述實際程式碼確認。

### Accepted work、delivery retry 與 model rejection

唯一允許的 accepted `chatgpt_delivery_timeout` retry 仍要求完整 canonical result 證據；現在另外拒絕 `_localCompactionRequest`。`submittedBrowserFailure` 與 `submittedStallFailure` 共用同一個 `submittedFailure`，所以兩條錯誤入口都受此邊界保護（`submitted-turn.ts:21-56,77-99`）。因此即使舊 tool result 留在 compaction input，也不能把來源 owner 的 accepted delivery 當成 local compaction 可重送的理由。新的 local execution identity 又阻止 compaction 直接取得來源 tool session/token。

Server 與 adapter 使用同一 `chatGptModelFailureKey`。模型遭 terminal rejection 後，server 在建立 adapter 前查詢該收據並回 HTTP 400，避免同一 native work 再觸發 browser send（`server.ts:231-237,270-277`；`index.ts:289-308,752-790`）。普通 response purpose、execution payload 與 trace 分支沒有被此修補改變；Native2 公開 ABI、budget/checkpoint 與 final-output 程式碼也不在這 7 個 diff hunks 中。

## RED/GREEN 與 runtime 證據

- `round2-local-compaction-isolation-red.log`：先前 identity collision 導致目的 key 僅有兩種，且 registry 未啟動替換 runtime；`round2-local-compaction-release-green.log` 與 `round2-final-related-local-compaction-release.log` 記錄修補後通過。
- `round2-local-compaction-retry-red.log`：local compaction 曾通過 delivery retry 例外；`round2-submitted-delivery-retry-green.log` 記錄加入 local boundary 後 37 pass、0 fail。
- Frozen packet 記錄 `verify:release` exit 0；restart verification 記錄 canonical source tree 為候選 tree，daemon healthy/accepting。這些是既有證據，本審查沒有重跑或獨立操作 runtime。

## Findings 與限制

**沒有可確認的 actionable findings。** 審查確認的是指定 B-native 修補及其必要呼叫鏈，未重新審查其他 reviewer domain 或全量整合 diff。未執行 live Codex native request、真實 browser session 或模型拒絕流程；因此 native endpoint 的現場時序與長時間 Web missing-final ROOT 仍是未由本次 reviewer 驗證的範圍。上述限制不構成已證實缺陷，也不應解讀為該 ROOT 已修復。
