# A-context 獨立審查報告

## 結果

A-context 範圍審查完成；發現 **2 項 actionable findings**。這是指定修正差異的領域審查，不代表整個 v6.1.17 integration 獲得核准。依使用者限制，本 reviewer 沒有修改 source/tests/config/index，也沒有執行測試、建置、安裝、瀏覽器或 runtime 操作，沒有派遣 reviewer/agent。

## 範圍與證據

- 比對 canonical `main` 的 C0 `972b19b7088ab4d843e2954346c22fe0afb071b4` 與凍結候選 tree `d686b4a04b0823fa15e22bacdc95da219d181048`；不採用歷史整合 worktree 或 `tmp/upstream-6.1.15` 舊候選。
- 逐檔檢視 remediation manifest 指定的 8 個 A-context primary files 及所有 staged hunks：
  - `G:\codex-chatgpt-web\src\adapters\chatgpt-web\compaction-continuation.ts`
  - `G:\codex-chatgpt-web\src\adapters\chatgpt-web\input-tokens.ts`
  - `G:\codex-chatgpt-web\src\adapters\chatgpt-web\multipart-browser-transport.ts`
  - `G:\codex-chatgpt-web\src\adapters\chatgpt-web\prompt.ts`
  - `G:\codex-chatgpt-web\tests\compaction-continuation-registry.test.ts`
  - `G:\codex-chatgpt-web\tests\compaction-task-context.test.ts`
  - `G:\codex-chatgpt-web\tests\compaction-task-restart.test.ts`
  - `G:\codex-chatgpt-web\tests\multipart-compaction.test.ts`
- 為判讀呼叫路徑，另檢視 parser/environment、Responses compaction/compact handler、terminal HTTP error mapping、adapter/runtime factory、submitted-turn/turn-execution、model/context-window 與相關回歸測試。
- 使用者提供的 `verify:release` log SHA-256 經本地雜湊核對為 `0964e604223da219385c7fd2403fed43e5e0be97dd56d0965496fff400f1b44c`。此為既有證據，不是本次 reviewer 重跑；沒有把先前失敗嘗試當成通過證據。

## Findings

### [P1] 壓縮裁切可刪除 checkpoint 後的有效 steering

**觸發條件：** 已有可接受的累積 checkpoint；新的 user/parent steering 位於 checkpoint 之後；後面還有 assistant 或 tool 紀錄，使 steering 不是輸入最後一筆；重新編譯後仍超出壓縮預算而進入裁切迴圈。

**位置：** [prompt.ts](G:/codex-chatgpt-web/src/adapters/chatgpt-web/prompt.ts:570) 的 `requiredTasks` 只標記本次插入的恢復 task；[prompt.ts](G:/codex-chatgpt-web/src/adapters/chatgpt-web/prompt.ts:610) 的 `discardIndex` 會刪除任何非 checkpoint、非最後一筆且不在該集合的紀錄。對有新 steering 的 replay，[compaction-continuation.ts](G:/codex-chatgpt-web/src/adapters/chatgpt-web/compaction-continuation.ts:155) 明確不插回舊 task，而讓原始 parsed messages 保留新指令；該指令因此不會進入 `requiredTasks`。

**影響：** 若當前指令不是最後一筆，它會成為最早可刪除的普通紀錄之一。迴圈可能在沒有錯誤的情況下移除它，最後用 checkpoint、後續 assistant/tool 歷史及壓縮控制文字產出摘要。摘要於是可能遺漏或違反當前 steering，並把不完整的狀態帶入下一回合。這是 reachable 的 over-budget compaction 路徑，不只是測試覆蓋缺口。

**最小修正：** 按已驗證的 revision/source provenance 將當前有效 steering 所在紀錄也加入保留集合；仍須讓新 steering 壓過舊 task，不能因為保留 steering 而恢復過期 task。

**缺少的回歸：** restart/continuation 狀態含舊 task 與 checkpoint，輸入在 checkpoint 後含新 user 或 parent steering，且 steering 後再有 assistant/tool records；令壓縮超預算並確認裁切後保留新指令、排除舊 task。現有 restart 測試只確認新 steering 可成為 source，沒有穿過 over-budget trimming；現有 pinned-task 測試只 pin 被重新插入的 task。

### [P2] hash-only restart 的預期 409 在 `/responses/compact` 被降成 400

**觸發條件：** daemon restart 後只剩 checkpoint 的來源 hash，該來源 plaintext 不在 replay，且 checkpoint 後沒有可用的新指令。此時 [compaction-continuation.ts](G:/codex-chatgpt-web/src/adapters/chatgpt-web/compaction-continuation.ts:207) 正確 fail closed，並建立 `status: 409`、`code: compaction_source_unavailable` 的 adapter error；不會把舊 retained human message 誤認成 task。

**位置：** [compact-handler.ts](G:/codex-chatgpt-web/src/responses/compact-handler.ts:123) 依 response body 的錯誤呼叫 `httpStatusFromTerminalError`；[errors.ts](G:/codex-chatgpt-web/src/lib/errors.ts:281) 對未特別辨識的 `invalid_request_error` 一律回傳 400。因此對外 compact endpoint 的 HTTP 結果是 400，而非內部錯誤所指定的 409。

**影響：** 失敗仍然 fail closed，沒有發現錯誤 task fallback；但 endpoint 遺失了刻意選定的 conflict 狀態，呼叫端無法按 409 語義處理不可恢復的舊 checkpoint。現有 restart 測試只斷言直接錯誤物件的 `httpStatus: 409`，沒有通過 compact handler 驗證實際 HTTP status。

**最小修正：** 在 terminal error 到 HTTP status 的映射中明確將 `compaction_source_unavailable` 映射為 409，或在 bridge/compact 邊界保留此錯誤的原始 HTTP status。

**缺少的回歸：** 由 compact endpoint 送入上述 restart/replay 情境，斷言回應 HTTP 409、錯誤 code 為 `compaction_source_unavailable`，且沒有產生以舊 retained message 為 task 的成功摘要。

## 已檢視且未發現其他 A-context 問題

- hash-only continuation 沒有 plaintext task 時會拒絕繼續；重啟測試也確認不以較早 retained human message 代替，並檢查持久化 snapshot 不包含 task、summary、thread 或 turn 明文。可用的新 steering 會取代舊 task。
- 被恢復的 native goal/delegation task 在 inline 與六段 multipart 測試中維持完整；不可約縮的 task 以 `context_length_exceeded` 明確失敗。輸入訊息不被就地修改。
- compaction preflight 呼叫與實際傳送相同的 multipart transport boundary。其 deterministic `ctx_` placeholder 與實際隨機 transaction handle 等長；估算器將 ASCII handle bytes 分開計入，並納入每段 ACK、final、images、skill attachment 與全域平台 reserve。實際 stage/final 也依真正 transaction ID 估算。
- 一般回合在 compaction trimming 之前直接返回；既有/新增測試確認一般 multipart 歷史不會被裁切，超過預算會失敗。
- 找到的 cumulative checkpoint 在裁切時保留，刪除紀錄後重建 image/skill attachment 索引；不可滿足的 final/physical/global ceiling 會 fail closed。
- Enhanced 與 Bigger Context 的排他及既有 context-window resolver 未被 A-context hunks 改動；multipart 測試覆蓋 Luna/native-compaction 使用 experimental ceiling。A-context 變更未改 `useSavedChats` 的 Temporary 預設，也未變更正常 Luna checkpoint capture 的隔離條件。

## 限制

這是 manifest 指定的 A-context corrective diff 審查，不是對 196-file 整合的重複全碼庫審查，也沒有重新執行任何測試或 release gate。使用者提供的 gate 與 restart 摘要僅作既有證據；結論僅涵蓋上述 staged candidate 及所列連接路徑。
