# B-native corrective staged diff review

## 結論

發現 1 項 P1：Codex 的 mid-turn local compaction 可沿用目前的 `thread_id/turn_id`，但 `_localCompactionRequest` 未被視為獨立執行目的。當同 turn 的一般工具 session 還留在 registry，local compaction 會命中並重用該 session；fresh runtime 的 no-local-tools 設定不會套用到已存在的 runtime。這違反 checkpoint 隔離。此 finding 不宣稱已發生工具副作用重播。

基準為 HEAD/C0 `972b19b7088ab4d843e2954346c22fe0afb071b4`，staged tree 依 manifest 固定為 `d686b4a04b0823fa15e22bacdc95da219d181048`。已確認 HEAD 等於 C0。全程未修改 source、tests、config、index、GitHub、瀏覽器或 runtime。

## 發現

### [P1] 同 turn local compaction 與一般回合共用 execution key/session

**觸發條件：** Codex 發出 mid-turn 的 `request_kind=compaction` local compaction，沿用目前的 `thread_id/turn_id` 與 user revision，而該 turn 的一般 tool-mode Web session 仍在 registry。Codex 本身有在 mid-turn、沿用同一 `step_context` 呼叫 auto compaction 的路徑；其 compaction metadata 由該 turn context 建立。[turn.rs](https://github.com/openai/codex/blob/main/codex-rs/core/src/session/turn.rs#L3424-L3472)、[session.rs](https://github.com/openai/codex/blob/main/codex-rs/core/src/session/session.rs#L3561-L3587)、[compact.rs](https://github.com/openai/codex/blob/main/codex-rs/core/src/compact.rs)。這是可由 native mid-turn 請求抵達的路徑，不是假造重複 session。

**本 repo 路徑與影響：**

- [parser.ts](G:/codex-chatgpt-web/src/responses/parser.ts:659) 將 `request_kind=compaction`（但非 remote/memento compaction）標記為 `_localCompactionRequest`。
- [turn-execution-key.ts](G:/codex-chatgpt-web/src/adapters/chatgpt-web/turn-execution-key.ts:30) 只用 `_compactionRequest` 選 compaction purpose/input revision。local compaction 因而仍使用一般 response key `(thread_id, turn_id)`。
- [steering.ts](G:/codex-chatgpt-web/src/adapters/chatgpt-web/steering.ts:104) 只把 `_compactionRequest` 路由到 compaction 專用處理；local compaction 走一般路徑。same user revision 不產生 steering，會保留原 session（第 154–166 行）。[turn-session-registry.ts](G:/codex-chatgpt-web/src/adapters/chatgpt-web/turn-session-registry.ts:22) 對相同 key 直接回傳既有 session（第 30–38 行）。
- [index.ts](G:/codex-chatgpt-web/src/adapters/chatgpt-web/index.ts:315) 的 compaction 專用分支也只檢查 `_compactionRequest`。雖然第 275–280 行會在建立新 runtime 時停用 local tools，session reuse 不會重跑 factory，所以舊 tool-mode runtime 不會因此變成 read-only。
- corrective retry guard [submitted-turn.ts](G:/codex-chatgpt-web/src/adapters/chatgpt-web/submitted-turn.ts:51) 亦只排除 `_compactionRequest`，未排除 `_localCompactionRequest`。若被重用 session 的結果恰為 accepted、retryable delivery timeout 且 canonical evidence 完整，local compaction 也會通過這個 retry 例外；目前未證明該分支會重播副作用，因此此處列為隔離缺陷的放大路徑，而非第二項 replay finding。

**最小修正：** 將 local compaction 納入獨立 compaction execution identity/session lifecycle，且在建立 checkpoint 前等待來源 tool session 退休/隔離，使 factory 的 read-only 能力實際生效；同時明確把 `_localCompactionRequest` 排除於 accepted-delivery retry 例外。只加 retry 旗標不足以修復 session reuse。

**缺少的回歸測試：** 用 production parser、execution-key、`sessionForChatGptRequest`/registry 與同 turn metadata：先留存仍有效的一般 tool-mode session，再提交相同 `thread_id/turn_id/user revision` 的 local mid-turn compaction。驗證 compaction 不取得舊 session、不沿用 tool token 或結果/round、建立隔離的 no-local-tools runtime；另驗證 reused accepted delivery timeout 不會被 local compaction 送入 retry exception。本審查未執行測試，依使用者限制。

## B-native 覆蓋範圍

Manifest 指定的 9 個 primary files 及全部 staged hunks 均已檢視：

- `src/adapters/chatgpt-web/mcp-tool-inventory.ts`
- `src/adapters/chatgpt-web/native-command.ts`
- `src/adapters/chatgpt-web/submitted-turn.ts`
- `src/adapters/chatgpt-web/turn-execution.ts`
- `tests/chatgpt-web-harness.test.ts`
- `tests/native-gateway-mcp.test.ts`
- `tests/native-gateway.test.ts`
- `tests/submitted-delivery-retry.test.ts`
- `tests/upstream-v6115-adaptations.test.ts`

另追讀必要的 parser/types、canonical user revision 與 generation、execution/retry/conversation keys、session reuse/steering/registry、runtime factory、broker dispatch/owner/state、tool-result delivery、trusted environment、MCP server、index.ts 呼叫點，以及 `tests/responses-lite-tools.test.ts`、`tests/local-compaction-release.test.ts`。未審查其他 reviewer domain、初始整合全量 diff 或舊 `tmp/upstream-6.1.15/worktree`。

Same-call/result 證據比對唯一 call ID、namespaced tool name、canonicalized arguments、已交付 result payload/error state 與目前 user revision；拒絕缺漏、重複、錯配及 superseded receipt。Freeform input 正規化成 `arguments.input`，與 evidence hash 的 `{input}` 一致。未在此範圍發現其他可證實 defect。

Polling 邊界符合要求：公開 `codex_write_stdin` schema 上限維持 300K，validator 接受該值；model-facing preferred schema 維持 60K，raw connector 執行仍以 30K slices 等待。固定 Native2 外層 `tools/list` 名稱/schema/description/revision/hash 未被 corrective hunks 修改，原固定 ABI assertion 仍在；動態 nested inventory 的 polling 指示文字調整為「最大 300K、偏好 60K」，並非更改外層公開 ABI。

## 驗證與限制

依使用者提供的 `tmp/upstream-6.1.15/verify-release-v617-remediation-third.log` 記錄，`bun run verify:release` exit 0，SHA-256 為 `0964e604223da219385c7fd2403fed43e5e0be97dd56d0965496fff400f1b44c`。本審查未重跑 gate、測試、build、process、browser/account 操作或 runtime restart，也未重算該 log hash。上述 Codex 網頁來源是目前 `main` 的協定交叉核對，未當作 pinned client build 證據；本機 client/runtime 沒有另行驗證。

模型與 effort 依主線提供的 `spawn_agent(gpt-6-luna, max)` 派發紀錄；本 review 無需自行切換或驗證。P1 finding 表示本結果不是通過審查的批准。
