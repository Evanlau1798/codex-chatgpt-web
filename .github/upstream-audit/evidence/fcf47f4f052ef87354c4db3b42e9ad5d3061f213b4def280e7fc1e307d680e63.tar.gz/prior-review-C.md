# C-settings-audit Remediation Review — Final

## 結果

審查已完成。共 1 項 P2 測試／稽核證據缺口；目前未發現相應的執行期缺陷。範圍限於 C-settings-audit 的 corrective staged diff 與判斷所需連接路徑，未重做初始整合的全域審查。

候選為 HEAD=C0=972b19b7088ab4d843e2954346c22fe0afb071b4；索引樹與凍結樹 d686b4a04b0823fa15e22bacdc95da219d181048 相符。工作樹既有未暫存 .gitignore 及未追蹤 archive 保持原狀。

## Finding

### [P2] 核心 config 測試未區分退役旗標，也未驗證未知偏好存檔

位置：[tests/runtime-layout.test.ts](/G:/codex-chatgpt-web/tests/runtime-layout.test.ts:420)，對應 audit 記錄 test-210 的 rationale 位於 [.github/upstream-audit/v6.1.17.json](/G:/codex-chatgpt-web/.github/upstream-audit/v6.1.17.json:16)。

目前測試把 useTemporaryChats 設成與 useSavedChats 相同；新旗標缺席時又沒有退役旗標。這些輸入無法證明只有舊旗標的設定仍預設 Saved Chats 關閉，或新舊值衝突時只採用新旗標。後續直接呼叫 saveConfig 加入相反的舊值後，斷言只檢查舊鍵消失，沒有再驗證存檔的 useSavedChats。此外，unrelatedPreference 只在載入結果檢查，沒有在 saveConfig(loaded) 後檢查；因此 audit rationale 宣稱 unknown preference 跨存檔保留，超出該測試實際證明範圍。

具體可達情境是舊 config 僅含 useTemporaryChats=true，或同時含互相矛盾的新舊值。最小修正是在此測試加入 stale-only 與衝突組合，斷言新設定優先、缺省仍為 false、存檔的 useSavedChats 不變、舊鍵移除，並在存檔後斷言 unrelatedPreference 保留；若不補測，則縮窄 test-210 rationale。目前 source 的 parseConfig 明確將缺省設為 false 並刪除舊鍵，saveConfig 以物件展開保留其他欄位後刪除舊鍵；此 finding 是測試與證據缺口，並非已證明的 runtime bug。

## 覆蓋與限制

- 已逐一審查 manifest 中 C-settings-audit 的 22/22 主檔案：.github/upstream-audit/evidence/2e29eab6d3b1da6538576a88566ff9c940de9c5a4edd383eac4e55e76daa9377.tar.gz、.github/upstream-audit/v6.1.17.json、TROUBLESHOOTING.md、docs/release-validation.md、launcher/bun.lock、launcher/package.json、launcher/src/i18n-fr.ts、launcher/src/i18n-ko.ts、launcher/src/i18n-zh-tw.ts、src/adapters/chatgpt-web/model-selection.ts、src/config.ts、tests/browser-login.test.ts、tests/browser-worker-contract.test.ts、tests/chatgpt-model-selection.test.ts、tests/chatgpt-smoke-picker.test.ts、tests/dom-browser-lifecycle.test.ts、tests/launcher-helper-client.test.ts、tests/launcher-localization.test.ts、tests/runtime-layout.test.ts、tests/setup-lifecycle.test.ts、tests/support/dom-browser.ts、tests/temporary-chat-onboarding.test.ts。
- 檢視了指定 12 筆 audit test 記錄（025/035/045/046/047/062/063/177/179/191/195/210）及其 27 個 target 區塊的實際斷言；所列 target blob 均與凍結索引相符。特別核對了 model position 的正反例、各 locale 的實際翻譯與狀態、saved-chat helper／offline smoke、BOM 與狀態讀寫、整筆 multipart record 保留，以及 owned browser close/termination/profile cleanup。
- Vite 更新解析結果為 launcher manifest ^6.4.4 → ^6.4.5；lock workspace 僅改 Vite 版本範圍，package lock record 也僅有 Vite 6.4.4 → 6.4.5，Vite runtime dependencies 未變。
- staged evidence archive SHA-256 與 manifest 相符（747,171 bytes）。指定 verify-release-v617-remediation-third.log 的 SHA-256 與提供值相符；依要求未重跑 gate。使用者提供的 gate 通過結果作為既有驗證證據，不當成本次獨立執行。
- 未執行測試、建置、安裝、瀏覽器／profile 操作或 runtime restart；未寫入 source、tests、config 或 index。初始 196-path 整合及其他 reviewer 領域不在本次範圍。
