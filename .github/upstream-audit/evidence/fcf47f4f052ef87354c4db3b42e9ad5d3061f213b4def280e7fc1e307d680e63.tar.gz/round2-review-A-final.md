# Round2 A-context 修正獨立審查

## 結果

**未發現可證實的 actionable finding。** 本報告只涵蓋凍結候選 tree 的 7 個 A-context 檔案及必要呼叫路徑；不代表整個 v6.1.17 整合或 196 個檔案的全域核准。審查依指定模型 `gpt-6-luna max` 執行，沒有派遣子代理。

## 候選與範圍

- Round1 已審查基線：`d686b4a04b0823fa15e22bacdc95da219d181048`。
- Round2 凍結候選 tree：`66791c6624b954920dc7624e7201a9431072f35c`。
- canonical `main` HEAD：`972b19b7088ab4d843e2954346c22fe0afb071b4`。
- 使用 `git diff BASE TREE -- assigned paths` 審查候選物件；沒有以目前含其他整合修改的工作目錄代替凍結候選。

覆蓋的 7 個指定檔案：

1. `src/adapters/chatgpt-web/compaction-continuation.ts`
2. `src/adapters/chatgpt-web/prompt.ts`
3. `src/lib/errors.ts`
4. `src/server.ts`
5. `tests/compaction-task-context.test.ts`
6. `tests/compaction-task-restart.test.ts`
7. `tests/original-compaction-recovery.test.ts`

另追查 `environment.ts`、`turn-user-revision.ts`、`turn-execution-key.ts`、Responses parser、`bridge.ts`、`compact-handler.ts`、compaction handoff、multipart prompt transport 與相關測試／既有日誌，以核實 source provenance、模型上下文和 HTTP 錯誤傳遞。

## 修正路徑判斷

### 指令保留與裁切

`prompt.ts:570-575` 僅在 compaction 請求具有 raw body 與 native `turn_id` 時查找 source；查得的已驗證訊息與恢復的 task 共用裁切保留集合。`compaction-continuation.ts:156-213` 以 item ID、turn/content digest 和解析後的 `CodexMessage` 對應 raw 輸入與模型 view，忽略 parser 產生的 timestamp 後作深度比較；缺少對應模型訊息時以 `compaction_source_unavailable` 409 fail closed。

- 沒有可接受 checkpoint 時，保留本 turn 已驗證的 native user/goal/delegation 指令。
- 有 checkpoint 且其後出現新 steering 時，以 checkpoint 後的 model message 邊界定位並保留新指令；不恢復舊 task。相同字句不會被誤當成同一 revision，因為 source matching 同時驗證 item ID 與 provenance。
- task 已存在於 raw request 時只 pin 該現存 message；只有來源不在 raw request、checkpoint 確實授權且沒有更新 steering 時才插入儲存的 task 副本，未見重複 accepted work 的路徑。
- text-parts checkpoint 在 raw `acceptedCheckpoint` 與 model-view 搜尋都以文字 parts 的換行串接表示；parser 將 `input_text` 正規化為 text part，與此搜尋方式一致。新增重複字句案例帶有八筆大型 assistant history，編譯結果要求只留下 checkpoint 後的新指令一次；另有 current user/parent steering 的 inline 與 multipart 超預算案例，以及 present task 與首個 checkpoint 前 task 的超預算案例。
- 保留集合只影響既有 compaction discard loop。multipart 仍經 `prepareChatGptWebMultipartTransport` 實際 preflight；不可約縮的必要 task 仍以 `context_length_exceeded` 拒絕。這些 A-context hunks 沒有改 Native2 工具 ABI、partition/token budget 或 final instruction 的編排。

### restart、hash-only source 與 compiler 呼叫邊界

來源查找在 compiler 中是可選的；沒有完整 native body／turn identity 的獨立編譯呼叫不會被迫執行 source lookup。實際 adapter compaction 另經 `chatGptCompactionSourceExecutionKey`，其要求 native `turn_id` 並呼叫嚴格的 `extractChatGptCompactionSourceRevision`。daemon restart 後若只剩 checkpoint hash、沒有 source plaintext 或新指令，`recoverCompactionInstruction` 會以 typed `compaction_source_unavailable` 拒絕；若有新 user/parent steering，則以該新來源繼續，不把較早 retained human text 升格成 task。

現有 RED/GREEN 記錄與這條因果一致：`round2-restarted-present-task-red.log` 顯示裁切後 task count 為 0，`round2-restarted-present-task-green.log` 顯示為 1；`round2-optional-source-compaction-task-context.log`、`round2-optional-source-compaction-task-restart.log` 與 `round2-optional-source-typecheck.log` 記錄 compiler 相容性及 restart 邊界通過。這些是既有證據，本 reviewer 沒有重跑。

### typed error 到 compact HTTP 409

實際路徑為：`responseRequest` 的 adapter exception catch（`server.ts` 約 290 行）只對 `ChatGptWebAdapterError` 附上 status、error type、code、retryable；`bridge.ts:46-55,657-672,1032-1035` 保留結構化欄位並產生 failed response；`compact-handler.ts:123-130` 將回傳錯誤交給 `httpStatusFromTerminalError`；`errors.ts` 現在在一般 `invalid_request_error` 的 400 fallback 前，將 `compaction_source_unavailable` 映射為 409。未帶結構化欄位的普通 Error 仍走原有 message classification。

`round2-compact-http-typed-red.log` 記錄只保留 error code 時 HTTP 仍是 400；`round2-compact-http-green.log` 記錄 typed status/code 穿過 compact endpoint 後 goal 與 delegation 都回 409。新增的 restart endpoint 案例也確認沒有產生摘要或洩漏 task／舊 human input。

### Original recovery fixture

`original-compaction-recovery.test.ts:90-95` 現在把超長 padding 同步寫進 parsed context 與 `_rawBody` source，避免故意製造 raw/model 不一致而在 prompt integrity guard 提前失敗。原有 browser start、完整 context、multipart、final event 與不注入 `CODEX_LATEST_USER_PROMPT_JSON` 等 assertion 均保留；diff 沒有刪除或放寬 assertion。模型 view 被單獨改寫時 fail closed 的負向 proof 保留於 `compaction-task-context.test.ts:284-294`。`round2-fixture-sync-original-compaction-recovery.log` 記錄原測試組通過。

## Finding

無 actionable finding。未把未執行的 live account/browser 情境或合併測試假設列為已證實缺陷。

## 驗證與限制

- 遵照要求沒有重跑測試、`verify:release`、建置、runtime、browser/account 或 process 操作。
- 使用者提供的 gate 證據已按 manifest 對照：`remediation-freeze.json` 指向候選 tree，記錄 `verify:release` exit code 0 及 log SHA-256 `af90c6981b079292141fc994602f7c04a68750b254b014f65259a186f14132d4`；本地唯讀雜湊與該值一致。`remediation-restart-verification.json` 記錄同一 source tree 原子重啟後 healthy/accepting；`remediation-preferences-comparison.json` 顯示兩個設定檔 `changed: []`。這是既有 gate/runtime 證據，不是本 reviewer 的新執行結果。
- 審查為凍結候選的靜態路徑檢視，受限於指定 A-context 修正範圍。既有長時間 Web missing-final ROOT 仍未解決；本次指令 pinning、錯誤映射與 fixture 調整不構成其修復證據，也未改變該判斷。
