<h1 align="center">ChatGPT Web for Codex & Claude Code — Enhanced</h1>

<p align="center">
  <strong>在 Codex 或 Claude Code 中使用 ChatGPT Web（包括 Pro）。</strong><br>
  通过一个本地桥接保留原生工具、会话续接、上下文压缩与多 Agent 工作流。
</p>

<p align="center">
  <a href="https://github.com/Evanlau1798/codex-chatgpt-web/releases/latest"><img src="assets/readme/download-windows.svg" width="224" height="64" alt="Windows · x64"></a>&nbsp;
  <a href="https://github.com/Evanlau1798/codex-chatgpt-web/releases/latest"><img src="assets/readme/download-macos.svg" width="224" height="64" alt="macOS · Apple silicon"></a>&nbsp;
  <a href="https://github.com/Evanlau1798/codex-chatgpt-web/releases/latest"><img src="assets/readme/download-linux.svg" width="224" height="64" alt="Linux · x64"></a>
</p>

<p align="center">
  <a href="https://github.com/Evanlau1798/codex-chatgpt-web/releases/latest">macOS Intel</a> · <a href="https://github.com/Evanlau1798/codex-chatgpt-web/releases/latest">最新版本</a>
</p>

<p align="center">
  <a href="README.md">English</a> · <a href="README.zh-CN.md">简体中文</a> · <a href="README.ja.md">日本語</a> · <a href="README.ko.md">한국어</a>
</p>

> **版本：`6.1.10-Enhanced.1`。** 下载按钮会始终打开最新发布的 Enhanced 版本。

下一条消息建议默认关闭，位于 Enhanced 设置；自动 Native 输出在同一次最终提交中生成建议，复用本地 5 分钟 TTL 缓存。缓存未命中就不提供建议，不新增 Web 请求或页面。

已整合上游 v6.1.10，保留 Enhanced 会话、Native2 工具与快速启动。

**Plus 原生上下文（实验性）** 是 Settings 中默认关闭的选项，仅对经验证的 Plus 账户与 Enhanced 自动模式生效。
GPT-6／GPT-5.6 Sol 推理路线向 Codex 宣告 256,000-token 窗口，于 230,400 tokens 自动压缩；不解锁账户没有的 effort，
也不提高单条消息或 composer 上限。256K 实际保留能力尚未确认。其他账户、Instant、Original 与 Zero Risk 保持既有预算，
No Context Window 仍使用独立的 checkpoint 策略。CLI 设置支持 `--plus-native-context`／`--standard-plus-context`。

支持 ChatGPT 更名后的 GPT-6 模型选择器及五种推理档位。Codex 显示 GPT-6 和 GPT-6 Instant；已有 `chatgpt-web/latest` 与 `chatgpt-web/latest-instant` 任务 ID 保持兼容。

<p align="center">
  <a href="TROUBLESHOOTING.md">故障排除</a> · <a href="SECURITY.md">安全</a> · <a href="CONTRIBUTING.md">贡献</a>
</p>

<p align="center">
  <a href="https://github.com/Evanlau1798/codex-chatgpt-web/actions/workflows/ci.yml"><img src="https://github.com/Evanlau1798/codex-chatgpt-web/actions/workflows/ci.yml/badge.svg" alt="CI"></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="MIT license"></a>
  <img src="https://img.shields.io/badge/macOS-arm64%20%7C%20x64-black?logo=apple" alt="macOS arm64 and x64">
  <img src="https://img.shields.io/badge/Windows-x64-0078d4?logo=windows11" alt="Windows x64">
  <img src="https://img.shields.io/badge/Linux-x64-fcc624?logo=linux&logoColor=black" alt="Linux x64">
  <img src="https://img.shields.io/badge/Free_AI-no_API_fees-10a37f" alt="Free AI with no API fees">
</p>

这是独立维护的 **Enhanced** fork：在持续跟进上游基线的同时，提供可选的长任务 Web 会话
生命周期。Fork 版本采用 `<上游版本>-Enhanced.<修订号>`，首个版本为 `3.0.1-Enhanced.1`。

Free 和 Go 账户会在 Codex 原生模型选择器中看到 **ChatGPT Web — Luna**。具有推理选择器的
账户仍会按订阅权限看到 **Instant**、**Medium**、**High**、**Extra High** 和 **Pro**。
桥接程序会把当前编译后的 Codex 任务上下文发送到一个全新的 ChatGPT 临时聊天，附加图片，
并将可见的推理过程、工具活动和 Markdown 流式传回同一个 Codex 任务。

<p align="center">
  <img src="assets/demo.gif" alt="ChatGPT Web 实时轮次正在使用原生 Codex harness" width="960">
</p>

```text
Codex / Claude Code ──Responses 或 Messages──▶ 本地桥接 ──浏览器──▶ ChatGPT
        ▲                                          │                    │
        └──────── 上下文、工具、流式输出、压缩与生命周期 ────────────────┘
```

Codex 会保留原生任务、上下文生命周期、界面和工具 harness。本地 Responses 桥接程序只会将
所选模型的任务转发到与该任务绑定的 ChatGPT 临时聊天；在完整模式下，MCP 会把 ChatGPT 连接回
同一个 Codex 任务的工具，直到下一次上下文压缩边界。

1. **安装启动器**：点击上方对应系统的下载按钮。
2. **登录 ChatGPT**：在内置浏览器中登录并运行浏览器冒烟测试。
3. **安装模型**：重启一次 Codex。在自动模式下，选择名称以 **(Web)** 结尾的模型。Pro 版本使用独立条目，Sol 推理等级通过 Effort 选择。Zero Risk 保留专用条目。
4. **需要使用工具编程时**：打开启动器中的 **MCP**，完成下方的完整 harness 设置。

## 亮点

- **精致的跨平台启动器。** 一条命令即可安装原生 macOS、Windows 或 Linux 应用。登录流程、设置、
  冒烟测试、MCP 指南、运行状态和本地日志都集中在同一处；内置浏览器还能让你实时看到每个
  ChatGPT 轮次的执行过程。Enhanced 模式最多可同时运行六个任务绑定的浏览器标签页；此上限用于避免
  对 ChatGPT 账户产生过多并行流量。
- **ChatGPT 就是所选模型。** 它作为 Codex 原生模型运行，而不是由另一个宿主模型调用的工具。
  原有的模型选择器、任务生命周期、流式输出、追踪和工具界面保持不变。
- **本地优先的任务会话。** Codex 或 Claude Code 仍然是电脑上任务历史的真实来源。原始模式
  使用配置的上游会话策略；Enhanced 模式会将完成的 root／subagent 对话保留 30 分钟，
  并只发送新增后缀。Codex Desktop 以稳定的原生 session key 维持同一浏览器对话，因此每轮重建的
  base instructions 不会释放仍在 TTL 内的 tab；当前 developer 与 environment 更新仍随新增后缀传送。
  其他没有该身分的 client 在 system instructions 改变时会建立新对话。compact 后也会切换到新的 epoch。浏览器聊天不会在无关任务
  之间共享。默认使用临时聊天；Saved Chats 可明确启用 Codex／Claude 的历史保存，但不影响 API。
- **同时支持 Codex 与 Claude Code。** 启动器可分别安装两种集成。Codex 使用兼容 OpenAI 的
  Responses 路由；Claude Code 使用标准 Anthropic Messages 数据流，并保留 Markdown、工具区块、
  subagent、非中断式 steering、原生 `/compact` 与 recap 行为。
- **通过 MCP 使用完整 Codex harness。** 在完整模式下，登录账户可用的每一个 effort——Luna、
  Instant、Medium、High、Extra High 和 Pro——都会通过同一个与当前回合绑定的 MCP 能力，使用
  Codex 任务的文件系统、shell、图片、审批以及已配置的工具和应用。调用及其真实结果会留在
  同一个浏览器响应中，不会被模拟成文本。
- **Pro 没有例外。** Pro 与其他所有 effort 遵循完全相同的 MCP、上下文、图片、追踪、工具轮次、
  浏览器上限和压缩契约。不存在按 effort 区分的 MCP 限制。仅浏览器模式下，所有路由都保持只读。
- **故障时明确失败，并设有明确的发布门槛。** UI 变化或能力缺失会产生明确错误，而不是静默
  回退。依赖真实账户的模型选择、超长上下文、图片、流式输出、上下文压缩、原生工具轮次、
  取消操作和 Pro 必须按[发布验证清单](docs/release-validation.md)逐个候选版本验证，不能用打包
  smoke 代替。

临时聊天是 ChatGPT 的隐私模式，并不代表匿名或仅在本地推理：提示仍会由 OpenAI 处理，并受账户
设置及 OpenAI [临时聊天政策](https://help.openai.com/en/articles/8914046-temporary-chat-faq)
约束。本项目为非官方项目；用户仍需自行遵守适用的 OpenAI 条款和工作区政策。

## 快速开始

安装或更新桌面启动器。若要更新或修复现有安装，请先退出启动器，然后再次运行同一条命令；它会
替换应用程序和内置运行时，同时保留 ChatGPT 配置文件和启动器配置。

**macOS 或 Linux**

```bash
curl -fsSL https://github.com/Evanlau1798/codex-chatgpt-web/releases/latest/download/install-launcher.sh | sh
```

**Windows PowerShell**

```powershell
irm https://github.com/Evanlau1798/codex-chatgpt-web/releases/latest/download/install-launcher.ps1 | iex
```

然后在应用中完成三项检查：

1. 默认在应用内嵌页面登录。若帐号需要 Passkey，请选择 **Use Chrome for passkey**；Chrome 验证
   临时聊天后，启动器只会将非分区的 ChatGPT／OpenAI 会话 Cookie 导入其私有 Electron 配置，并
   再次验证 composer。若找不到已配置的 Chrome，启动器会直接使用内置登录。
2. 运行浏览器冒烟测试。
3. 使用 **安装到 Codex** 和／或 **安装到 Claude Code**。完成任一集成即可完成设置，两者可独立
   安装或刷新；随后重启所选客户端。

启动器会在设置期间检测当前账户的 ChatGPT 控件：Free/Go 账户只会显示 Luna；只有已登录账户
支持 Pro 时，Pro 才会显示。独立的 **MCP** 页面是可选项，它会在不需要终端命令的情况下引导你
完成完整 harness 设置。

打包后的启动器在其内置浏览器中完成登录并运行 ChatGPT 模型轮次，不需要模型 API 密钥、已安装的
Chrome/Chromium、系统级 Node/Bun，也不会由本项目另行下载浏览器。

**从源码运行**

```bash
git clone https://github.com/Evanlau1798/codex-chatgpt-web.git && \
cd codex-chatgpt-web && \
bun run app
```

Zero Risk 不读取或操作 ChatGPT 页面。请自行选择模型和 `Codex Zero Risk` 连接器，粘贴并发送准备好的提示词，再在启动器中确认 **Sent**。名称以 **(Web)** 结尾的自动模型会在 Codex 中提供其支持的 Effort 选项。Instant 和各个 Pro 版本使用独立条目，以保留各自的上下文额度；旧任务中保存的模型条目仍使用原来的固定模式。

源码方式需要 Bun 1.4.0。该命令会安装锁定版本的依赖并打开应用。

## 模式

| 模式 | 模型 | 本地 Codex 工具 | 额外设置 |
| --- | --- | --- | --- |
| **仅浏览器** | Free/Go：Luna；Plus：Instant–High；Pro：增加 Extra High 和 Pro | 不可用；Codex 会显示警告 | 无 |
| **完整 harness（自动化）** | Free/Go：Luna；Plus：Instant–High；Pro：增加 Extra High 和 Pro | 每个列出的 effort 均支持，包括 Pro | OpenAI 隧道 + ChatGPT 连接器 |
| **Zero Risk** | 手动选择 ChatGPT 模型与 effort；可选 Pro 上下文 | 支持；保留完整的回合绑定 Codex harness | 独立 OpenAI 隧道 + `Codex Zero Risk` 连接器；手动贴上并发送 |

新版 **(Web)** 条目只提供实际支持的 Effort；Instant 与各个 Pro family 保留独立的上下文额度。
旧条目保留固定模式。发送前必须验证所请求的 family 与 effort，不支持的选择会明确失败。在完整模式下，每一个可用 effort 都会
获得同一个与当前回合绑定的 MCP 能力；Pro 没有单独限制，也没有缩减后的工具契约。

Zero Risk 保留本地 Responses bridge 与完整 Codex harness，但不会读取或修改 ChatGPT 页面，也不会
替你发送提示。启动器只准备并复制提示；模型、effort、`Codex Zero Risk` 连接器、贴上与发送均由
你手动完成，以排除 ChatGPT 网页自动化本身带来的帐号风险。

### 会话设置、Limits 与 API

**Save chats in ChatGPT** 默认关闭，可为 Codex／Claude 任务启用历史保存。API 的直送与 native tool bridge 都保持 Temporary Chat，并拒绝 `store:true`。关闭保存不会删除已有历史。

**New browser chat for each turn** 默认关闭，仅供 Original Automatic 模式使用。Enhanced 与 Zero Risk 在 UI、launcher、config 和 adapter 边界强制关闭此设置，过期配置也不能重启它；该设置与是否保存历史独立。

**Limits** 是 opt-in 本地用量估算，不是官方精确剩余额度，也不取代 Account Safety。仅对实际已接受的物理消息去重计数；记账失败不能导致重发。Zero Risk 不进行自动账户检查或跟踪。
API `reasoning_effort` 仅接受新路由支持的选择，旧路由保持固定语义；同一 native Web generation 的工具续接必须保持有效 family／effort。

### 快速启动（实验性）

`6.1.4-Enhanced.1` 增加了 **Settings** 中可选择启用的 **快速启动**。它预先准备一个尚未发送
消息的待命 Web 页面，包含最后验证的模型及 harness 草稿；收到请求后，再验证账号、模型与
草稿，插入当前请求并发送。预热本身不会发送消息。工作任务优先，页面上限有空位时才准备
待命页。工作页受 Account Safety 的 **Maximum concurrency** 限制；未启用该限制时默认
最多六个 session。已完成但仍在 TTL 保留期内的页面不算待命页。

Native2 在工作期间可流式返回进度，完整最终答案则通过 output tunnel 一次原子提交。
启动及最终收尾诊断可区分本地准备时间与等待 ChatGPT 的时间。

**已知限制：** 偶发续接可能在发送前的模型验证阶段失败。已增加诊断，根因仍在调查。

### 增强型 Web 工作阶段模式

此设置在 Enhanced fork 的新安装中默认开启，且只影响 `chatgpt-web/*` 路由。已有安装的明确选择
会原样保留；从未选择过模式的旧配置会保守迁移为关闭。无论该设置如何，非 Web 的 OpenAI／Codex
模型始终使用原生 Responses 与 compact 路径。

关闭时，Web 模型使用上游原始的会话与压缩行为。开启后，桥接会增加 30 分钟 root／subagent
会话保留、同对话 steering、六路浏览器调度、结构化 handoff compact、停止／重启后的 canonical
续接，以及对超过实测浏览器 inline 边界的 bootstrap／archive 传输。稳定的 system instructions
不会在每轮重送；Codex Desktop 使用稳定的原生 session key，当前回合 context 则保留在新增后缀。
没有该稳定身分的 client 在 system instructions 改变时仍会建立新浏览器对话。每次 compact
也会建立新 epoch；旧 turn token 与已完成工具调用不会被重播。

Enhanced 自动化工具回合默认启用 **透过 MCP Tunnel 传送 Web Agent 输出**。使用者可见的进度、
reasoning 摘要与最终答案会通过现有 Native2 tunnel 返回，ChatGPT 仍会正常显示工具卡。成功路径
只持续观察回合状态；若 tunnel 没有提供最终答案，Bridge 会在同一页面验证已经结束的回应，不会
重新发送提示。关闭 Enhanced 或切换至 Zero Risk 时会保留偏好，但停用这条传输路径。

### 更大上下文（实验性）

此功能使用独立开关，可传输超过单条 ChatGPT 消息实测上限的请求，同时确保每次 composer
提交仍在已验证边界内。Bridge 会在同一个任务聊天中发送总共 1、2 或 6 条消息；六段包含五条不会执行任务的暂存消息，
逐次验证精确 acknowledgement，最后才由 commit 消息开始工作。连接器选择最多完整输入三次
`@codex`；找不到连接器时会明确失败，不会无限建立替代会话。

更大上下文不会取代 compact，也不会更改非 Web 的 OpenAI／Codex 原生路由。偏好一般单消息传输时
可关闭此功能；Enhanced 的会话保留、steering 与 handoff compact 均维持独立。

### 三个上下文开关分别改变什么

**增强型 Web 会话模式**会在工具回合、steering 与压缩之间保留同一个任务绑定的 ChatGPT 对话。
它本身只改变会话连续性，不会扩大上下文窗口，也不会关闭压缩；Plus 原生上下文实验选项另见上文。它与 **Bigger Context** 互斥。
Bigger Context 使用总共 1、2 或 6 条浏览器消息；六段为五条暂存消息加一条最终执行消息。每条都
是真实的 ChatGPT 请求，可能消耗账户额度。它会把向 Codex 公布的上下文和压缩阈值扩大三倍，但
ChatGPT 的消息、模型、编辑器、传输与服务限制仍然有效。

**No Context Window** 只会从 Codex 读取的模型目录中移除 ChatGPT Web 的上下文窗口与自动压缩
阈值。它不会创造无限上下文、绕过 ChatGPT 限制、停止 Token 计量，也不会让过大的浏览器提示变成
有效请求；这类提示仍会安全失败。只有在其他流程明确负责压缩时才应启用。

## Claude Code

在启动器中选择 **安装到 Claude Code**，即可配置本地 `/v1/messages` gateway、所选 Web 模型
别名与受管理的 steering hooks。不需要模型 API key；安装后的 gateway key 是本地占位值 `local`。
Claude Code 的 root 与 subagent 使用彼此独立的 Web 对话；mid-turn prompt 会附加在正常工具结果
边界，而不是中断或替换正在进行的工具结果。

桥接会将一般 Web commentary 输出为 Claude `text` 区块，将真正 reasoning 输出为 `thinking`，
并将工具调用输出为标准 `tool_use`。Markdown 与代码围栏会逐字传递。Claude 原生 `/compact`、
recap、resume 与 subagent 生命周期仍由客户端管理；Enhanced 模式只管理对应 Web surface 的
保留与安全续接。

## 完整 harness

完整模式通过官方
[OpenAI tunnel-client](https://github.com/openai/tunnel-client)
将 ChatGPT 的工具调用连接回当前 Codex 任务。该隧道为出站连接：不会暴露公网 IP、开放入站端口，
也不需要配置路由器端口转发。

> **限制**
>
> 有关 **GPT-5.6 Sol Pro** 和 **GPT-6 Astra** 当前的 ChatGPT 消息额度，请参阅
> [Limits](https://github.com/miuuyy/codex-chatgpt-web/discussions/309)。Token 上下文上限取决于
> 账户类型和所选 effort。GPT-5.6 Plus 的 Medium/High 使用实测的 90,000-token 窗口；启用实验性的
> **3× context** 后最高为 270,000 tokens，并且全程支持原生 Codex compaction。
> GPT-6 Sol 的 Bigger Context 在 Plus 下为 120,000 tokens／110,000 tokens 压缩，在 Pro 下为 240,000／220,000。
> 仅开放账户可用的推理 effort；Instant 使用标准窗口。GPT-5.6 与 GPT-6 Pro 保留既有上限。
> Bigger Context 仅供 Original Automatic 使用，与 Enhanced 互斥。Luna/Think 为实验性选项，
> 启用时保留任务对话，并停用 rolling checkpoint。

1. 完成启动器中的必需设置。
2. 在启动器中打开 **MCP**。请在将使用 ChatGPT 连接器的同一个 OpenAI 账户中创建 Tunnel
   和普通 API 密钥；创建密钥本身免费，也不会消耗模型 API 额度。
3. 粘贴 Tunnel ID 和 API 密钥，然后点击 **连接 Harness**。
4. 在 ChatGPT 设置中启用 **开发者模式**。新建连接器时选择 **Tunnel**，选择刚创建的
   Tunnel，将 **身份验证** 设为 **无**，并使用启动器中显示的准确名称（默认为 **Codex Native2**）。
5. 在显示的连接器的 **权限** 中选择 **允许所有操作**；**允许低风险操作** 会在命令和
   补丁到达本地运行时前将其拦截。外层 Codex harness 仍会执行沙箱和审批规则。
6. 运行 **验证运行时**，确认显示的连接器已连接并可用。

写入/修改操作还需要 ChatGPT 工作区及其管理员政策允许。请参阅
[开发者模式和 MCP 应用](https://help.openai.com/en/articles/12584461-developer-mode-and-mcp-apps-in-chatgpt)。
除非显式启用 `--auto-approve-tool-calls`，否则意外的审批提示会直接失败；该选项只会点击
**Allow once**，绝不会授予永久权限。

## 日常操作

使用 **活动** 页面查看安全的本地诊断，并通过 **设置 → 运行诊断** 执行端到端健康检查。设置页还可
取消保留的浏览器任务，或在卸载前移除 Codex 集成。仅在需要为每个浏览器检查点保存截图时设置
`CODEX_CHATGPT_WEB_BROWSER_DIAGNOSTICS=1`。

新安装默认使用 **Compatibility V1** 以支持跨后端 subagent。**Native** 会保留 Codex 自身的
功能设置，并启用明文 Web-to-Web V2 委派。切换协议后，请重启 Codex 并创建新任务：

```bash
codex-chatgpt-web subagents status
codex-chatgpt-web subagents compatibility-v1
codex-chatgpt-web subagents native
```

Subagent 协议是独立的安装设置，与增强型 Web 会话模式互不绑定。新安装默认使用
**Compatibility V1**，以获得最广泛的跨后端兼容性：安装程序会启用 `multi_agent`、关闭全局
`multi_agent_v2` override，并在断开或卸载时精确恢复用户原有的 feature 配置。启用期间还会将
`[agents].max_depth` 提升到至少 2，使 Web child 可以继续派发 Web grandchild；恢复集成时会还原
原值。Web parent 的 `wait_agent` 使用明确的 10 秒轮询，避免一次长等待占用共享 MCP channel 并
阻塞 child 自己的工具调用。

**Native V2** 是当前 Codex 协作语义下完整支持的可选模式。它保留 Codex 自己的 feature 设置，
并支持 root、child 与 grandchild 之间的明文阶层式 Web 派发、定向消息、等待及中断。切换协议后
必须重启 Codex 并建立新任务，因为既有任务无法在运行中更换协议：

```bash
codex-chatgpt-web subagents status
codex-chatgpt-web subagents compatibility-v1
codex-chatgpt-web subagents native
```

## 限制和安全性

- 这是非官方浏览器自动化，并非 OpenAI API。ChatGPT UI 变更可能破坏选择器；发生变化时会明确
  失败，而不是静默切换模型或传输方式。
- 浏览器状态是敏感的登录凭据，loopback 监听器也可被同一本地用户运行的进程访问。切勿共享
  启动器 profile，并仅在可信工作站上使用。
- 发布包目前支持 macOS 13+（arm64/x64）、Windows x64 和 Linux x64。运行时、测试和打包会在
  CI 中对三种系统进行检查；依赖账户的浏览器与 MCP 流程使用单独的
  [发布验证](docs/release-validation.md)。
- 构建目前尚未进行平台签名，因此 Gatekeeper 或 SmartScreen 可能会显示警告。安装程序会在安装前
  验证已发布的 SHA-256 清单。

启用完整模式前，请阅读完整的[架构说明](docs/architecture.md)和
[安全模型](docs/security-model.md)。安全漏洞请通过 [SECURITY.md](SECURITY.md) 报告。

## 开发

```bash
bun run app
bun run dev:launcher
bun run src/cli.ts dev status
bun run dev:chat compaction-lab "Reply with exactly: DEV READY"
bun run verify
bun run smoke:subagents
bun run app:package
```

`dev:launcher` 会在 `~/.codex-chatgpt-web-dev` 下启动第二个独立的启动器配置：Electron 状态、
浏览器 Cookie/登录、ChatGPT 账户、配置、沙箱化 `CODEX_HOME`、聊天、诊断、broker 和 tunnel
配置均与正式启动器隔离。它可以与正式启动器同时运行，绝不会启动 Responses daemon 或修改
Codex。可选的完整模式只会启动并监管隔离的 DEV MCP tunnel，并使用独立连接器名称
`Codex Native2 DEV`。

`dev:chat` 是一个具名、持久的合成外层 Codex harness。它通过隔离的启动器浏览器、临时聊天、
prompt compiler、Responses parser 和压缩处理器执行当前工作树。可选的完整模式也会测试 MCP
连接器和 broker；工具效果会显示为明确的模拟回执。仅浏览器聊天不会暴露外层工具。该命令不会
打开 Responses listener、修改 `openai_base_url`、停止正式 daemon，也不会占用 17841 端口。
不带消息运行时，可使用 `/status`、`/fill 30000`、`/compact`、`/model` 和 `/reset`。首次使用时，
请在标有 **DEV** 的窗口中登录并初始化一次配置。完整模式仅用于模拟工具轮次；DEV 启动器会保持
DEV tunnel 就绪，具名聊天按需连接 broker。正式凭据和 `Codex Native2` 连接器绝不会被隐式复用。
详见 [DEV chat harness](docs/dev-chat.md)。

- [架构说明](docs/architecture.md)
- [DEV chat harness](docs/dev-chat.md)
- [安全模型](docs/security-model.md)
- [故障排除](TROUBLESHOOTING.md)
- [贡献指南](CONTRIBUTING.md)

## Star History

<a href="https://www.star-history.com/?repos=miuuyy%2Fcodex-chatgpt-web&type=date&legend=top-left">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/chart?repos=miuuyy/codex-chatgpt-web&type=date&theme=dark&legend=top-left&sealed_token=hBVvg_eOjfMFDrfyeo5FPQkIwcvBEmXc6F7ZoOKnfFE4KPCs67o34w4XwVuM-bHGnKR-SKCAN_TSTWrzuqSBNU-RjNZCLT4f-xNs9qcDhciQtemxHKuuFj0N5YNqZIihdaQfakrh2ANhOrvP0K2LmLXX2zbsYyVaYZknyTnlYeIS_mOGvMcO32ZmPCHK">
    <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/chart?repos=miuuyy/codex-chatgpt-web&type=date&legend=top-left&sealed_token=hBVvg_eOjfMFDrfyeo5FPQkIwcvBEmXc6F7ZoOKnfFE4KPCs67o34w4XwVuM-bHGnKR-SKCAN_TSTWrzuqSBNU-RjNZCLT4f-xNs9qcDhciQtemxHKuuFj0N5YNqZIihdaQfakrh2ANhOrvP0K2LmLXX2zbsYyVaYZknyTnlYeIS_mOGvMcO32ZmPCHK">
    <img alt="Star History Chart" src="https://api.star-history.com/chart?repos=miuuyy/codex-chatgpt-web&type=date&legend=top-left&sealed_token=hBVvg_eOjfMFDrfyeo5FPQkIwcvBEmXc6F7ZoOKnfFE4KPCs67o34w4XwVuM-bHGnKR-SKCAN_TSTWrzuqSBNU-RjNZCLT4f-xNs9qcDhciQtemxHKuuFj0N5YNqZIihdaQfakrh2ANhOrvP0K2LmLXX2zbsYyVaYZknyTnlYeIS_mOGvMcO32ZmPCHK">
  </picture>
</a>

## 免责声明

本项目是独立软件，与 OpenAI 无关联，也未获得 OpenAI 背书。请仅使用自己的账户，并遵守适用的
[使用条款](https://openai.com/policies/terms-of-use/)和工作区政策；本项目不会绕过身份验证或
访问控制。
