import { expect, spyOn, test } from "bun:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { callTurnBroker, RemoteTurnBroker, TurnBroker } from "../src/adapters/chatgpt-web/turn-broker";
import { defaultBrokerEndpoint } from "../src/config";
import { submitNativeOutputControl } from "../src/adapters/chatgpt-web/native-output-control";
import { scopeHash } from "../src/adapters/chatgpt-web/mcp-request-diagnostics";

const environment = (root: string) => ({
  cwd: root, roots: [root], writableRoots: [root],
  sandboxPolicy: { type: "dangerFullAccess" as const }, tools: [],
});

test("opt-in same-final suggestions are atomic, bounded and private to the final event", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-output-prediction-"));
  const socket = defaultBrokerEndpoint(root);
  const broker = TurnBroker.forSocket(socket);
  const owner = new RemoteTurnBroker(socket);
  try {
    const disabled = await broker.register(environment(root), undefined, "prediction-off", undefined, true);
    const token = await owner.register(environment(root), undefined, "prediction-on", undefined, { predictions: true });
    const args = { kind: "final", text: "Complete answer.", next_message_prediction: "Show the diff." };
    await assert.rejects(submitNativeOutputControl(socket, disabled, args, undefined), /prediction.*enabled/i);
    await assert.rejects(submitNativeOutputControl(socket, token, { ...args, kind: "commentary" }, undefined), /prediction.*final/i);
    await assert.rejects(submitNativeOutputControl(socket, token, { ...args, next_message_prediction: "x".repeat(2_001) }, undefined), /prediction.*invalid/i);
    const first = await submitNativeOutputControl(socket, token, args, undefined);
    expect(first).toEqual({ accepted: true, sequence: 1, duplicate: false });
    expect(await submitNativeOutputControl(socket, token, args, undefined)).toMatchObject({ sequence: 1, duplicate: true });
    await assert.rejects(submitNativeOutputControl(socket, token, { ...args, next_message_prediction: "Different." }, undefined), /conflicting final/);
    expect(await owner.nextOutput(token, 0)).toEqual({ sequence: 1, kind: "final", text: "Complete answer.", nextMessagePrediction: "Show the diff." });
  } finally { await broker.close(); rmSync(root, { recursive: true, force: true }); }
});

// Await pipe I/O normally: Bun's promise matchers can re-enter its Windows pipe event loop.
test("turn output is ordered and final delivery is fail closed", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-output-tunnel-"));
  const socket = defaultBrokerEndpoint(root);
  const broker = TurnBroker.forSocket(socket);
  const owner = new RemoteTurnBroker(socket);
  const log = spyOn(console, "info").mockImplementation(() => {});
  try {
    const token = await broker.register(environment(root), undefined, "output-test", undefined, true);
    const submit = (kind: "commentary" | "reasoning" | "final", text: string) => callTurnBroker<{ duplicate: boolean }>(socket, {
      method: "submit_output", token, outputKind: kind, outputText: text,
    });
    await assert.rejects(callTurnBroker(socket, {
      method: "submit_output", token: "turn_wrong", outputKind: "commentary", outputText: "No.",
    }), /invalid, expired, or revoked/);
    await assert.rejects(callTurnBroker(socket, {
      method: "submit_output", token, outputKind: "unknown" as "commentary", outputText: "No.",
    }), /kind is invalid/);
    await assert.rejects(submit("commentary", ""), /text is invalid/);
    await submit("commentary", "Checking the repository.");
    await submit("reasoning", "The shared boundary is the smallest fix.");
    await submit("final", "Done.");
    assert.deepEqual(await owner.nextOutput(token, 0), { sequence: 1, kind: "commentary", text: "Checking the repository." });
    assert.deepEqual(await owner.nextOutput(token, 1), { sequence: 2, kind: "reasoning", text: "The shared boundary is the smallest fix." });
    assert.deepEqual(await owner.nextOutput(token, 2), { sequence: 3, kind: "final", text: "Done." });
    assert.equal((await submit("final", "Done.")).duplicate, true);
    await assert.rejects(submit("final", "Different."), /conflicting final/);
    await assert.rejects(submit("commentary", "Late."), /after the final/);
    await owner.resetOutput(token, 3);
    const nextAttempt = owner.nextOutput(token, 0);
    assert.equal(await Promise.race([
      nextAttempt.then(() => "replayed"),
      new Promise(resolve => setTimeout(() => resolve("waiting"), 10)),
    ]), "waiting");
    await submit("final", "Retried final.");
    assert.deepEqual(await nextAttempt, { sequence: 4, kind: "final", text: "Retried final." });
    const receipts = log.mock.calls.flat().filter(line => String(line).includes("output accepted"));
    expect(receipts).toHaveLength(5);
    expect(receipts).toContain("[chatgpt-web] broker trace=output-test output accepted kind=final sequence=3 chars=5 duplicate=false referenceHash=" + scopeHash(token));
    expect(receipts).toContain("[chatgpt-web] broker trace=output-test output accepted kind=final sequence=3 chars=5 duplicate=true referenceHash=" + scopeHash(token));
    expect(String(receipts)).toContain("kind=commentary sequence=1");
    expect(String(receipts)).toContain("kind=reasoning sequence=2");
    for (const privateValue of [token, "Checking the repository.", "The shared boundary is the smallest fix.", "Done.", "Retried final."]) {
      expect(String(receipts)).not.toContain(privateValue);
    }
    await broker.revoke(token);
    await assert.rejects(owner.nextOutput(token, 4));
    await assert.rejects(submit("final", "Late."), /invalid, expired, or revoked/);

    const sealedToken = await broker.register(environment(root), undefined, "sealed-output-test", undefined, true);
    assert.equal(await owner.sealOutput(sealedToken, 0, 0), true);
    await assert.rejects(callTurnBroker(socket, {
      method: "submit_output", token: sealedToken, outputKind: "final", outputText: "Too late.",
    }), /DOM fallback was sealed/);
  } finally {
    log.mockRestore();
    await broker.close();
    rmSync(root, { recursive: true, force: true });
  }
});

test("final output waits for work settlement and blocks later work until reset", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-output-final-"));
  const socket = defaultBrokerEndpoint(root);
  const broker = TurnBroker.forSocket(socket);
  const owner = new RemoteTurnBroker(socket);
  try {
    const token = await broker.register(environment(root), undefined, "output-final-test", undefined, true);
    const warnings = spyOn(console, "warn").mockImplementation(() => {});
    const activityId = "activity_1234567890123456";
    await callTurnBroker(socket, { method: "claim", token, activityId });
    await assert.rejects(callTurnBroker(socket, {
      method: "submit_output", token, outputKind: "final", outputText: "Too early.",
    }), /work tools are still active/);
    const diagnostic = warnings.mock.calls.flat().join(" ");
    warnings.mockRestore();
    expect(diagnostic).toContain("output rejected kind=final chars=10 activeActivities=1 pendingTools=0 finalizationOnly=false");
    expect(diagnostic).not.toContain(token);
    expect(diagnostic).not.toContain("Too early.");
    await callTurnBroker(socket, { method: "activity_complete", token, activityId });
    const submitted = await callTurnBroker<{ sequence: number }>(socket, {
      method: "submit_output", token, outputKind: "final", outputText: "Settled.",
    });
    await assert.rejects(callTurnBroker(socket, {
      method: "claim", token, activityId: "activity_abcdefghijklmnop",
    }), /final answer is pending/);
    await owner.resetOutput(token, submitted.sequence);
    expect(await callTurnBroker(socket, {
      method: "claim", token, activityId: "activity_abcdefghijklmnop",
    })).toMatchObject({ activityId: "activity_abcdefghijklmnop" });
  } finally {
    await broker.close();
    rmSync(root, { recursive: true, force: true });
  }
});

test("final-answer recovery closes work tools and arms final output only after browser submission", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-output-finalization-"));
  const socket = defaultBrokerEndpoint(root);
  const broker = TurnBroker.forSocket(socket);
  const owner = new RemoteTurnBroker(socket);
  try {
    const token = await broker.register(environment(root), undefined, "output-finalization-test", undefined, true);
    const activityId = "activity_1234567890123456";
    await callTurnBroker(socket, { method: "claim", token, activityId });
    assert.equal(await owner.beginFinalizationOnly(token, 0), false);
    await callTurnBroker(socket, { method: "activity_complete", token, activityId });
    const revision = await owner.beginCompletionFence(token);
    assert.equal(typeof revision, "number");
    assert.equal(await owner.beginFinalizationOnly(token, revision! - 1), false);
    assert.equal(await owner.beginFinalizationOnly(token, revision!), true);
    await assert.rejects(callTurnBroker(socket, {
      method: "claim", token, activityId: "activity_abcdefghijklmnop",
    }), /work tools are closed during final-answer recovery/);
    expect(await submitNativeOutputControl(
      socket, token, { kind: "final", text: "Recovered final." }, undefined,
    )).toMatchObject({ accepted: true });
    let delivered = false;
    const pending = owner.nextOutput(token, 0).then(event => { delivered = true; return event; });
    await Promise.resolve();
    expect(delivered).toBeFalse();
    assert.equal(await owner.armFinalizationOutput(token, revision! + 1), true);
    expect(await pending).toMatchObject({ kind: "final", text: "Recovered final." });
  } finally {
    await broker.close();
    rmSync(root, { recursive: true, force: true });
  }
});

test("a recovery submission fence reopens unfinished Native work with the exact revision", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-output-finalization-cancel-"));
  const socket = defaultBrokerEndpoint(root);
  const broker = TurnBroker.forSocket(socket);
  const owner = new RemoteTurnBroker(socket);
  try {
    const token = await broker.register(environment(root), undefined, "output-finalization-cancel-test", undefined, true);
    const revision = await owner.beginCompletionFence(token);
    assert.equal(typeof revision, "number");
    assert.equal(await owner.beginFinalizationOnly(token, revision!), true);
    assert.equal(await owner.cancelFinalizationOnly(token, revision! + 1), true);
    assert.equal(await owner.cancelFinalizationOnly(token, revision! + 1), false);
    const activityId = "activity_remaining_work_123456";
    await callTurnBroker(socket, { method: "claim", token, activityId });
    await assert.rejects(submitNativeOutputControl(
      socket, token, { kind: "final", text: "Premature completion." }, undefined,
    ), /work tools are still active/);
    await callTurnBroker(socket, { method: "activity_complete", token, activityId });
    expect(await submitNativeOutputControl(
      socket, token, { kind: "final", text: "Late final remains admissible." }, undefined,
    )).toMatchObject({ accepted: true });
  } finally {
    await broker.close();
    rmSync(root, { recursive: true, force: true });
  }
});

test("DOM fallback seal rejects new work before completion is committed", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-output-sealed-work-"));
  const socket = defaultBrokerEndpoint(root);
  const broker = TurnBroker.forSocket(socket);
  const owner = new RemoteTurnBroker(socket);
  try {
    const token = await broker.register(environment(root), undefined, "sealed-work-test", undefined, true);
    const activityId = "activity_1234567890123456";
    const claimed = await callTurnBroker<{ bindingId: string }>(socket, { method: "claim", token, activityId });
    await callTurnBroker(socket, { method: "activity_complete", token, activityId });
    const revision = await owner.beginCompletionFence(token);
    assert.equal(typeof revision, "number");
    assert.equal(await owner.sealOutput(token, 0, revision!), true);
    await assert.rejects(callTurnBroker(socket, {
      method: "claim", token, activityId: "activity_abcdefghijklmnop",
    }), /DOM fallback was sealed/);
    await assert.rejects(callTurnBroker(socket, {
      method: "invoke", bindingId: claimed.bindingId, wireName: "read", arguments: { path: "test" },
    }), /DOM fallback was sealed/);
    const completionRevision = await owner.beginCompletionFence(token);
    assert.equal(typeof completionRevision, "number");
    assert.equal(await owner.commitCompletionFence(token, completionRevision!), true);
  } finally {
    await broker.close();
    rmSync(root, { recursive: true, force: true });
  }
});

test("the hidden MCP output control is scoped to output-enabled turns", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-output-mcp-"));
  const socket = defaultBrokerEndpoint(root);
  const broker = TurnBroker.forSocket(socket);
  try {
    await broker.listen();
    const remote = new RemoteTurnBroker(socket);
    const disabled = await remote.register(environment(root), undefined, "output-disabled-test");
    const enabled = await remote.register(environment(root), undefined, "output-enabled-test", undefined, true);
    await assert.rejects(submitNativeOutputControl(
      socket, disabled, { kind: "commentary", text: "Denied." }, undefined,
    ), /not enabled/);
    expect(await submitNativeOutputControl(
      socket, enabled, { kind: "final", text: "Accepted." }, undefined,
    )).toMatchObject({ accepted: true });
    expect(await remote.nextOutput(enabled, 0)).toMatchObject({
      kind: "final", text: "Accepted.",
    });
    await assert.rejects(remote.nextOutput(disabled, 0), /not enabled/);
    await assert.rejects(remote.resetOutput(disabled, 1), /not enabled/);
    await assert.rejects(remote.sealOutput(disabled, 0, 0), /not enabled/);
  } finally {
    await broker.close();
    rmSync(root, { recursive: true, force: true });
  }
});

test("final output cannot bypass an unread native context archive", async () => {
  const root = mkdtempSync(join(tmpdir(), "cgw-output-context-"));
  const socket = defaultBrokerEndpoint(root);
  const broker = TurnBroker.forSocket(socket);
  try {
    const token = await broker.register(environment(root), undefined, "output-context-test", undefined, true);
    const contextToken = await broker.registerContext("required context", 60_000, "output-context-test", token);
    await assert.rejects(callTurnBroker(socket, {
      method: "submit_output", token, outputKind: "final", outputText: "Too early.",
    }), /context archive/);
    await callTurnBroker(socket, { method: "read_context", token: contextToken, index: 0, chunkChars: 1_000 });
    expect(await callTurnBroker(socket, {
      method: "submit_output", token, outputKind: "final", outputText: "Complete.",
    })).toMatchObject({ accepted: true });
  } finally {
    await broker.close();
    rmSync(root, { recursive: true, force: true });
  }
});
