# v6.1.8 caller closure review

## Scope

Read-only targeted caller-closure review. Inspected the bounded caller packets:

- `tmp/upstream-6.1.8/caller-1.txt` through `caller-20.txt`

Coverage was limited to the requested closure areas. This report records inspected evidence and does not repeat the previous full diff review.

## Verdicts

| Area | Verdict | Evidence |
| --- | --- | --- |
| Plus eligibility, default, persistence, CLI, catalog, adapter, no-CW | Accepted closure | `src/config.ts`, `src/setup-config.ts`, `src/provider-config.ts`, `src/adapters/chatgpt-web/adapter-runtime-config.ts`, `src/model-catalog.ts`, `src/cli.ts` paths inspected. Eligibility is guarded through config, setup, provider, runtime, and catalog boundaries. |
| Bigger Context invariants | Accepted closure | `context-mode.ts` packet plus setup, launcher state, provider and runtime packets show Enhanced Web Session gating and effective capability checks. |
| Upload frame cleanup and accepted-send ownership | Accepted closure | `attachment-upload.ts` and browser-worker attachment/send callers inspected. Upload observation is scoped to owned frame/request state and send readiness follows attachment completion handling. |
| Positive compact progress vs hidden heartbeat/accepted checkpoint | Accepted closure | `enhanced-compaction.ts`, `retained-compaction-handoff.ts`, turn broker dispatch paths inspected. Progress refresh paths and completion fence ownership are connected through existing helpers. |
| Legacy archive budget and MCP + broker final fence | Accepted closure | `turn-context-store.ts`, `mcp-server.ts`, `turn-broker-dispatch.ts` inspected. Archive paging remains bounded and final output checks incomplete context state. |
| Disabled hook preserve/tamper | Accepted closure | `codex-interrupt-hook.ts`, `codex-integration.ts` inspected. Validation rejects ownership changes while preserving managed enable state semantics. |
| Native environment rollout authority | Accepted closure | `thread-environment.ts` inspected. Stored environment remains rollout authority and claim validation is bounded by current authority. |

## Files/ranges inspected

- `src/config.ts:400-424`, `src/config.ts:473-489`
- `src/setup-config.ts:118-144`
- `launcher/electron/main.cjs:525-568`, `launcher/electron/main.cjs:858-891`
- `launcher/electron/runtime-setup-state.cjs:1-45`
- `launcher/electron/runtime-setup.cjs:367-402`
- `src/adapters/chatgpt-web/browser-worker.ts:2210-2245`, `3302-3400`
- `src/adapters/chatgpt-web/turn-broker-dispatch.ts:48-237`
- `src/codex-interrupt-hook.ts:249-464`
- `src/adapters/chatgpt-web/thread-environment.ts:377-412`, `445-523`
- `src/adapters/chatgpt-web/mcp-server.ts:397-438`
- `src/codex-integration.ts:213-235`, `331-356`
- `src/cli.ts:193-224`
- `src/model-catalog.ts:91-158`

## Remaining limitations

The caller packet coverage is complete for the provided bounded parts. No source edits were made. This closes the missing connected-caller inspection only; it does not replace the prior semantic diff review or establish additional runtime/live-account evidence.
