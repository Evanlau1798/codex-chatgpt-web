import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const root = "G:/codex-chatgpt-web";
const B = "199e6f63b9e2f69a89b4364b7384a35de4a249e2";
const folder = join(root, "tmp/upstream-6.1.8/review-parts");
mkdirSync(folder, { recursive: true });
const git = (args: string[]) => execFileSync("git", args, { cwd: root, encoding: "utf8", maxBuffer: 8 * 1024 * 1024 });
const ledger = JSON.parse(readFileSync(join(root, ".github/upstream-audit/v6.1.8.json"), "utf8"));
let packet = "# EXACT B-to-current authorized diff, excluding user gitignore and binary archive\n";
packet += git(["diff", "--no-ext-diff", B, "--", "src", "launcher", "scripts", "tests", "package.json", "README.md", "README.ja.md", "README.ko.md", "README.zh-CN.md"]);
packet += "\n# NEW UNTRACKED REGRESSION\n" + readFileSync(join(root, "tests/context-archive-budget.test.ts"), "utf8");
const currentPatch = packet;
packet += "\n# ALL UPSTREAM OBLIGATIONS\n" + JSON.stringify(ledger.obligations, null, 2);
packet += "\n# ALL UPSTREAM PATH MAPPINGS\n" + JSON.stringify(ledger.paths, null, 2);
const emittedTargets = new Set<string>();
for (const item of ledger.tests) {
  packet += `\n# UPSTREAM TEST MAPPING ${item.id}: ${item.status}\n`;
  packet += JSON.stringify({id:item.id,status:item.status,obligation:item.obligation,classification:item.classification,
    reason:item.reason,source:{name:item.source.name,path:item.source.path,start:item.source.start,end:item.source.end},
    targets:item.targets.map((t:any)=>({name:t.name,path:t.path,start:t.start,end:t.end}))}, null, 2) + "\nUPSTREAM ORIGINAL CASE:\n";
  packet += git(["cat-file", "blob", item.source.blob]).replaceAll("\r\n", "\n")
    .split("\n").slice(item.source.start - 1, item.source.end).join("\n");
  for (const target of item.targets) {
    const key = `${target.path}:${target.start}-${target.end}`;
    if (emittedTargets.has(key) || currentPatch.includes(target.name)) { packet += `\nTARGET CASE ALREADY INCLUDED IN CURRENT DIFF: ${key}\n`; continue; }
    emittedTargets.add(key);
    packet += `\nCURRENT TARGET CASE ${target.path}:${target.start}-${target.end}\n`;
    packet += readFileSync(join(root, target.path), "utf8").replaceAll("\r\n", "\n")
      .split("\n").slice(target.start - 1, target.end).join("\n");
  }
}
const chunks: string[] = [];
let chunk = "";
for (const line of packet.split("\n")) {
  if (chunk && chunk.length + line.length + 1 > 12_000) { chunks.push(chunk); chunk = ""; }
  chunk += line + "\n";
}
if (chunk) chunks.push(chunk);
const parts = chunks.map((content, index) => {
  const name = `part-${String(index + 1).padStart(2, "0")}.txt`;
  const text = `REVIEW PART ${index + 1}/${chunks.length}\n` + content;
  writeFileSync(join(folder, name), text);
  return { name, chars: text.length, sha256: createHash("sha256").update(text).digest("hex") };
});
writeFileSync(join(folder, "manifest.json"), JSON.stringify({ B, merge: git(["rev-parse", "HEAD"]).trim(), parts, sourcePaths: git(["diff", "--name-only", B, "--", "src", "launcher", "scripts", "tests", "package.json", "README.md", "README.ja.md", "README.ko.md", "README.zh-CN.md"]).trim().split("\n") }, null, 2));
console.log(JSON.stringify({ parts: parts.length, chars: packet.length, maxPartChars: Math.max(...parts.map(p => p.chars)) }));
