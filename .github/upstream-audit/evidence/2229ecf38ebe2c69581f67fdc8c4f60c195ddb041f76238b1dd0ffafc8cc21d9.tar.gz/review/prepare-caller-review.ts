import {readFileSync,writeFileSync} from "node:fs";
const root="G:/codex-chatgpt-web/", base="src/adapters/chatgpt-web/";
const full=["src/context-mode.ts","src/provider-config.ts",base+"adapter-runtime-config.ts",base+"attachment-upload.ts",base+"enhanced-compaction.ts",base+"retained-compaction-handoff.ts",base+"turn-context-store.ts"];
const ranges:[string,number,number][]=[
 ["src/chatgpt-web-models.ts",148,247], ["src/config.ts",400,424], ["src/config.ts",473,489],
 ["src/setup-config.ts",118,144], ["launcher/electron/main.cjs",525,568], ["launcher/electron/main.cjs",858,891],
 ["launcher/electron/runtime-setup-state.cjs",1,45],
 [base+"browser-worker.ts",3302,3400], [base+"browser-worker.ts",2210,2245],
 [base+"turn-broker-dispatch.ts",48,140], [base+"turn-broker-dispatch.ts",150,237],
 ["src/codex-interrupt-hook.ts",249,283], ["src/codex-interrupt-hook.ts",391,464],
 [base+"thread-environment.ts",377,412],
 [base+"mcp-server.ts",397,438], ["src/codex-integration.ts",213,235], ["src/codex-integration.ts",331,356],
 ["launcher/electron/runtime-setup.cjs",367,402], ["src/cli.ts",193,224], ["src/model-catalog.ts",91,158],
 [base+"thread-environment.ts",445,523],
];
let out="# Production caller closure packet (actual source, not review conclusions)\n";
for(const p of full) out+=`\n## COMPLETE ${p}\n`+readFileSync(root+p,"utf8");
for(const [p,s,e] of ranges) out+=`\n## ${p}:${s}-${e}\n`+readFileSync(root+p,"utf8").split("\n").slice(s-1,e).join("\n");
writeFileSync(root+"tmp/upstream-6.1.8/CALLER_REVIEW_SOURCE.txt",out);
const sections=out.split(/(?=\n## )/), inline:string[]=[], rest:string[]=[];
for(const text of sections) { if(rest.length===0 && inline.join("").length+text.length<45_000) inline.push(text); else rest.push(text); }
writeFileSync(root+"tmp/upstream-6.1.8/CALLER_INLINE.txt",inline.join(""));
rest.forEach((text,index)=>writeFileSync(root+`tmp/upstream-6.1.8/caller-${index+1}.txt`,text));
writeFileSync(root+"tmp/upstream-6.1.8/caller-manifest.json",JSON.stringify({inlineChars:inline.join("").length,parts:rest.map((text,index)=>({path:`tmp/upstream-6.1.8/caller-${index+1}.txt`,chars:text.length}))},null,2));
console.log(JSON.stringify({chars:out.length,completeFiles:full,ranges}));
