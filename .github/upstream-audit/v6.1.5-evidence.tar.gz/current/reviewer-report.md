## 獨立唯讀整合審查結論

**結論：通過。未發現確認的 P0 / P1 / P2 問題，亦未發現未解決 blocker。**

本次依指定範圍審查 frozen candidate：

- C0: `5146e58034600071550613d325555f3848026949`
- tree: `cb3d90d3e610c25685f7dbdb1c620d7cf1c52605`
- baseline B: `2537456a53da54202b7afcef45f48704eb85ce0b`
- upstream P→U: `b6ca2d3f91f8a2ba140b522fe3b3c50b4ebffa2d` → `92a356fac2292e3af5a97ab7ba634edd8d38621e`
- true merge `ea2c9373ac20ca6600aa3788059759e4572e6887` 的兩個 parent 確認為 B / U，沒有 squash 或 rebase。
- v6.1.5 tag object `38311dfe5c8914b397b6f890e2b21c990dd4a84c` 為 annotated tag，但**沒有簽章**。
- C0 的 parent 為已實際 atomic restart 的 source `36fededbde242529552378daea443bacf1266b5f`；C0 相對該 source 只多兩個 evidence receipt 檔。
- evidence archive SHA-256 確認為 `584BD5889D2C29AF4E1536795E26D926708F1D895C1F1DEE1F57A63138CF2CD4`。
- ledger 關閉狀態一致：54 paths / 202 hunks / 21 test paths / 61 case deltas，pending=0、missing=0。

### 確認 findings

**無。**

沒有發現需要列為 P0、P1 或 P2 的 correctness、data-loss、security、protocol、replay、ownership 或 integration regression，因此沒有需要提供「觸發條件／影響／最小修正方向」的未解決 finding。

### 主要審查結果

Writer disconnect / replay 路徑符合預期。事件在寫入 HTTP observer 前先完整 journal；同一 native round 的 reconnect 直接 replay 已保存事件，不會重新啟動 browser work。工具批次與 final receipt 也維持 request-specific journal。相關核心點位包括：

- `src/adapters/chatgpt-web/index.ts:369-379`：整批事件先 append，再送 observer。
- `src/adapters/chatgpt-web/index.ts:391-398`：重連先 replay exact round receipt。
- `src/adapters/chatgpt-web/turn-events.ts:70-72`：replay 不重新解譯事件。
- `src/adapters/chatgpt-web/turn-execution.ts:260-265`：shared final prelude 明確排除 `done/error`，避免另一 observer 借到前一個 round 的 terminal receipt。
- `src/adapters/chatgpt-web/turn-execution-key.ts:58-71`：round identity 綁定 native `turn_id`、purpose 與完整 raw input array。

這與 writer disconnect、heartbeat failure、tool batch replay、concurrent steering、native result at-most-once 的新增回歸案例一致。

Multipart / Bigger Context 沒有看到 upstream v6.1.5 義務遺漏。特別重新檢查了一個容易誤判的點：Pro 規劃時在 `prompt.ts` 使用 max 作為**分割容量上限**，但 runtime 並不因此固定用 max 發送；`multipart-browser-transport.ts:148-159` 仍依序嘗試 low → medium → max，選擇能承載該 stage 的最低 effort。Plus 則在 `src/chatgpt-web-models.ts:241-254` 對 low staging 套用較保守的 ordinary pre-compaction budget，必要時才升 medium。這符合 upstream 對連續 staging headroom 的修正目的，也沒有改變 Enhanced 230K / 258K 總 context contract。

Multipart stage identity / remount reconciliation 的 current-generation、acknowledgedStages、payload identity 與 rebind 驗證均有對應測試，包括 2-part / 6-part、send 前後 remount、foreign / altered / duplicate / unfinished history。沒有看到會把舊 stage 誤認成目前交易的路徑。

SSE input-size rejection、generation ownership 與 DOM grace 行為也維持 fail-closed：只接受目前 generation 的錯誤訊號，foreign/stale/malformed 事件不會直接終止目前 turn；generation/tool activity 期間會暫停 DOM liveness 計時；真正空 shell / 無答案最後會轉成 non-retryable `chatgpt_response_incomplete`，而不是錯誤地成功完成。

Think / connector / approval 流程沒有看到 selector ownership 擴張。Think 先走可見 semantic control，只有不存在時才走 slash fallback；connector 狀態與 draft 會驗證並保留。Approval 只接受目前可見且唯一匹配的 Allow / Deny surface，quoted、foreign、ambiguous control 被拒絕，manual cancellation 與 delayed mount 也有對應覆蓋。

Model-family proof 與語言 selector 的 localized Latest 修正已納入。最新版 selector 現在接受繁中「最新模型」，同時 preview 類名稱仍不會誤判。GPT-6 family 不會僅因 unversioned effort 被推論成立；既有 GPT-5.6 family proof 邏輯則保留。

Luna 邊界一致：Bigger Context 在 launcher、runtime setup、server/setup 與 adapter 層皆拒絕 Luna；UI 對 stale-on 狀態仍保留「可關閉」能力。Luna compaction 也繼續使用 rolling checkpoint contract，沒有被 Enhanced Bigger Context 流程誤收。

Environment / interrupt / journal 安全沒有看到 authority regression。trusted environment 可以在語法損壞時保存原檔並重建；未知 schema 或 invalid permission record 仍 fail-closed，不會覆寫。durable write 會在 rename 前 fsync temp file。interrupt config 與 journal error 分類維持 content-free / privacy-safe diagnostics，沒有把私密設定值打進 log。

Markdown / Passthrough contract 仍保留。完整 Markdown buffer 的原子 final、compaction 時不提前串流，以及一般 turn 的 observation streaming 都維持原有 Enhanced 行為；沒有看到 upstream 的 complete-delivery 變更破壞 exact Markdown 或 Passthrough semantics。

Native2 ABI、atomic tunnel final、hidden liveness、Fast startup ownership亦未見本次整合造成破壞。upstream runtime hunks在 fork 已拆分的模組中有實際對應，而不是因檔案搬移被漏掉；例如 Bigger Context runtime guard 已落在 `runtime-setup.cjs`，turn broker observation 也落在拆出的 dispatch 模組。

版本與依賴整合一致：

- root / launcher 為 `6.1.5-Enhanced.1`。
- MCP SDK lock resolution 為 1.32.1。
- launcher 保留 `source-map-js`。
- 既有 `proxy-addr` override 未被 upstream lock 更新沖掉。
- README 多語版本正確區分 source candidate 6.1.5 與目前正式 published 6.1.4。
- installer default 仍指向已發布的 `6.1.4-Enhanced.1`，沒有把未發布 candidate 當作 stable installer target。

Audit retention 也符合要求。54 個 upstream path / 202 hunks 已全部分類；4 個 superseded App.tsx recommendation hunks 與被移除／替代的 upstream tests 都有明確 Enhanced 替代理由與現行測試覆蓋，沒有 pending / missing obligation。

### 額外檢查過、但不構成 finding 的疑點

1. `src/adapters/chatgpt-web/prompt.ts:455` 的 Pro `stagingEfforts = ["max"]` 初看可能像強制所有 stage 用 max。實際 transport 在 `multipart-browser-transport.ts:148-159` 會依 stage 大小重新選最低可承載 effort，因此不是行為缺陷。

2. `src/adapters/chatgpt-web/turn-execution.ts:152-163` 的 512-round journal 上限會先建立第 513 個 entry 再拋錯。該錯誤隨即走同一 request 的 failure path，該 round 會被標成 completed，後續建立新 round 時可被 oldest-completed eviction 回收；沒有形成實際無界 journal growth，因此不列 finding。

### 驗證證據

我重用既有驗證證據前先確認 candidate / source / tree / evidence 身分一致。

`verify.log` 明確記錄的是 **composed production verify stages**，不是宣稱一次乾淨的 wrapper invocation。其已通過：

- root：326 test files / 2697 pass。
- launcher：662 pass / 0 fail / 6 platform skips。
- root 與 launcher typecheck。
- isolated runtime build。
- relocatable smoke。
- lifecycle 對應 stage exit 0。

localized Latest selector 修正之後另有：

- 29 focused cases / 757 assertions。
- typecheck 通過。
- all-lane lifecycle：630 pass / 0 fail / 1 platform skip / 5055 assertions，exit 0。
- real capability probe 完成，沒有送出 Web prompt。
- canonical source `36feded...` 已成功 atomic restart，健康版本為 6.1.5-Enhanced.1。

先前失敗的 runs 仍保留為失敗證據，沒有被後續成功結果「洗掉」。

### 限制與剩餘外部狀態

這次依指示**沒有**重跑 broad verification、沒有送 Web prompt、沒有 inspect image、沒有 restart、沒有修改 source / commit / push。

Hosted CI 目前仍 pending，因此這份報告能確認 frozen candidate 的 source / integration correctness 與已存在的本地驗證證據，但不能把尚未完成的 hosted CI 宣稱為通過。

v6.1.5 upstream tag 是 annotated 但 unsigned；這是 provenance 限制，不是本次整合的程式碼 blocker。

Prerequisite remount/drain baseline B 已另由 Wegener 審查，其 `PREREQ_REVIEW_REPORT.md` 為 0 P0 / P1 / P2；本次有讀取該報告並把它當成 prerequisite evidence，但沒有重新把 B 當成另一個完整審查任務重做。

**最終判定：C0 可作為此 v6.1.5 Enhanced integration candidate 的審查通過點；目前未發現未解決 blocker。**
