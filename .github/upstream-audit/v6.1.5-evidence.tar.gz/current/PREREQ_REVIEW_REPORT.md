獨立唯讀 checkpoint review 完成。**Confirmed findings：0（無 P0/P1/P2 confirmed defect）**。

我確認 `main` 的 `HEAD` 正是 `a939b389c4b3590cf345e8fc2b90528c294fc27e`，scope 與 PREREQ 一致：四個 tracked source 修改＋兩個 untracked tests；`.gitignore` 未納入審查。

- [response-turn-boundary.ts](G:/codex-chatgpt-web/src/adapters/chatgpt-web/response-turn-boundary.ts:274)：anchor-based delta 會先驗證 retained identities 的相對順序，再只把最後 retained anchor 之後的 unknown 當候選；因此歷史 remount 位於可信 anchor 前不再誤判，post-anchor 多個 unknown 仍拒絕，reorder 仍 fail-closed。必要 callers（submission evidence、assistant binding、rebind/recovery）均沿用同一 primitive，未看到旁路。
- [errors.ts](G:/codex-chatgpt-web/src/lib/errors.ts:147) / [server.ts](G:/codex-chatgpt-web/src/server.ts:497)：本機 drain 現在輸出 HTTP 503、`type=server_error`、`code=service_draining`；真正 provider 503/overload 仍維持 `server_is_overloaded`。`/v1/models`、Responses、Messages、compact 與 native auxiliary 都在進入 tracked/upstream work 前短路；Chat Completions 原本也已有 `service_draining`。`/v1/messages/steering` 只作用於既有 active root turn，我不把它視為新的模型工作 admission。
- [manifest.ts](G:/codex-chatgpt-web/scripts/lifecycle-sim/manifest.ts)：兩個 regression tests 已加入 `sharedLifecycleTests`，而 `scripts/lifecycle-sim/run.ts --lane=all` 確實會執行該清單；測試直接呼叫 production primitive / `startServer`，沒有另寫一套模擬判斷。

既有證據與候選相符：RED 為 **1 pass / 7 fail**；GREEN 為 **77 pass / 0 fail、507 assertions、5 files**；root typecheck 已留存成功紀錄，隔離 runtime build 目錄也存在。依要求沒有重跑全套、沒有修改、commit、push、restart 或再派 reviewer。

唯一需要明列的**需求解讀假設，非 finding**：PREREQ 的「missing anchors remain fail-closed」我依現有契約解讀為「沒有 anchor 時不能把 unknown 當歷史直接忽略；所有 unknown 都仍是新 turn 候選，所以兩個以上必須拒絕」。目前仍允許「0 retained overlap + 恰好 1 個 unknown」作為唯一候選；既有 [response-turn-boundary.test.ts](G:/codex-chatgpt-web/tests/response-turn-boundary.test.ts:141) 明確要求這個行為，而且新 absent-anchor 測試在 RED 階段本來就是唯一通過的 turn-identity case。若你的真正要求是「只要 0 retained overlap 就一律拒絕」，那會是尚未實作的更強契約，而不是我能從目前規格與既有測試確認的 defect。

未驗證範圍：沒有執行 `lifecycle:sim --lane=all`、live Web lifecycle、daemon health 或第二次 restart；PID 2472 與 restart 後 source 身分沿用你提供的 checkpoint 證據。
